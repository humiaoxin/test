package com.nxin.etposvr.dm.elasticsearch.controller.req;

import com.nxin.etpojar.common.validation.group.VldGroup102th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/8 18:14
 */
public class JestClientReqForm {

    /**
     * 实体属性名称
     */
    @ApiModelProperty(value = "实体属性名称", example = "3", dataType = "String")
    @NotNull(message = "000001|实体属性名称", groups = {VldGroup102th.class})
    public String fieldName;
    /**
     * 搜索值
     */
    @ApiModelProperty(value = "搜索值", example = "3", dataType = "Object")
    @NotNull(message = "000001|搜索值", groups = {VldGroup102th.class})
    public Object fieldValue;

    /**
     * 区间查询 开始搜索值
     */
   @ApiModelProperty(value = "区间查询 开始搜索值", example = "3", dataType = "Object")
    public Object startFieldValue;

    /**
     * 区间查询 结束搜索值
     */
    @ApiModelProperty(value = "区间查询 结束搜索值", example = "3", dataType = "Object")
    public Object endFieldValue;

    /**
     * 是否模糊
     */
    @ApiModelProperty(value = "是否模糊", example = "1", dataType = "Integer")
    public Integer isVague = 1;
    /**
     * 是否分词
     */
    @ApiModelProperty(value = "是否分词", example = "1", dataType = "Integer")
    public Integer isParticiple = 1;

    /**
     * 是否是字符串
     */
    @ApiModelProperty(value = "是否字符串", example = "1", dataType = "Integer")
    public Integer isString = 1;
    /**
     * 是否and
     */
    @ApiModelProperty(value = "是否and", example = "1", dataType = "Integer")
    public Integer isAnd = 1;

    /**
     * 是否排序 默认不排序  (0 升序 1，降序)
     */
    public Integer isSort=0;

    public Integer groupId;

    //组之间是否and 默认 and
    public Integer groupIsAnd=1;

    /**
     * 是否查询区间
     */
    public Integer isInterval=0;

    public Integer getGroupIsAnd() {
        return groupIsAnd;
    }

    public void setGroupIsAnd(Integer groupIsAnd) {
        this.groupIsAnd = groupIsAnd;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Integer getIsString() {
        return isString;
    }

    public void setIsString(Integer isString) {
        this.isString = isString;
    }

    public Object getStartFieldValue() {
        return startFieldValue;
    }

    public void setStartFieldValue(Object startFieldValue) {
        this.startFieldValue = startFieldValue;
    }

    public Object getEndFieldValue() {
        return endFieldValue;
    }

    public void setEndFieldValue(Object endFieldValue) {
        this.endFieldValue = endFieldValue;
    }

    public Integer getIsInterval() {
        return isInterval;
    }

    public void setIsInterval(Integer isInterval) {
        this.isInterval = isInterval;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Object getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(Object fieldValue) {
        this.fieldValue = fieldValue;
    }

    public Integer getIsVague() {
        return isVague;
    }

    public void setIsVague(Integer isVague) {
        this.isVague = isVague;
    }

    public Integer getIsParticiple() {
        return isParticiple;
    }

    public void setIsParticiple(Integer isParticiple) {
        this.isParticiple = isParticiple;
    }

    public Integer getIsAnd() {
        return isAnd;
    }

    public void setIsAnd(Integer isAnd) {
        this.isAnd = isAnd;
    }

    public Integer getIsSort() {
        return isSort;
    }

    public void setIsSort(Integer isSort) {
        this.isSort = isSort;
    }

    public JestClientReqForm(){
        super();
    }

    public JestClientReqForm(String fieldName, Object fieldValue){
        super();
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
    }
    public JestClientReqForm(String fieldName, Object fieldValue, Integer isVague, Integer isParticiple, Integer isAnd, Integer isSort) {
        super();
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
        this.isVague = isVague;
        this.isParticiple = isParticiple;
        this.isAnd = isAnd;
        this.isSort = isSort;
    }

    public JestClientReqForm(String fieldName, Object fieldValue, Object startFieldValue, Object endFieldValue, Integer isVague, Integer isParticiple, Integer isString, Integer isAnd, Integer isSort, Integer isInterval) {
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
        this.startFieldValue = startFieldValue;
        this.endFieldValue = endFieldValue;
        this.isVague = isVague;
        this.isParticiple = isParticiple;
        this.isString = isString;
        this.isAnd = isAnd;
        this.isSort = isSort;
        this.isInterval = isInterval;
    }
}
