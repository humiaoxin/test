package com.nxin.etposvr.dmp.stat.dao.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Title stat_pdmg_indicate_val表的实体类
 * @Description 生产管理指标数值表
 * @version 1.0
 * @Author System
 * @Date 2020-05-23 13:58:48
 */
public class StatPdmgIndicateVal implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields statId 统计ID
     */
    private Long statId;

    /**
     * @Fields statType 统计类型
     */
    private String statType;

    /**
     * @Fields indicateDefId 指标定义表ID
     */
    private Long indicateDefId;

    /**
     * @Fields indicateVal 指标值
     */
    private String indicateVal;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:stat_pdmg_indicate_val.id
     *
     * @return stat_pdmg_indicate_val.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:stat_pdmg_indicate_val.id
     *
     * @param id the value for stat_pdmg_indicate_val.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 统计ID 字段:stat_pdmg_indicate_val.stat_id
     *
     * @return stat_pdmg_indicate_val.stat_id, 统计ID
     */
    public Long getStatId() {
        return statId;
    }

    /**
     * 设置 统计ID 字段:stat_pdmg_indicate_val.stat_id
     *
     * @param statId the value for stat_pdmg_indicate_val.stat_id, 统计ID
     */
    public void setStatId(Long statId) {
        this.statId = statId;
    }

    /**
     * 获取 统计类型 字段:stat_pdmg_indicate_val.stat_type
     *
     * @return stat_pdmg_indicate_val.stat_type, 统计类型
     */
    public String getStatType() {
        return statType;
    }

    /**
     * 设置 统计类型 字段:stat_pdmg_indicate_val.stat_type
     *
     * @param statType the value for stat_pdmg_indicate_val.stat_type, 统计类型
     */
    public void setStatType(String statType) {
        this.statType = statType == null ? null : statType.trim();
    }

    /**
     * 获取 指标定义表ID 字段:stat_pdmg_indicate_val.indicate_def_id
     *
     * @return stat_pdmg_indicate_val.indicate_def_id, 指标定义表ID
     */
    public Long getIndicateDefId() {
        return indicateDefId;
    }

    /**
     * 设置 指标定义表ID 字段:stat_pdmg_indicate_val.indicate_def_id
     *
     * @param indicateDefId the value for stat_pdmg_indicate_val.indicate_def_id, 指标定义表ID
     */
    public void setIndicateDefId(Long indicateDefId) {
        this.indicateDefId = indicateDefId;
    }

    /**
     * 获取 指标值 字段:stat_pdmg_indicate_val.indicate_val
     *
     * @return stat_pdmg_indicate_val.indicate_val, 指标值
     */
    public String getIndicateVal() {
        return indicateVal;
    }

    /**
     * 设置 指标值 字段:stat_pdmg_indicate_val.indicate_val
     *
     * @param indicateVal the value for stat_pdmg_indicate_val.indicate_val, 指标值
     */
    public void setIndicateVal(String indicateVal) {
        this.indicateVal = indicateVal == null ? null : indicateVal.trim();
    }

    /**
     * 获取 所属系统 字段:stat_pdmg_indicate_val.system_id
     *
     * @return stat_pdmg_indicate_val.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:stat_pdmg_indicate_val.system_id
     *
     * @param systemId the value for stat_pdmg_indicate_val.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:stat_pdmg_indicate_val.data_remark
     *
     * @return stat_pdmg_indicate_val.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:stat_pdmg_indicate_val.data_remark
     *
     * @param dataRemark the value for stat_pdmg_indicate_val.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:stat_pdmg_indicate_val.create_time
     *
     * @return stat_pdmg_indicate_val.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:stat_pdmg_indicate_val.create_time
     *
     * @param createTime the value for stat_pdmg_indicate_val.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:stat_pdmg_indicate_val.version_remark
     *
     * @return stat_pdmg_indicate_val.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:stat_pdmg_indicate_val.version_remark
     *
     * @param versionRemark the value for stat_pdmg_indicate_val.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:stat_pdmg_indicate_val.vno
     *
     * @return stat_pdmg_indicate_val.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:stat_pdmg_indicate_val.vno
     *
     * @param vno the value for stat_pdmg_indicate_val.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:stat_pdmg_indicate_val.is_enabled
     *
     * @return stat_pdmg_indicate_val.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:stat_pdmg_indicate_val.is_enabled
     *
     * @param isEnabled the value for stat_pdmg_indicate_val.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :stat_pdmg_indicate_val
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", statId=").append(statId);
        sb.append(", statType=").append(statType);
        sb.append(", indicateDefId=").append(indicateDefId);
        sb.append(", indicateVal=").append(indicateVal);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :stat_pdmg_indicate_val
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        StatPdmgIndicateVal other = (StatPdmgIndicateVal) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getStatId() == null ? other.getStatId() == null : this.getStatId().equals(other.getStatId()))
            && (this.getStatType() == null ? other.getStatType() == null : this.getStatType().equals(other.getStatType()))
            && (this.getIndicateDefId() == null ? other.getIndicateDefId() == null : this.getIndicateDefId().equals(other.getIndicateDefId()))
            && (this.getIndicateVal() == null ? other.getIndicateVal() == null : this.getIndicateVal().equals(other.getIndicateVal()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :stat_pdmg_indicate_val
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getStatId() == null) ? 0 : getStatId().hashCode());
        result = prime * result + ((getStatType() == null) ? 0 : getStatType().hashCode());
        result = prime * result + ((getIndicateDefId() == null) ? 0 : getIndicateDefId().hashCode());
        result = prime * result + ((getIndicateVal() == null) ? 0 : getIndicateVal().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}