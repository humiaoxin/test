package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;

/**
 * 成交量实体
 */
public class OrderVolume {

    /**日期*/
    private String dates;
    /**交易量（笔）*/
    private BigDecimal businessCount;
    /**品类ID*/
    private Long categoryId;
    /**品类名称*/
    private String categoryName;
    /**均重*/
    private BigDecimal avgWeight;
    /**成交金额*/
    private BigDecimal payableMoney;

    public BigDecimal getPayableMoney() {
        return payableMoney;
    }

    public void setPayableMoney(BigDecimal payableMoney) {
        this.payableMoney = payableMoney;
    }

    public BigDecimal getAvgWeight() {
        return avgWeight;
    }

    public void setAvgWeight(BigDecimal avgWeight) {
        this.avgWeight = avgWeight;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public BigDecimal getBusinessCount() {
        return businessCount;
    }

    public void setBusinessCount(BigDecimal businessCount) {
        this.businessCount = businessCount;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
