package com.nxin.etposvr.dm.elasticsearch.controller.res;

import com.nxin.etposvr.dm.elasticsearch.dao.model.CmsArticleEsEntity;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/5/17 10:58
 */
public class CmsArticleEsResForm extends CmsArticleEsEntity {
  
}
