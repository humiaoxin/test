package com.nxin.etposvr.dm.commission.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class CommissionInfoDtlDmEntity {
    private Long id;

    private Long commissionId;

    private String bizDtlType;

    private Long bizDtlId;

    private Date bizDtlTime;

    private Long bizDtlAmount;

    private String commissionStatus;

    private Date commissionSettleTime;

    private BigDecimal ratio;

    private Long commissionAmount;

    private BigDecimal platformRatio;

    private Long platformCommissionAmount;

    private Long oprBoId;

    private Long payBizId;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCommissionId() {
        return commissionId;
    }

    public void setCommissionId(Long commissionId) {
        this.commissionId = commissionId;
    }

    public String getBizDtlType() {
        return bizDtlType;
    }

    public void setBizDtlType(String bizDtlType) {
        this.bizDtlType = bizDtlType == null ? null : bizDtlType.trim();
    }

    public Long getBizDtlId() {
        return bizDtlId;
    }

    public void setBizDtlId(Long bizDtlId) {
        this.bizDtlId = bizDtlId;
    }

    public Date getBizDtlTime() {
        return bizDtlTime;
    }

    public void setBizDtlTime(Date bizDtlTime) {
        this.bizDtlTime = bizDtlTime;
    }

    public Long getBizDtlAmount() {
        return bizDtlAmount;
    }

    public void setBizDtlAmount(Long bizDtlAmount) {
        this.bizDtlAmount = bizDtlAmount;
    }

    public String getCommissionStatus() {
        return commissionStatus;
    }

    public void setCommissionStatus(String commissionStatus) {
        this.commissionStatus = commissionStatus == null ? null : commissionStatus.trim();
    }

    public Date getCommissionSettleTime() {
        return commissionSettleTime;
    }

    public void setCommissionSettleTime(Date commissionSettleTime) {
        this.commissionSettleTime = commissionSettleTime;
    }

    public BigDecimal getRatio() {
        return ratio;
    }

    public void setRatio(BigDecimal ratio) {
        this.ratio = ratio;
    }

    public Long getCommissionAmount() {
        return commissionAmount;
    }

    public void setCommissionAmount(Long commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    public BigDecimal getPlatformRatio() {
        return platformRatio;
    }

    public void setPlatformRatio(BigDecimal platformRatio) {
        this.platformRatio = platformRatio;
    }

    public Long getPlatformCommissionAmount() {
        return platformCommissionAmount;
    }

    public void setPlatformCommissionAmount(Long platformCommissionAmount) {
        this.platformCommissionAmount = platformCommissionAmount;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public Long getPayBizId() {
        return payBizId;
    }

    public void setPayBizId(Long payBizId) {
        this.payBizId = payBizId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}