package com.nxin.etposvr.dm.base.dao.model;

/**
 * @author tianshiwei
 */
public class BaseRangeDmEntity {

    private Byte systemId;

    /**
     * 规模占比（小于200）
     */
    private String scale1;

    /**
     * 规模占比（大于200且小于300）
     */
    private String scale2;

    /**
     * 规模占比（大于300且小于500）
     */
    private String scale3;

    /**
     * 规模占比（大于500）
     */
    private String scale4;

    /**
     * 规模占比（小于200）
     */
    private String scaleProportion1;

    /**
     * 规模占比（大于200且小于300）
     */
    private String scaleProportion2;

    /**
     * 规模占比（大于300且小于500）
     */
    private String scaleProportion3;

    /**
     * 规模占比（大于500）
     */
    private String scaleProportion4;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getScale1() {
        return scale1;
    }

    public void setScale1(String scale1) {
        this.scale1 = scale1;
    }

    public String getScale2() {
        return scale2;
    }

    public void setScale2(String scale2) {
        this.scale2 = scale2;
    }

    public String getScale3() {
        return scale3;
    }

    public void setScale3(String scale3) {
        this.scale3 = scale3;
    }

    public String getScale4() {
        return scale4;
    }

    public void setScale4(String scale4) {
        this.scale4 = scale4;
    }

    public String getScaleProportion1() {
        return scaleProportion1;
    }

    public void setScaleProportion1(String scaleProportion1) {
        this.scaleProportion1 = scaleProportion1;
    }

    public String getScaleProportion2() {
        return scaleProportion2;
    }

    public void setScaleProportion2(String scaleProportion2) {
        this.scaleProportion2 = scaleProportion2;
    }

    public String getScaleProportion3() {
        return scaleProportion3;
    }

    public void setScaleProportion3(String scaleProportion3) {
        this.scaleProportion3 = scaleProportion3;
    }

    public String getScaleProportion4() {
        return scaleProportion4;
    }

    public void setScaleProportion4(String scaleProportion4) {
        this.scaleProportion4 = scaleProportion4;
    }
}
