package com.nxin.etposvr.dmp.satelite.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * 数据文件信息入参
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2020/1/8 10:26
 */
public class SateliteHdfInfoReqForm extends WebPageParam {

    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "HDF文件名，相同文件替换", example = "1")
    private String hdfName;

    @ApiModelProperty(value = "数据产品类型，如，TRSF_D：土壤水分日产品", example = "1")
    private String hdfType;

    @ApiModelProperty(value = "数据日期", example = "2019-10-10")
    private Date recDate;

    @ApiModelProperty(value = "所属系统", example = "1")
    private Byte systemId;

    @ApiModelProperty(value = "数据说明 开发时写入", example = "1")
    private String dataRemark;

    @ApiModelProperty(value = "是否可用 1可用 0不可用", example = "1")
    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHdfName() {
        return hdfName;
    }

    public void setHdfName(String hdfName) {
        this.hdfName = hdfName;
    }

    public String getHdfType() {
        return hdfType;
    }

    public void setHdfType(String hdfType) {
        this.hdfType = hdfType;
    }

    public Date getRecDate() {
        return recDate;
    }

    public void setRecDate(Date recDate) {
        this.recDate = recDate;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        return "SateliteHdfInfoReqForm{" +
                "id=" + id +
                ", hdfName='" + hdfName + '\'' +
                ", hdfType='" + hdfType + '\'' +
                ", recDate=" + recDate +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", isEnabled=" + isEnabled +
                '}';
    }
}
