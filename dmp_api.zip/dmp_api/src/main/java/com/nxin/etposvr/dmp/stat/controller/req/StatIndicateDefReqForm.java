package com.nxin.etposvr.dmp.stat.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 指标定义
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:03
 * @version: v_1.0.1
 */
public class StatIndicateDefReqForm extends WebPageParam {

    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields statType 统计类型
     */
    private String statType;

    /**
     * @Fields type 指标类型
     */
    private String type;

    /**
     * @Fields name 指标名称
     */
    private String name;

    /**
     * @Fields rangType 值域类型
     */
    private String rangType;

    /**
     * @Fields statLevel 统计级别
     */
    private String statLevel;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRangType() {
        return rangType;
    }

    public void setRangType(String rangType) {
        this.rangType = rangType;
    }

    public String getStatLevel() {
        return statLevel;
    }

    public void setStatLevel(String statLevel) {
        this.statLevel = statLevel;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
