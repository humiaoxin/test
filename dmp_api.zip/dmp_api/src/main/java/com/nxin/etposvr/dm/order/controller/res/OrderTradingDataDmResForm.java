package com.nxin.etposvr.dm.order.controller.res;

import java.math.BigDecimal;

/**
 * 订单大数据返回实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class OrderTradingDataDmResForm {

    /**交易额*/
    private BigDecimal amount;
    /**交易量（笔）*/
    private BigDecimal businessCount;
    /**今日交易量（笔）*/
    private BigDecimal todayBusinessCount;
    /**交易量（商品数）*/
    private BigDecimal businessNum;
    /**今日交易量（商品数）*/
    private BigDecimal todayBusinessNum;
    /**今日交易额*/
    private BigDecimal todayVolume;
    /**近X天交易额*/
    private BigDecimal rangeVolume;
    /**近X天交易量（笔）*/
    private BigDecimal rangeBusinessCount;
    /**近X天交易量（商品数）*/
    private BigDecimal rangeBusinessNum;
    /**今日新增店铺*/
    private Integer newShopNum;
    /**近X日新增店铺*/
    private Integer newShopRangeNum;
    /**在售商品数*/
    private BigDecimal saleGoodsNum;
    /**买家数量*/
    private Long buyerCount;

    public Long getBuyerCount() {
        return buyerCount;
    }

    public void setBuyerCount(Long buyerCount) {
        this.buyerCount = buyerCount;
    }

    public BigDecimal getSaleGoodsNum() {
        return saleGoodsNum;
    }

    public void setSaleGoodsNum(BigDecimal saleGoodsNum) {
        this.saleGoodsNum = saleGoodsNum;
    }

    public BigDecimal getTodayBusinessCount() {
        return todayBusinessCount;
    }

    public void setTodayBusinessCount(BigDecimal todayBusinessCount) {
        this.todayBusinessCount = todayBusinessCount;
    }

    public BigDecimal getTodayBusinessNum() {
        return todayBusinessNum;
    }

    public void setTodayBusinessNum(BigDecimal todayBusinessNum) {
        this.todayBusinessNum = todayBusinessNum;
    }

    public BigDecimal getRangeBusinessCount() {
        return rangeBusinessCount;
    }

    public void setRangeBusinessCount(BigDecimal rangeBusinessCount) {
        this.rangeBusinessCount = rangeBusinessCount;
    }

    public BigDecimal getRangeBusinessNum() {
        return rangeBusinessNum;
    }

    public void setRangeBusinessNum(BigDecimal rangeBusinessNum) {
        this.rangeBusinessNum = rangeBusinessNum;
    }

    public BigDecimal getTodayVolume() {
        return todayVolume;
    }

    public void setTodayVolume(BigDecimal todayVolume) {
        this.todayVolume = todayVolume;
    }

    public BigDecimal getRangeVolume() {
        return rangeVolume;
    }

    public void setRangeVolume(BigDecimal rangeVolume) {
        this.rangeVolume = rangeVolume;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBusinessCount() {
        return businessCount;
    }

    public void setBusinessCount(BigDecimal businessCount) {
        this.businessCount = businessCount;
    }

    public BigDecimal getBusinessNum() {
        return businessNum;
    }

    public void setBusinessNum(BigDecimal businessNum) {
        this.businessNum = businessNum;
    }

    public Integer getNewShopNum() {
        return newShopNum;
    }

    public void setNewShopNum(Integer newShopNum) {
        this.newShopNum = newShopNum;
    }

    public Integer getNewShopRangeNum() {
        return newShopRangeNum;
    }

    public void setNewShopRangeNum(Integer newShopRangeNum) {
        this.newShopRangeNum = newShopRangeNum;
    }

}
