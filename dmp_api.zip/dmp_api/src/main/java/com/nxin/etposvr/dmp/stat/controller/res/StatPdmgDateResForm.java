package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatPdmgDate;

/**
 * 品类
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:11
 * @version: v_1.0.1
 */
public class StatPdmgDateResForm extends StatPdmgDate {
}
