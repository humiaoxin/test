package com.nxin.etposvr.dm.report.dao.model;

import java.math.BigDecimal;

public class RemindRecordDmEntity {

    /**
     * 名称
     */
    private String name;

    /**
     * 数量
     */
    private BigDecimal num;

    private Byte systemId;

    /**
     * 数量百分比
     */
    private String numPercent;

    /**
     * 面积
     */
    private BigDecimal areaSize;

    public String getNumPercent() {
        return numPercent;
    }

    public void setNumPercent(String numPercent) {
        this.numPercent = numPercent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getNum() {
        return num;
    }

    public void setNum(BigDecimal num) {
        this.num = num;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
