package com.nxin.etposvr.dm.shop.dao.model;

import java.util.List;

/**
 * 店铺增长趋势返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class ShopGrowthTrendDmInfo {

    private String dates;
    private List<ShopInfoDmEntity> shopInfoDmEntityList;

    public ShopGrowthTrendDmInfo(String dates, List<ShopInfoDmEntity> shopInfoDmEntityList) {
        this.dates = dates;
        this.shopInfoDmEntityList = shopInfoDmEntityList;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public List<ShopInfoDmEntity> getShopInfoDmEntityList() {
        return shopInfoDmEntityList;
    }

    public void setShopInfoDmEntityList(List<ShopInfoDmEntity> shopInfoDmEntityList) {
        this.shopInfoDmEntityList = shopInfoDmEntityList;
    }
}
