package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatPdmgIndicateVal;

/**
 * 指标数值
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:12
 * @version: v_1.0.1
 */
public class StatPdmgIndicateValResForm extends StatPdmgIndicateVal {

    private StatIndicateDefResForm statIndicateDefResForm;

    private StatPdmgCategoryResForm statPdmgCategoryResForm;

    private StatPdmgAreaResForm statPdmgAreaResForm;

    private StatPdmgDateResForm statPdmgDateResForm;

    private StatPdmgSchemeResForm statPdmgSchemeResForm;

    public StatIndicateDefResForm getStatIndicateDefResForm() {
        return statIndicateDefResForm;
    }

    public void setStatIndicateDefResForm(StatIndicateDefResForm statIndicateDefResForm) {
        this.statIndicateDefResForm = statIndicateDefResForm;
    }

    public StatPdmgCategoryResForm getStatPdmgCategoryResForm() {
        return statPdmgCategoryResForm;
    }

    public void setStatPdmgCategoryResForm(StatPdmgCategoryResForm statPdmgCategoryResForm) {
        this.statPdmgCategoryResForm = statPdmgCategoryResForm;
    }

    public StatPdmgAreaResForm getStatPdmgAreaResForm() {
        return statPdmgAreaResForm;
    }

    public void setStatPdmgAreaResForm(StatPdmgAreaResForm statPdmgAreaResForm) {
        this.statPdmgAreaResForm = statPdmgAreaResForm;
    }

    public StatPdmgDateResForm getStatPdmgDateResForm() {
        return statPdmgDateResForm;
    }

    public void setStatPdmgDateResForm(StatPdmgDateResForm statPdmgDateResForm) {
        this.statPdmgDateResForm = statPdmgDateResForm;
    }

    public StatPdmgSchemeResForm getStatPdmgSchemeResForm() {
        return statPdmgSchemeResForm;
    }

    public void setStatPdmgSchemeResForm(StatPdmgSchemeResForm statPdmgSchemeResForm) {
        this.statPdmgSchemeResForm = statPdmgSchemeResForm;
    }
}
