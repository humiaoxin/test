package com.nxin.etposvr.dm.goods.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class GoodsAgencyUserInfoDmEntity {
    private Long id;

    private Long agencySalesBoId;

    private BigDecimal commissionAmountSum;

    private String agencySalesStatus;

    private BigDecimal commissionAmountSettled;

    private BigDecimal commissionAmountWaiting;

    private String agencySalesUserType;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Byte isEnabled;
    /**
     * 登录名
     */
    private String loginName;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 用户手机号
     */
    private String mobilePhone;
    /**
     * 用户地区
     */
    private String area;
    /**
     * 第几页
     */
    private Integer pageNum;
    /**
     * 条数
     */
    private Integer pageSize;


    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAgencySalesBoId() {
        return agencySalesBoId;
    }

    public void setAgencySalesBoId(Long agencySalesBoId) {
        this.agencySalesBoId = agencySalesBoId;
    }

    public BigDecimal getCommissionAmountSum() {
        return commissionAmountSum;
    }

    public void setCommissionAmountSum(BigDecimal commissionAmountSum) {
        this.commissionAmountSum = commissionAmountSum;
    }

    public String getAgencySalesStatus() {
        return agencySalesStatus;
    }

    public void setAgencySalesStatus(String agencySalesStatus) {
        this.agencySalesStatus = agencySalesStatus == null ? null : agencySalesStatus.trim();
    }

    public BigDecimal getCommissionAmountSettled() {
        return commissionAmountSettled;
    }

    public void setCommissionAmountSettled(BigDecimal commissionAmountSettled) {
        this.commissionAmountSettled = commissionAmountSettled;
    }

    public BigDecimal getCommissionAmountWaiting() {
        return commissionAmountWaiting;
    }

    public void setCommissionAmountWaiting(BigDecimal commissionAmountWaiting) {
        this.commissionAmountWaiting = commissionAmountWaiting;
    }

    public String getAgencySalesUserType() {
        return agencySalesUserType;
    }

    public void setAgencySalesUserType(String agencySalesUserType) {
        this.agencySalesUserType = agencySalesUserType == null ? null : agencySalesUserType.trim();
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}