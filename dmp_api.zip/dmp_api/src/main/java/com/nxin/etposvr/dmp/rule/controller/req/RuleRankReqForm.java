package com.nxin.etposvr.dmp.rule.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup4th;
import com.nxin.etpojar.common.validation.group.VldGroup5th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class RuleRankReqForm extends WebPageParam {
    @NotNull(message = "规则类型id不能为空", groups = {VldGroup4th.class})
    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "业务类型", example = "DPXYZ")
    private String busType;

    @ApiModelProperty(value = "规则表ID", example = "1")
    private Long infoId;

    @ApiModelProperty(value = "名称", example = "店铺信誉值")
    private String name;

    @NotNull(message = "等级", groups = {VldGroup5th.class})
    @ApiModelProperty(value = "等级", example = "1")
    private Integer rank;

    @ApiModelProperty(value = "最小值", example = "1")
    private Integer minValue;

    @ApiModelProperty(value = "最大值", example = "1000")
    private Integer maxValue;

    @ApiModelProperty(value = "排序", example = "1")
    private Integer sorting;

    @ApiModelProperty(value = "图标", example = "icon")
    private String icon;

    @ApiModelProperty(value = "所属系统", example = "6")
    private Byte systemId;

    @ApiModelProperty(value = "创建时间", example = "")
    private Date createTime;

    @ApiModelProperty(value = "版本号", example = "")
    private Date vno;

    @ApiModelProperty(value = "是否可用", example = "1可用 0不可用")
    private Byte isEnabled;

    @ApiModelProperty(value = "规则系数", example = "")
    private BigDecimal factor;

    private List<RuleRankReqForm> reqFormList;

    private Integer value;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusType() {
        return busType;
    }

    public void setBusType(String busType) {
        this.busType = busType;
    }

    public Long getInfoId() {
        return infoId;
    }

    public void setInfoId(Long infoId) {
        this.infoId = infoId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Integer getMinValue() {
        return minValue;
    }

    public void setMinValue(Integer minValue) {
        this.minValue = minValue;
    }

    public Integer getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    public Integer getSorting() {
        return sorting;
    }

    public void setSorting(Integer sorting) {
        this.sorting = sorting;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public List<RuleRankReqForm> getReqFormList() {
        return reqFormList;
    }

    public void setReqFormList(List<RuleRankReqForm> reqFormList) {
        this.reqFormList = reqFormList;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public BigDecimal getFactor() {
        return factor;
    }

    public void setFactor(BigDecimal factor) {
        this.factor = factor;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
