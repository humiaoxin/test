package com.nxin.etposvr.dm.export.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2020/9/5 10:41
 */
public class ExportSystemCategoryDmReqForm extends WebPageParam {

    /**
     * 系统id
     */
    private Byte systemId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
