package com.nxin.etposvr.dm.order.controller.res;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;

public class OrderInfoDmResForm extends WebPageParam {

    private List<Long> boIdList;

    private Date startTime;

    private Date endTime;

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "OrderInfoDmReqForm{" +
                "boIdList=" + boIdList +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
