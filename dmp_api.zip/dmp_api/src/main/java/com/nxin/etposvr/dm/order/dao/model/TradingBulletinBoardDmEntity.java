package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;

/**
 * 实时交易公告板实体
 * @author ZhangXu
 * @since 2020.1.7
 */
public class TradingBulletinBoardDmEntity {

    /**
     * 订单时间
     */
    private String orderTime;
    /**
     * 地区
     */
    private String areaName;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 售价
     */
    private BigDecimal sellPrice;
    /**
     * 商品状态
     */
    private String goodsStatus;

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getGoodsStatus() {
        return goodsStatus;
    }

    public void setGoodsStatus(String goodsStatus) {
        this.goodsStatus = goodsStatus;
    }
}
