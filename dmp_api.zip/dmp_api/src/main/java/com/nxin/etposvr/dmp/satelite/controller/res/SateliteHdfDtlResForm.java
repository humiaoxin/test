package com.nxin.etposvr.dmp.satelite.controller.res;

import com.nxin.etposvr.dmp.satelite.dao.model.SateliteHdfDtl;

/**
 * 卫星数据明细
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2020/1/8 10:27
 */
public class SateliteHdfDtlResForm extends SateliteHdfDtl {
}
