package com.nxin.etposvr.dm.goods.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import com.nxin.etposvr.dm.goods.dao.model.GoodsAttrDmEntity;
import com.nxin.etposvr.dm.goods.dao.model.GoodsSpecDmEntity;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

public class GoodsInfoDmReqForm extends WebPageParam {

    public String id;

    public String name;

    public String shopId;

    private Byte systemId;

    public String type;

    private String categoryAxis;

    private String categoryName;

    private String areaAxis;

    private String areaFullName;

    public List<GoodsAttrDmEntity> goodsAttrDmEntityList;

    public List<GoodsSpecDmEntity> goodsSpecDmEntityList;

    public String oneCategoryId;

    public String twoCategoryId;

    public String categoryId;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    public String promotionType;

    public String thumbnailUrl;

    public String saleMode;

    private Date  vno;

    private Date expireTime;

    private Date publishTime;

    private Long sellerBoId;

    /**
     * 客户boId集合
     */
    @ApiModelProperty(value = "客户boId集合", example = "110119011415270001", dataType = "List")
    @NotNull(message = "000001|客户boId集合", groups = {VldGroup2th.class})
    public List<Long> boIdList;

    /**
     * 分类串模糊查询
     */
    @ApiModelProperty(value = "分类串", example = "$12$123", dataType = "List")
    @NotNull(message = "000001|分类串", groups = {VldGroup1th.class})
    private String categoryAxisLike;

    /**状态*/
    private String status;
    /**数量*/
    private Integer count;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<GoodsAttrDmEntity> getGoodsAttrDmEntityList() {
        return goodsAttrDmEntityList;
    }

    public void setGoodsAttrDmEntityList(List<GoodsAttrDmEntity> goodsAttrDmEntityList) {
        this.goodsAttrDmEntityList = goodsAttrDmEntityList;
    }

    public List<GoodsSpecDmEntity> getGoodsSpecDmEntityList() {
        return goodsSpecDmEntityList;
    }

    public void setGoodsSpecDmEntityList(List<GoodsSpecDmEntity> goodsSpecDmEntityList) {
        this.goodsSpecDmEntityList = goodsSpecDmEntityList;
    }

    public String getOneCategoryId() {
        return oneCategoryId;
    }

    public void setOneCategoryId(String oneCategoryId) {
        this.oneCategoryId = oneCategoryId;
    }

    public String getTwoCategoryId() {
        return twoCategoryId;
    }

    public void setTwoCategoryId(String twoCategoryId) {
        this.twoCategoryId = twoCategoryId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public String getSaleMode() {
        return saleMode;
    }

    public void setSaleMode(String saleMode) {
        this.saleMode = saleMode;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    @Override
    public String toString() {
        return "GoodsInfoDmReqForm{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", shopId='" + shopId + '\'' +
                ", systemId='" + systemId + '\'' +
                ", type='" + type + '\'' +
                ", categoryAxis='" + categoryAxis + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", areaAxis='" + areaAxis + '\'' +
                ", areaFullName='" + areaFullName + '\'' +
                ", goodsAttrDmEntityList=" + goodsAttrDmEntityList +
                ", goodsSpecDmEntityList=" + goodsSpecDmEntityList +
                ", oneCategoryId='" + oneCategoryId + '\'' +
                ", twoCategoryId='" + twoCategoryId + '\'' +
                ", categoryId='" + categoryId + '\'' +
                ", oneAreaId='" + oneAreaId + '\'' +
                ", twoAreaId='" + twoAreaId + '\'' +
                ", areaId='" + areaId + '\'' +
                ", promotionType='" + promotionType + '\'' +
                ", thumbnailUrl='" + thumbnailUrl + '\'' +
                ", saleMode='" + saleMode + '\'' +
                ", vno=" + vno +
                ", expireTime=" + expireTime +
                ", publishTime=" + publishTime +
                ", sellerBoId=" + sellerBoId +
                ", boIdList=" + boIdList +
                ", categoryAxisLike='" + categoryAxisLike + '\'' +
                '}';
    }
}
