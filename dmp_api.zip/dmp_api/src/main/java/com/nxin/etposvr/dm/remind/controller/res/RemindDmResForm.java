package com.nxin.etposvr.dm.remind.controller.res;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * 提醒
 *
 * @author sjw
 * @version v_1.0.1
 * @since 2019/11/16
 */
public class RemindDmResForm  {
    /**
     *  地块名称
     */
    private String landName;
    /**
     * 提醒日期
     */
    private String value;
    /**
     * 类型
     */
    private String type;
    /**
     * 所属系统
     */
    private Byte systemId;

    /**
     * 提醒个数
     */
    private Integer sumNum;

    /**
     * 类型中文
     */
    private String typeCn;

    /**
     * 移动端url
     */
    private String mobUrl;

    /**
     * pc端url
     */
    private String pcUrl;

    public String getLandName() {
        return landName;
    }

    public void setLandName(String landName) {
        this.landName = landName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Integer getSumNum() {
        return sumNum;
    }

    public void setSumNum(Integer sumNum) {
        this.sumNum = sumNum;
    }

    public String getTypeCn() {
        return typeCn;
    }

    public void setTypeCn(String typeCn) {
        this.typeCn = typeCn;
    }

    public String getMobUrl() {
        return mobUrl;
    }

    public void setMobUrl(String mobUrl) {
        this.mobUrl = mobUrl;
    }

    public String getPcUrl() {
        return pcUrl;
    }

    public void setPcUrl(String pcUrl) {
        this.pcUrl = pcUrl;
    }
}
