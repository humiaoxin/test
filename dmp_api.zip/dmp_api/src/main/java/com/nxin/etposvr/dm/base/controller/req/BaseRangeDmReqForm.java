package com.nxin.etposvr.dm.base.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * @author tianshiwei
 */
public class BaseRangeDmReqForm extends WebPageParam {

    private Byte systemId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

}
