package com.nxin.etposvr.dm.goods.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * @author LiuXiBin
 * @since 2019/12/11 13:25
 */
public class GoodsAgencySalesDmReqForm extends WebPageParam {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields agencySalesBoId 代理销售用户ID
     */
    private Long agencySalesBoId;

    /**
     * @Fields agencySalesOperatorBoId 代理销售操作员ID
     */
    private Long agencySalesOperatorBoId;

    /**
     * @Fields agencySalesUserType 代理销售用户类型
     */
    private String agencySalesUserType;

    /**
     * @Fields agencySalesType 代理销售类型
     */
    private String agencySalesType;

    /**
     * @Fields goodsId 商品ID(SPU)
     */
    private Long goodsId;

    /**
     * @Fields goodsSpecId 商品规格ID
     */
    private Long goodsSpecId;

    /**
     * @Fields sort 排序
     */
    private Byte sort;
    /**
     * @Fields systemId 系统ID
     */
    private Byte systemId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAgencySalesBoId() {
        return agencySalesBoId;
    }

    public void setAgencySalesBoId(Long agencySalesBoId) {
        this.agencySalesBoId = agencySalesBoId;
    }

    public Long getAgencySalesOperatorBoId() {
        return agencySalesOperatorBoId;
    }

    public void setAgencySalesOperatorBoId(Long agencySalesOperatorBoId) {
        this.agencySalesOperatorBoId = agencySalesOperatorBoId;
    }

    public String getAgencySalesUserType() {
        return agencySalesUserType;
    }

    public void setAgencySalesUserType(String agencySalesUserType) {
        this.agencySalesUserType = agencySalesUserType;
    }

    public String getAgencySalesType() {
        return agencySalesType;
    }

    public void setAgencySalesType(String agencySalesType) {
        this.agencySalesType = agencySalesType;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Long getGoodsSpecId() {
        return goodsSpecId;
    }

    public void setGoodsSpecId(Long goodsSpecId) {
        this.goodsSpecId = goodsSpecId;
    }

    public Byte getSort() {
        return sort;
    }

    public void setSort(Byte sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        return "GoodsAgencySalesDmReqForm{" +
                "id=" + id +
                ", agencySalesBoId=" + agencySalesBoId +
                ", agencySalesOperatorBoId=" + agencySalesOperatorBoId +
                ", agencySalesUserType='" + agencySalesUserType + '\'' +
                ", agencySalesType='" + agencySalesType + '\'' +
                ", goodsId=" + goodsId +
                ", goodsSpecId=" + goodsSpecId +
                ", sort=" + sort +
                '}';
    }
}
