package com.nxin.etposvr.dm.rebate.controller.res;

import com.nxin.etposvr.dm.goods.controller.res.GoodsSpecAttrDmResForm;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @version 1.0
 * @Title rebate_setting表的实体类
 * @Description 分账设置表
 * @Author System
 * @Date 2019-12-06 09:38:25
 */
public class RebateSettingDmResForm {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields type 类型 FD-返点, FY-返佣
     */
    private String type;

    /**
     * @Fields boId 用户编号
     */
    private Long boId;

    /**
     * @Fields busType 业务类型 SHOP-店铺 GOODS-货品 CATE品类 SPEC-规格
     */
    private String busType;

    /**
     * @Fields shopId 店铺编号
     */
    private Long shopId;

    /**
     * @Fields goodsId 商品编号
     */
    private Long goodsId;

    /**
     * @Fields categoryId 品类编号
     */
    private Long categoryId;

    /**
     * @Fields goodsSpecId 商品规格编号
     */
    private Long goodsSpecId;

    /**
     * @Fields ratio 返点比例
     */
    private BigDecimal ratio;

    /**
     * @Fields editBoid 编辑人
     */
    private Long editBoid;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    /**
     * @Fields pageNum 页码
     */
    private Integer pageNum;
    /**
     * @Fields pageSize 页大小
     */
    private Integer pageSize;

    /**
     * @Fields idList id集合
     */
    private List<Long> idList;
    /**
     * @Fields goodsName 商品名称
     */
    private String goodsName;
    /**
     * @Fields shopName 店铺名称
     */
    private String shopName;
    /**
     * @Fields categoryName 品类名称
     */
    private String categoryName;
    /**
     * @Fields attrDefName 规格名称
     */
    private String attrDefName;
    /**
     * @Fields sellPrice 商品价格
     */
    private BigDecimal sellPrice;
    /**
     * @Fields goodsNameLike 商品名称模糊查
     */
    private String goodsNameLike;
    /**
     * @Fields shopNameLike 店铺名称模糊查
     */
    private String shopNameLike;
    /**
     * @Fields realName 企业名称
     */
    private String realName;
    /**
     * @Fields tel 店铺联系电话
     */
    private String tel;

    /**
     * @Fields 商品缩率图
     */
    private String thumbnailUrl;
    /**
     * @Fields 分账金额
     */
    private BigDecimal rebateMoney;
    /**
     * @Fields goodsSpecAttrDmResFormList 商品规格属性集合
     */
    private List<GoodsSpecAttrDmResForm> goodsSpecAttrDmResFormList;
    /**
     * @Fields shopAreaFullName 店铺所在地区
     */
    private String shopAreaFullName;

    /**
     * @Fields currStock 库存
     */
    private String currStock;
    /**
     * @Fields currStock 库存单位
     */
    private String stockUnitTxt;

    /**
     * 返佣比例
     *
     * @author lpp
     * @date 2019/12/12 17:11
     */
    private BigDecimal fyRatio;
    /**
     * 规格描述
     *
     * @author lpp
     * @date 2019/12/13 15:46
     */
    private String goodsSpecTxt;

    public String getGoodsSpecTxt() {
        return goodsSpecTxt;
    }

    public void setGoodsSpecTxt(String goodsSpecTxt) {
        this.goodsSpecTxt = goodsSpecTxt;
    }
    public BigDecimal getFyRatio() {
        return fyRatio;
    }

    public void setFyRatio(BigDecimal fyRatio) {
        this.fyRatio = fyRatio;
    }

    /**
     * 获取 ID 字段:rebate_setting.id
     *
     * @return rebate_setting.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:rebate_setting.id
     *
     * @param id the value for rebate_setting.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 类型 FD-返点, FY-返佣 字段:rebate_setting.type
     *
     * @return rebate_setting.type, 类型 FD-返点, FY-返佣
     */
    public String getType() {
        return type;
    }

    /**
     * 设置 类型 FD-返点, FY-返佣 字段:rebate_setting.type
     *
     * @param type the value for rebate_setting.type, 类型 FD-返点, FY-返佣
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 获取 用户编号 字段:rebate_setting.bo_id
     *
     * @return rebate_setting.bo_id, 用户编号
     */
    public Long getBoId() {
        return boId;
    }

    /**
     * 设置 用户编号 字段:rebate_setting.bo_id
     *
     * @param boId the value for rebate_setting.bo_id, 用户编号
     */
    public void setBoId(Long boId) {
        this.boId = boId;
    }

    /**
     * 获取 业务类型 SHOP-店铺 GOODS-货品 CATE品类 SPEC-规格 字段:rebate_setting.bus_type
     *
     * @return rebate_setting.bus_type, 业务类型 SHOP-店铺 GOODS-货品 CATE品类 SPEC-规格
     */
    public String getBusType() {
        return busType;
    }

    /**
     * 设置 业务类型 SHOP-店铺 GOODS-货品 CATE品类 SPEC-规格 字段:rebate_setting.bus_type
     *
     * @param busType the value for rebate_setting.bus_type, 业务类型 SHOP-店铺 GOODS-货品 CATE品类 SPEC-规格
     */
    public void setBusType(String busType) {
        this.busType = busType == null ? null : busType.trim();
    }

    /**
     * 获取 店铺编号 字段:rebate_setting.shop_id
     *
     * @return rebate_setting.shop_id, 店铺编号
     */
    public Long getShopId() {
        return shopId;
    }

    /**
     * 设置 店铺编号 字段:rebate_setting.shop_id
     *
     * @param shopId the value for rebate_setting.shop_id, 店铺编号
     */
    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    /**
     * 获取 商品编号 字段:rebate_setting.goods_id
     *
     * @return rebate_setting.goods_id, 商品编号
     */
    public Long getGoodsId() {
        return goodsId;
    }

    /**
     * 设置 商品编号 字段:rebate_setting.goods_id
     *
     * @param goodsId the value for rebate_setting.goods_id, 商品编号
     */
    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    /**
     * 获取 品类编号 字段:rebate_setting.category_id
     *
     * @return rebate_setting.category_id, 品类编号
     */
    public Long getCategoryId() {
        return categoryId;
    }

    /**
     * 设置 品类编号 字段:rebate_setting.category_id
     *
     * @param categoryId the value for rebate_setting.category_id, 品类编号
     */
    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * 获取 商品规格编号 字段:rebate_setting.goods_spec_id
     *
     * @return rebate_setting.goods_spec_id, 商品规格编号
     */
    public Long getGoodsSpecId() {
        return goodsSpecId;
    }

    /**
     * 设置 商品规格编号 字段:rebate_setting.goods_spec_id
     *
     * @param goodsSpecId the value for rebate_setting.goods_spec_id, 商品规格编号
     */
    public void setGoodsSpecId(Long goodsSpecId) {
        this.goodsSpecId = goodsSpecId;
    }

    /**
     * 获取 返点比例 字段:rebate_setting.ratio
     *
     * @return rebate_setting.ratio, 返点比例
     */
    public BigDecimal getRatio() {
        return ratio;
    }

    /**
     * 设置 返点比例 字段:rebate_setting.ratio
     *
     * @param ratio the value for rebate_setting.ratio, 返点比例
     */
    public void setRatio(BigDecimal ratio) {
        this.ratio = ratio;
    }

    /**
     * 获取 编辑人 字段:rebate_setting.edit_boid
     *
     * @return rebate_setting.edit_boid, 编辑人
     */
    public Long getEditBoid() {
        return editBoid;
    }

    /**
     * 设置 编辑人 字段:rebate_setting.edit_boid
     *
     * @param editBoid the value for rebate_setting.edit_boid, 编辑人
     */
    public void setEditBoid(Long editBoid) {
        this.editBoid = editBoid;
    }

    /**
     * 获取 所属系统 字段:rebate_setting.system_id
     *
     * @return rebate_setting.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:rebate_setting.system_id
     *
     * @param systemId the value for rebate_setting.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:rebate_setting.data_remark
     *
     * @return rebate_setting.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:rebate_setting.data_remark
     *
     * @param dataRemark the value for rebate_setting.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:rebate_setting.create_time
     *
     * @return rebate_setting.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:rebate_setting.create_time
     *
     * @param createTime the value for rebate_setting.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:rebate_setting.version_remark
     *
     * @return rebate_setting.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:rebate_setting.version_remark
     *
     * @param versionRemark the value for rebate_setting.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:rebate_setting.vno
     *
     * @return rebate_setting.vno, 版本号
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:rebate_setting.vno
     *
     * @param vno the value for rebate_setting.vno, 版本号
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:rebate_setting.is_enabled
     *
     * @return rebate_setting.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:rebate_setting.is_enabled
     *
     * @param isEnabled the value for rebate_setting.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }


    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAttrDefName() {
        return attrDefName;
    }

    public void setAttrDefName(String attrDefName) {
        this.attrDefName = attrDefName;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getGoodsNameLike() {
        return goodsNameLike;
    }

    public void setGoodsNameLike(String goodsNameLike) {
        this.goodsNameLike = goodsNameLike;
    }

    public String getShopNameLike() {
        return shopNameLike;
    }

    public void setShopNameLike(String shopNameLike) {
        this.shopNameLike = shopNameLike;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public List<GoodsSpecAttrDmResForm> getGoodsSpecAttrDmResFormList() {
        return goodsSpecAttrDmResFormList;
    }

    public void setGoodsSpecAttrDmResFormList(List<GoodsSpecAttrDmResForm> goodsSpecAttrDmResFormList) {
        this.goodsSpecAttrDmResFormList = goodsSpecAttrDmResFormList;
    }

    public String getShopAreaFullName() {
        return shopAreaFullName;
    }

    public void setShopAreaFullName(String shopAreaFullName) {
        this.shopAreaFullName = shopAreaFullName;
    }

    public String getCurrStock() {
        return currStock;
    }

    public void setCurrStock(String currStock) {
        this.currStock = currStock;
    }

    public String getStockUnitTxt() {
        return stockUnitTxt;
    }

    public void setStockUnitTxt(String stockUnitTxt) {
        this.stockUnitTxt = stockUnitTxt;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public BigDecimal getRebateMoney() {
        return rebateMoney;
    }

    public void setRebateMoney(BigDecimal rebateMoney) {
        this.rebateMoney = rebateMoney;
    }

    @Override
    public String toString() {
        return "RebateSettingDmResForm{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", boId=" + boId +
                ", busType='" + busType + '\'' +
                ", shopId=" + shopId +
                ", goodsId=" + goodsId +
                ", categoryId=" + categoryId +
                ", goodsSpecId=" + goodsSpecId +
                ", ratio=" + ratio +
                ", editBoid=" + editBoid +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                ", pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", idList=" + idList +
                ", goodsName='" + goodsName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", attrDefName='" + attrDefName + '\'' +
                ", sellPrice=" + sellPrice +
                ", goodsNameLike='" + goodsNameLike + '\'' +
                ", shopNameLike='" + shopNameLike + '\'' +
                ", realName='" + realName + '\'' +
                ", tel='" + tel + '\'' +
                ", thumbnailUrl='" + thumbnailUrl + '\'' +
                ", rebateMoney=" + rebateMoney +
                ", goodsSpecAttrDmResFormList=" + goodsSpecAttrDmResFormList +
                ", shopAreaFullName='" + shopAreaFullName + '\'' +
                ", currStock='" + currStock + '\'' +
                ", stockUnitTxt='" + stockUnitTxt + '\'' +
                ", goodsSpecTxt='" + goodsSpecTxt+ '\'' +
                '}';
    }
}