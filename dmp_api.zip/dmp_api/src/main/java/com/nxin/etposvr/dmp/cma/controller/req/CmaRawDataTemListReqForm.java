package com.nxin.etposvr.dmp.cma.controller.req;

import java.util.List;

public class CmaRawDataTemListReqForm {

    private Byte systemId;

    private List<CmaRawDataTemReqForm> list;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<CmaRawDataTemReqForm> getList() {
        return list;
    }

    public void setList(List<CmaRawDataTemReqForm> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "CmaRawDataTemListReqForm{" +
                "list=" + list +
                '}';
    }
}
