package com.nxin.etposvr.dm.report.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.math.BigDecimal;

public class RemindRecordDmReqForm extends WebPageParam {
    /**
     * 名称
     */
    private String name;

    /**
     * 数量
     */
    private BigDecimal num;

    private Byte systemId;

    /**
     * 面积
     */
    private BigDecimal areaSize;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getNum() {
        return num;
    }

    public void setNum(BigDecimal num) {
        this.num = num;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
    }
}
