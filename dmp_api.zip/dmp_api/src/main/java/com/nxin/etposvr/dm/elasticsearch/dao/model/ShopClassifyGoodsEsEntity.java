package com.nxin.etposvr.dm.elasticsearch.dao.model;

public class ShopClassifyGoodsEsEntity {

    private Long shopClassifyId;

    private String shopClassifyName;

    private Long shopClassifyParentId;

    public Long getShopClassifyParentId() {
        return shopClassifyParentId;
    }

    public void setShopClassifyParentId(Long shopClassifyParentId) {
        this.shopClassifyParentId = shopClassifyParentId;
    }

    public Long getShopClassifyId() {
        return shopClassifyId;
    }

    public void setShopClassifyId(Long shopClassifyId) {
        this.shopClassifyId = shopClassifyId;
    }

    public String getShopClassifyName() {
        return shopClassifyName;
    }

    public void setShopClassifyName(String shopClassifyName) {
        this.shopClassifyName = shopClassifyName;
    }
}
