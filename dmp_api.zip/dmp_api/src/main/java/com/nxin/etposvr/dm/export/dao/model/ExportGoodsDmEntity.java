package com.nxin.etposvr.dm.export.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class ExportGoodsDmEntity {
    private String categoryAxisLike;

    private Long id;

    private String nameLike;

    private Date onTimeDateEnd;

    private Date onTimeDateStart;

    private List<String> statusList;

    private String name;

    private String shopName;

    private String stockUnitTxt;

    private BigDecimal sellPrice;

    private String numUnitTxt;

    private BigDecimal currStock;

    private String statusCn;

    private Date onTime;

    private String categoryName;

    private String dictId;

    private Byte systemId;

    public String getDictId() {
        return dictId;
    }

    public void setDictId(String dictId) {
        this.dictId = dictId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameLike() {
        return nameLike;
    }

    public void setNameLike(String nameLike) {
        this.nameLike = nameLike;
    }

    public Date getOnTimeDateEnd() {
        return onTimeDateEnd;
    }

    public void setOnTimeDateEnd(Date onTimeDateEnd) {
        this.onTimeDateEnd = onTimeDateEnd;
    }

    public Date getOnTimeDateStart() {
        return onTimeDateStart;
    }

    public void setOnTimeDateStart(Date onTimeDateStart) {
        this.onTimeDateStart = onTimeDateStart;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getStockUnitTxt() {
        return stockUnitTxt;
    }

    public void setStockUnitTxt(String stockUnitTxt) {
        this.stockUnitTxt = stockUnitTxt;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getNumUnitTxt() {
        return numUnitTxt;
    }

    public void setNumUnitTxt(String numUnitTxt) {
        this.numUnitTxt = numUnitTxt;
    }

    public BigDecimal getCurrStock() {
        return currStock;
    }

    public void setCurrStock(BigDecimal currStock) {
        this.currStock = currStock;
    }

    public String getStatusCn() {
        return statusCn;
    }

    public void setStatusCn(String statusCn) {
        this.statusCn = statusCn;
    }

    public Date getOnTime() {
        return onTime;
    }

    public void setOnTime(Date onTime) {
        this.onTime = onTime;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
