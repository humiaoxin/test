package com.nxin.etposvr.dmp.cma.dao.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Title cma_raw_data_tem表的实体类
 * @Description 气温原始数据
 * @version 1.0
 * @Author System
 * @Date 2020-05-16 14:15:46
 */
public class CmaRawDataTemExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    /**
     *  构造查询条件:cma_raw_data_tem
     */
    public CmaRawDataTemExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *  设置排序字段:cma_raw_data_tem
     * @param orderByClause 排序字段
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *  获取排序字段:cma_raw_data_tem
     * @return String
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *  设置过滤重复数据:cma_raw_data_tem
     * @param distinct 是否过滤重复数据
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *  是否过滤重复数据:cma_raw_data_tem
     * @return boolean
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *  获取当前的查询条件实例:cma_raw_data_tem
     * @return List<Criteria>
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     *  增加的查询条件,用于构建或者查询:cma_raw_data_tem
     * @param criteria 过滤条件实例
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *  创建一个新的查询条件:cma_raw_data_tem
     * @return Criteria
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *  创建一个查询条件:cma_raw_data_tem
     * @return Criteria
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *  内部构建查询条件对象:cma_raw_data_tem
     * @return Criteria
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *  清除查询条件:cma_raw_data_tem
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * @Title cma_raw_data_tem表的实体类
     * @Description 气温原始数据
     * @version 1.0
     * @Author System
     * @Date 2020-05-16 14:15:46
     */
    protected abstract static class AbstractGeneratedCriteria {
        protected List<Criterion> criteria;

        protected AbstractGeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("type like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("type not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andSiteIdIsNull() {
            addCriterion("site_id is null");
            return (Criteria) this;
        }

        public Criteria andSiteIdIsNotNull() {
            addCriterion("site_id is not null");
            return (Criteria) this;
        }

        public Criteria andSiteIdEqualTo(Integer value) {
            addCriterion("site_id =", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdNotEqualTo(Integer value) {
            addCriterion("site_id <>", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdGreaterThan(Integer value) {
            addCriterion("site_id >", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("site_id >=", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdLessThan(Integer value) {
            addCriterion("site_id <", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdLessThanOrEqualTo(Integer value) {
            addCriterion("site_id <=", value, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdIn(List<Integer> values) {
            addCriterion("site_id in", values, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdNotIn(List<Integer> values) {
            addCriterion("site_id not in", values, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdBetween(Integer value1, Integer value2) {
            addCriterion("site_id between", value1, value2, "siteId");
            return (Criteria) this;
        }

        public Criteria andSiteIdNotBetween(Integer value1, Integer value2) {
            addCriterion("site_id not between", value1, value2, "siteId");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNull() {
            addCriterion("latitude is null");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNotNull() {
            addCriterion("latitude is not null");
            return (Criteria) this;
        }

        public Criteria andLatitudeEqualTo(Integer value) {
            addCriterion("latitude =", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotEqualTo(Integer value) {
            addCriterion("latitude <>", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThan(Integer value) {
            addCriterion("latitude >", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThanOrEqualTo(Integer value) {
            addCriterion("latitude >=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThan(Integer value) {
            addCriterion("latitude <", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThanOrEqualTo(Integer value) {
            addCriterion("latitude <=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIn(List<Integer> values) {
            addCriterion("latitude in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotIn(List<Integer> values) {
            addCriterion("latitude not in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeBetween(Integer value1, Integer value2) {
            addCriterion("latitude between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotBetween(Integer value1, Integer value2) {
            addCriterion("latitude not between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeIsNull() {
            addCriterion("longtitude is null");
            return (Criteria) this;
        }

        public Criteria andLongtitudeIsNotNull() {
            addCriterion("longtitude is not null");
            return (Criteria) this;
        }

        public Criteria andLongtitudeEqualTo(Integer value) {
            addCriterion("longtitude =", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeNotEqualTo(Integer value) {
            addCriterion("longtitude <>", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeGreaterThan(Integer value) {
            addCriterion("longtitude >", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeGreaterThanOrEqualTo(Integer value) {
            addCriterion("longtitude >=", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeLessThan(Integer value) {
            addCriterion("longtitude <", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeLessThanOrEqualTo(Integer value) {
            addCriterion("longtitude <=", value, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeIn(List<Integer> values) {
            addCriterion("longtitude in", values, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeNotIn(List<Integer> values) {
            addCriterion("longtitude not in", values, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeBetween(Integer value1, Integer value2) {
            addCriterion("longtitude between", value1, value2, "longtitude");
            return (Criteria) this;
        }

        public Criteria andLongtitudeNotBetween(Integer value1, Integer value2) {
            addCriterion("longtitude not between", value1, value2, "longtitude");
            return (Criteria) this;
        }

        public Criteria andGeohashIsNull() {
            addCriterion("geohash is null");
            return (Criteria) this;
        }

        public Criteria andGeohashIsNotNull() {
            addCriterion("geohash is not null");
            return (Criteria) this;
        }

        public Criteria andGeohashEqualTo(String value) {
            addCriterion("geohash =", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashNotEqualTo(String value) {
            addCriterion("geohash <>", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashGreaterThan(String value) {
            addCriterion("geohash >", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashGreaterThanOrEqualTo(String value) {
            addCriterion("geohash >=", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashLessThan(String value) {
            addCriterion("geohash <", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashLessThanOrEqualTo(String value) {
            addCriterion("geohash <=", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashLike(String value) {
            addCriterion("geohash like", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashNotLike(String value) {
            addCriterion("geohash not like", value, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashIn(List<String> values) {
            addCriterion("geohash in", values, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashNotIn(List<String> values) {
            addCriterion("geohash not in", values, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashBetween(String value1, String value2) {
            addCriterion("geohash between", value1, value2, "geohash");
            return (Criteria) this;
        }

        public Criteria andGeohashNotBetween(String value1, String value2) {
            addCriterion("geohash not between", value1, value2, "geohash");
            return (Criteria) this;
        }

        public Criteria andAltitudeIsNull() {
            addCriterion("altitude is null");
            return (Criteria) this;
        }

        public Criteria andAltitudeIsNotNull() {
            addCriterion("altitude is not null");
            return (Criteria) this;
        }

        public Criteria andAltitudeEqualTo(Integer value) {
            addCriterion("altitude =", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeNotEqualTo(Integer value) {
            addCriterion("altitude <>", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeGreaterThan(Integer value) {
            addCriterion("altitude >", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeGreaterThanOrEqualTo(Integer value) {
            addCriterion("altitude >=", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeLessThan(Integer value) {
            addCriterion("altitude <", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeLessThanOrEqualTo(Integer value) {
            addCriterion("altitude <=", value, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeIn(List<Integer> values) {
            addCriterion("altitude in", values, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeNotIn(List<Integer> values) {
            addCriterion("altitude not in", values, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeBetween(Integer value1, Integer value2) {
            addCriterion("altitude between", value1, value2, "altitude");
            return (Criteria) this;
        }

        public Criteria andAltitudeNotBetween(Integer value1, Integer value2) {
            addCriterion("altitude not between", value1, value2, "altitude");
            return (Criteria) this;
        }

        public Criteria andYearIsNull() {
            addCriterion("year is null");
            return (Criteria) this;
        }

        public Criteria andYearIsNotNull() {
            addCriterion("year is not null");
            return (Criteria) this;
        }

        public Criteria andYearEqualTo(Integer value) {
            addCriterion("year =", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotEqualTo(Integer value) {
            addCriterion("year <>", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearGreaterThan(Integer value) {
            addCriterion("year >", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearGreaterThanOrEqualTo(Integer value) {
            addCriterion("year >=", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearLessThan(Integer value) {
            addCriterion("year <", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearLessThanOrEqualTo(Integer value) {
            addCriterion("year <=", value, "year");
            return (Criteria) this;
        }

        public Criteria andYearIn(List<Integer> values) {
            addCriterion("year in", values, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotIn(List<Integer> values) {
            addCriterion("year not in", values, "year");
            return (Criteria) this;
        }

        public Criteria andYearBetween(Integer value1, Integer value2) {
            addCriterion("year between", value1, value2, "year");
            return (Criteria) this;
        }

        public Criteria andYearNotBetween(Integer value1, Integer value2) {
            addCriterion("year not between", value1, value2, "year");
            return (Criteria) this;
        }

        public Criteria andMonthIsNull() {
            addCriterion("month is null");
            return (Criteria) this;
        }

        public Criteria andMonthIsNotNull() {
            addCriterion("month is not null");
            return (Criteria) this;
        }

        public Criteria andMonthEqualTo(Integer value) {
            addCriterion("month =", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotEqualTo(Integer value) {
            addCriterion("month <>", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthGreaterThan(Integer value) {
            addCriterion("month >", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthGreaterThanOrEqualTo(Integer value) {
            addCriterion("month >=", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthLessThan(Integer value) {
            addCriterion("month <", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthLessThanOrEqualTo(Integer value) {
            addCriterion("month <=", value, "month");
            return (Criteria) this;
        }

        public Criteria andMonthIn(List<Integer> values) {
            addCriterion("month in", values, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotIn(List<Integer> values) {
            addCriterion("month not in", values, "month");
            return (Criteria) this;
        }

        public Criteria andMonthBetween(Integer value1, Integer value2) {
            addCriterion("month between", value1, value2, "month");
            return (Criteria) this;
        }

        public Criteria andMonthNotBetween(Integer value1, Integer value2) {
            addCriterion("month not between", value1, value2, "month");
            return (Criteria) this;
        }

        public Criteria andDayIsNull() {
            addCriterion("day is null");
            return (Criteria) this;
        }

        public Criteria andDayIsNotNull() {
            addCriterion("day is not null");
            return (Criteria) this;
        }

        public Criteria andDayEqualTo(Integer value) {
            addCriterion("day =", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotEqualTo(Integer value) {
            addCriterion("day <>", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThan(Integer value) {
            addCriterion("day >", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayGreaterThanOrEqualTo(Integer value) {
            addCriterion("day >=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThan(Integer value) {
            addCriterion("day <", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayLessThanOrEqualTo(Integer value) {
            addCriterion("day <=", value, "day");
            return (Criteria) this;
        }

        public Criteria andDayIn(List<Integer> values) {
            addCriterion("day in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotIn(List<Integer> values) {
            addCriterion("day not in", values, "day");
            return (Criteria) this;
        }

        public Criteria andDayBetween(Integer value1, Integer value2) {
            addCriterion("day between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andDayNotBetween(Integer value1, Integer value2) {
            addCriterion("day not between", value1, value2, "day");
            return (Criteria) this;
        }

        public Criteria andAverageTemIsNull() {
            addCriterion("average_tem is null");
            return (Criteria) this;
        }

        public Criteria andAverageTemIsNotNull() {
            addCriterion("average_tem is not null");
            return (Criteria) this;
        }

        public Criteria andAverageTemEqualTo(Integer value) {
            addCriterion("average_tem =", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemNotEqualTo(Integer value) {
            addCriterion("average_tem <>", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemGreaterThan(Integer value) {
            addCriterion("average_tem >", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemGreaterThanOrEqualTo(Integer value) {
            addCriterion("average_tem >=", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemLessThan(Integer value) {
            addCriterion("average_tem <", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemLessThanOrEqualTo(Integer value) {
            addCriterion("average_tem <=", value, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemIn(List<Integer> values) {
            addCriterion("average_tem in", values, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemNotIn(List<Integer> values) {
            addCriterion("average_tem not in", values, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemBetween(Integer value1, Integer value2) {
            addCriterion("average_tem between", value1, value2, "averageTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemNotBetween(Integer value1, Integer value2) {
            addCriterion("average_tem not between", value1, value2, "averageTem");
            return (Criteria) this;
        }

        public Criteria andHiTemIsNull() {
            addCriterion("hi_tem is null");
            return (Criteria) this;
        }

        public Criteria andHiTemIsNotNull() {
            addCriterion("hi_tem is not null");
            return (Criteria) this;
        }

        public Criteria andHiTemEqualTo(Integer value) {
            addCriterion("hi_tem =", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemNotEqualTo(Integer value) {
            addCriterion("hi_tem <>", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemGreaterThan(Integer value) {
            addCriterion("hi_tem >", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemGreaterThanOrEqualTo(Integer value) {
            addCriterion("hi_tem >=", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemLessThan(Integer value) {
            addCriterion("hi_tem <", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemLessThanOrEqualTo(Integer value) {
            addCriterion("hi_tem <=", value, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemIn(List<Integer> values) {
            addCriterion("hi_tem in", values, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemNotIn(List<Integer> values) {
            addCriterion("hi_tem not in", values, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemBetween(Integer value1, Integer value2) {
            addCriterion("hi_tem between", value1, value2, "hiTem");
            return (Criteria) this;
        }

        public Criteria andHiTemNotBetween(Integer value1, Integer value2) {
            addCriterion("hi_tem not between", value1, value2, "hiTem");
            return (Criteria) this;
        }

        public Criteria andLowTemIsNull() {
            addCriterion("low_tem is null");
            return (Criteria) this;
        }

        public Criteria andLowTemIsNotNull() {
            addCriterion("low_tem is not null");
            return (Criteria) this;
        }

        public Criteria andLowTemEqualTo(Integer value) {
            addCriterion("low_tem =", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemNotEqualTo(Integer value) {
            addCriterion("low_tem <>", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemGreaterThan(Integer value) {
            addCriterion("low_tem >", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemGreaterThanOrEqualTo(Integer value) {
            addCriterion("low_tem >=", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemLessThan(Integer value) {
            addCriterion("low_tem <", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemLessThanOrEqualTo(Integer value) {
            addCriterion("low_tem <=", value, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemIn(List<Integer> values) {
            addCriterion("low_tem in", values, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemNotIn(List<Integer> values) {
            addCriterion("low_tem not in", values, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemBetween(Integer value1, Integer value2) {
            addCriterion("low_tem between", value1, value2, "lowTem");
            return (Criteria) this;
        }

        public Criteria andLowTemNotBetween(Integer value1, Integer value2) {
            addCriterion("low_tem not between", value1, value2, "lowTem");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeIsNull() {
            addCriterion("average_tem_code is null");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeIsNotNull() {
            addCriterion("average_tem_code is not null");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeEqualTo(Integer value) {
            addCriterion("average_tem_code =", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeNotEqualTo(Integer value) {
            addCriterion("average_tem_code <>", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeGreaterThan(Integer value) {
            addCriterion("average_tem_code >", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeGreaterThanOrEqualTo(Integer value) {
            addCriterion("average_tem_code >=", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeLessThan(Integer value) {
            addCriterion("average_tem_code <", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeLessThanOrEqualTo(Integer value) {
            addCriterion("average_tem_code <=", value, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeIn(List<Integer> values) {
            addCriterion("average_tem_code in", values, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeNotIn(List<Integer> values) {
            addCriterion("average_tem_code not in", values, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeBetween(Integer value1, Integer value2) {
            addCriterion("average_tem_code between", value1, value2, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andAverageTemCodeNotBetween(Integer value1, Integer value2) {
            addCriterion("average_tem_code not between", value1, value2, "averageTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeIsNull() {
            addCriterion("hi_tem_code is null");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeIsNotNull() {
            addCriterion("hi_tem_code is not null");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeEqualTo(Integer value) {
            addCriterion("hi_tem_code =", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeNotEqualTo(Integer value) {
            addCriterion("hi_tem_code <>", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeGreaterThan(Integer value) {
            addCriterion("hi_tem_code >", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeGreaterThanOrEqualTo(Integer value) {
            addCriterion("hi_tem_code >=", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeLessThan(Integer value) {
            addCriterion("hi_tem_code <", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeLessThanOrEqualTo(Integer value) {
            addCriterion("hi_tem_code <=", value, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeIn(List<Integer> values) {
            addCriterion("hi_tem_code in", values, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeNotIn(List<Integer> values) {
            addCriterion("hi_tem_code not in", values, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeBetween(Integer value1, Integer value2) {
            addCriterion("hi_tem_code between", value1, value2, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andHiTemCodeNotBetween(Integer value1, Integer value2) {
            addCriterion("hi_tem_code not between", value1, value2, "hiTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeIsNull() {
            addCriterion("low_tem_code is null");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeIsNotNull() {
            addCriterion("low_tem_code is not null");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeEqualTo(Integer value) {
            addCriterion("low_tem_code =", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeNotEqualTo(Integer value) {
            addCriterion("low_tem_code <>", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeGreaterThan(Integer value) {
            addCriterion("low_tem_code >", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeGreaterThanOrEqualTo(Integer value) {
            addCriterion("low_tem_code >=", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeLessThan(Integer value) {
            addCriterion("low_tem_code <", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeLessThanOrEqualTo(Integer value) {
            addCriterion("low_tem_code <=", value, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeIn(List<Integer> values) {
            addCriterion("low_tem_code in", values, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeNotIn(List<Integer> values) {
            addCriterion("low_tem_code not in", values, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeBetween(Integer value1, Integer value2) {
            addCriterion("low_tem_code between", value1, value2, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andLowTemCodeNotBetween(Integer value1, Integer value2) {
            addCriterion("low_tem_code not between", value1, value2, "lowTemCode");
            return (Criteria) this;
        }

        public Criteria andSystemIdIsNull() {
            addCriterion("system_id is null");
            return (Criteria) this;
        }

        public Criteria andSystemIdIsNotNull() {
            addCriterion("system_id is not null");
            return (Criteria) this;
        }

        public Criteria andSystemIdEqualTo(Byte value) {
            addCriterion("system_id =", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotEqualTo(Byte value) {
            addCriterion("system_id <>", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdGreaterThan(Byte value) {
            addCriterion("system_id >", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdGreaterThanOrEqualTo(Byte value) {
            addCriterion("system_id >=", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdLessThan(Byte value) {
            addCriterion("system_id <", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdLessThanOrEqualTo(Byte value) {
            addCriterion("system_id <=", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdIn(List<Byte> values) {
            addCriterion("system_id in", values, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotIn(List<Byte> values) {
            addCriterion("system_id not in", values, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdBetween(Byte value1, Byte value2) {
            addCriterion("system_id between", value1, value2, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotBetween(Byte value1, Byte value2) {
            addCriterion("system_id not between", value1, value2, "systemId");
            return (Criteria) this;
        }

        public Criteria andDataRemarkIsNull() {
            addCriterion("data_remark is null");
            return (Criteria) this;
        }

        public Criteria andDataRemarkIsNotNull() {
            addCriterion("data_remark is not null");
            return (Criteria) this;
        }

        public Criteria andDataRemarkEqualTo(String value) {
            addCriterion("data_remark =", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkNotEqualTo(String value) {
            addCriterion("data_remark <>", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkGreaterThan(String value) {
            addCriterion("data_remark >", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("data_remark >=", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkLessThan(String value) {
            addCriterion("data_remark <", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkLessThanOrEqualTo(String value) {
            addCriterion("data_remark <=", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkLike(String value) {
            addCriterion("data_remark like", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkNotLike(String value) {
            addCriterion("data_remark not like", value, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkIn(List<String> values) {
            addCriterion("data_remark in", values, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkNotIn(List<String> values) {
            addCriterion("data_remark not in", values, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkBetween(String value1, String value2) {
            addCriterion("data_remark between", value1, value2, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andDataRemarkNotBetween(String value1, String value2) {
            addCriterion("data_remark not between", value1, value2, "dataRemark");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkIsNull() {
            addCriterion("version_remark is null");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkIsNotNull() {
            addCriterion("version_remark is not null");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkEqualTo(String value) {
            addCriterion("version_remark =", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkNotEqualTo(String value) {
            addCriterion("version_remark <>", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkGreaterThan(String value) {
            addCriterion("version_remark >", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("version_remark >=", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkLessThan(String value) {
            addCriterion("version_remark <", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkLessThanOrEqualTo(String value) {
            addCriterion("version_remark <=", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkLike(String value) {
            addCriterion("version_remark like", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkNotLike(String value) {
            addCriterion("version_remark not like", value, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkIn(List<String> values) {
            addCriterion("version_remark in", values, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkNotIn(List<String> values) {
            addCriterion("version_remark not in", values, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkBetween(String value1, String value2) {
            addCriterion("version_remark between", value1, value2, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVersionRemarkNotBetween(String value1, String value2) {
            addCriterion("version_remark not between", value1, value2, "versionRemark");
            return (Criteria) this;
        }

        public Criteria andVnoIsNull() {
            addCriterion("vno is null");
            return (Criteria) this;
        }

        public Criteria andVnoIsNotNull() {
            addCriterion("vno is not null");
            return (Criteria) this;
        }

        public Criteria andVnoEqualTo(Date value) {
            addCriterion("vno =", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoNotEqualTo(Date value) {
            addCriterion("vno <>", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoGreaterThan(Date value) {
            addCriterion("vno >", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoGreaterThanOrEqualTo(Date value) {
            addCriterion("vno >=", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoLessThan(Date value) {
            addCriterion("vno <", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoLessThanOrEqualTo(Date value) {
            addCriterion("vno <=", value, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoIn(List<Date> values) {
            addCriterion("vno in", values, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoNotIn(List<Date> values) {
            addCriterion("vno not in", values, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoBetween(Date value1, Date value2) {
            addCriterion("vno between", value1, value2, "vno");
            return (Criteria) this;
        }

        public Criteria andVnoNotBetween(Date value1, Date value2) {
            addCriterion("vno not between", value1, value2, "vno");
            return (Criteria) this;
        }

        public Criteria andIsEnabledIsNull() {
            addCriterion("is_enabled is null");
            return (Criteria) this;
        }

        public Criteria andIsEnabledIsNotNull() {
            addCriterion("is_enabled is not null");
            return (Criteria) this;
        }

        public Criteria andIsEnabledEqualTo(Byte value) {
            addCriterion("is_enabled =", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledNotEqualTo(Byte value) {
            addCriterion("is_enabled <>", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledGreaterThan(Byte value) {
            addCriterion("is_enabled >", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledGreaterThanOrEqualTo(Byte value) {
            addCriterion("is_enabled >=", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledLessThan(Byte value) {
            addCriterion("is_enabled <", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledLessThanOrEqualTo(Byte value) {
            addCriterion("is_enabled <=", value, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledIn(List<Byte> values) {
            addCriterion("is_enabled in", values, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledNotIn(List<Byte> values) {
            addCriterion("is_enabled not in", values, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledBetween(Byte value1, Byte value2) {
            addCriterion("is_enabled between", value1, value2, "isEnabled");
            return (Criteria) this;
        }

        public Criteria andIsEnabledNotBetween(Byte value1, Byte value2) {
            addCriterion("is_enabled not between", value1, value2, "isEnabled");
            return (Criteria) this;
        }
    }

    /**
     * @Title cma_raw_data_tem表的实体类
     * @Description 气温原始数据
     * @version 1.0
     * @Author System
     * @Date 2020-05-16 14:15:46
     */
    public static class Criteria extends AbstractGeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * @Title cma_raw_data_tem表的实体类
     * @Description 气温原始数据
     * @version 1.0
     * @Author System
     * @Date 2020-05-16 14:15:46
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}