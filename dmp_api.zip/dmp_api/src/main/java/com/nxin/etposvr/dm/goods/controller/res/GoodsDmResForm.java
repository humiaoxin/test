package com.nxin.etposvr.dm.goods.controller.res;

import java.math.BigDecimal;

/**
 * 商品返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class GoodsDmResForm {

    /**品类名称*/
    private String categoryName;
    /**单价*/
    private BigDecimal sellPrice;
    /**库存*/
    private BigDecimal currStock;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getCurrStock() {
        return currStock;
    }

    public void setCurrStock(BigDecimal currStock) {
        this.currStock = currStock;
    }
}
