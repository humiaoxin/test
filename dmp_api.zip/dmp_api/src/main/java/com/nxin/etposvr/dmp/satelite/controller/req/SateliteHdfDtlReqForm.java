package com.nxin.etposvr.dmp.satelite.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 卫星数据明细
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2020/1/8 10:26
 */
public class SateliteHdfDtlReqForm extends WebPageParam {

    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "数据文件ID", example = "1")
    private Long hdfId;

    @ApiModelProperty(value = "经度", example = "1")
    private String longtitude;

    @ApiModelProperty(value = "纬度", example = "1")
    private String latitude;

    @ApiModelProperty(value = "数值", example = "1")
    private BigDecimal val;

    @ApiModelProperty(value = "所属系统", example = "1")
    private Byte systemId;

    @ApiModelProperty(value = "是否可用 1可用 0不可用", example = "1")
    private Byte isEnabled;

    /**
     * @Fields lonlatHash 经纬度HASH
     */
    private String lonlatHash;

    private Long dataId;
    /**
     * 数据文件开始时间
     */
    private Date hdfInfoRecDateStart;
    /**
     * 数据文件结束时间
     */
    private Date hdfInfoRecDateEnd;
    /**
     * 数据文件类型
     */
    private String hdfInfoHdfType;
    /**
     * @Fields isChina 是否中国
     */
    private Boolean isChina;

    private List<SateliteHdfDtlReqForm> sateliteHdfDtlReqFormList;

    public List<SateliteHdfDtlReqForm> getSateliteHdfDtlReqFormList() {
        return sateliteHdfDtlReqFormList;
    }

    public void setSateliteHdfDtlReqFormList(List<SateliteHdfDtlReqForm> sateliteHdfDtlReqFormList) {
        this.sateliteHdfDtlReqFormList = sateliteHdfDtlReqFormList;
    }

    public Long getDataId() {
        return dataId;
    }

    public void setDataId(Long dataId) {
        this.dataId = dataId;
    }

    public String getLonlatHash() {
        return lonlatHash;
    }

    public void setLonlatHash(String lonlatHash) {
        this.lonlatHash = lonlatHash;
    }

    public Boolean getChina() {
        return isChina;
    }

    public void setChina(Boolean china) {
        isChina = china;
    }

    public Date getHdfInfoRecDateStart() {
        return hdfInfoRecDateStart;
    }

    public void setHdfInfoRecDateStart(Date hdfInfoRecDateStart) {
        this.hdfInfoRecDateStart = hdfInfoRecDateStart;
    }

    public Date getHdfInfoRecDateEnd() {
        return hdfInfoRecDateEnd;
    }

    public void setHdfInfoRecDateEnd(Date hdfInfoRecDateEnd) {
        this.hdfInfoRecDateEnd = hdfInfoRecDateEnd;
    }

    public String getHdfInfoHdfType() {
        return hdfInfoHdfType;
    }

    public void setHdfInfoHdfType(String hdfInfoHdfType) {
        this.hdfInfoHdfType = hdfInfoHdfType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHdfId() {
        return hdfId;
    }

    public void setHdfId(Long hdfId) {
        this.hdfId = hdfId;
    }

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getVal() {
        return val;
    }

    public void setVal(BigDecimal val) {
        this.val = val;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        return "SateliteHdfDtlReqForm{" +
                "id=" + id +
                ", hdfId=" + hdfId +
                ", longtitude='" + longtitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", val=" + val +
                ", systemId=" + systemId +
                ", isEnabled=" + isEnabled +
                ", hdfInfoRecDateStart=" + hdfInfoRecDateStart +
                ", hdfInfoRecDateEnd=" + hdfInfoRecDateEnd +
                ", hdfInfoHdfType='" + hdfInfoHdfType + '\'' +
                '}';
    }
}
