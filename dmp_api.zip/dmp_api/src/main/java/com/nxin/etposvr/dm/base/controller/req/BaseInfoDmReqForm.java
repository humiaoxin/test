package com.nxin.etposvr.dm.base.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 大数据土地reqForm
 *
 * @author TianShiWei
 * @since: 2019/12/13 14:33
 * @version: v_1.0.1
 */
public class BaseInfoDmReqForm extends WebPageParam {

    private Long id;

    /**
     * 统计类型DAY-按日统计MON-按月统计YEAR-按年统计
     */
    private String stateType;

    /**
     * 天数范围
     */
    private Integer range;

    /**
     * 系统id
     */
    private Byte systemId;

    private Long boId;

    private String timeStart;

    private String timeEnd;

    private Long rangeId;

    private String uniqueId;

    private String categoryAxisLike;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public Long getRangeId() {
        return rangeId;
    }

    public void setRangeId(Long rangeId) {
        this.rangeId = rangeId;
    }

    public String getStateType() {
        return stateType;
    }

    public void setStateType(String stateType) {
        this.stateType = stateType;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "BaseInfoDmReqForm{" +
                "stateType='" + stateType + '\'' +
                ", range=" + range +
                ", systemId=" + systemId +
                '}';
    }
}
