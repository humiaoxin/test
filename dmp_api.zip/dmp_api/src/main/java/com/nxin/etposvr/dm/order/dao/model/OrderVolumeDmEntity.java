package com.nxin.etposvr.dm.order.dao.model;

import java.util.List;

/**
 * 成交量实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class OrderVolumeDmEntity {

    private String dates;
    private List<OrderInfoDmEntity> orderInfoDmEntityList;

    public OrderVolumeDmEntity(String dates, List<OrderInfoDmEntity> orderInfoDmEntityList) {
        this.dates = dates;
        this.orderInfoDmEntityList = orderInfoDmEntityList;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public List<OrderInfoDmEntity> getOrderInfoDmEntityList() {
        return orderInfoDmEntityList;
    }

    public void setOrderInfoDmEntityList(List<OrderInfoDmEntity> orderInfoDmEntityList) {
        this.orderInfoDmEntityList = orderInfoDmEntityList;
    }
}
