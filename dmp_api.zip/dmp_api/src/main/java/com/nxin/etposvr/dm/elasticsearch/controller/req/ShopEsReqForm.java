package com.nxin.etposvr.dm.elasticsearch.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup101th;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/9 21:29
 */
public class ShopEsReqForm extends WebPageParam {

    @ApiModelProperty(value = "店铺ID", example = "11", dataType = "String")
    @NotNull(message = "000001|店铺ID", groups = {VldGroup1th.class, VldGroup101th.class, VldGroup2th.class})
    public String id;

    @ApiModelProperty(value = "店铺名称", example = "11", dataType = "String")
    @NotNull(message = "000001|店铺名称", groups = {VldGroup1th.class, VldGroup101th.class})
    public String name;

    @ApiModelProperty(value = "系统ID", example = "3", dataType = "Byte")
    @NotNull(message = "000001|系统ID", groups = {VldGroup1th.class, VldGroup101th.class})
    private Byte systemId;
    @ApiModelProperty(value = "经营范围", example = "3", dataType = "String")
    public String busiScopeCode;

    @ApiModelProperty(value = "一级地区id", example = "3", dataType = "String")
    public String oneAreaId;
    @ApiModelProperty(value = "二级地区id", example = "3", dataType = "String")
    public String twoAreaId;
    @ApiModelProperty(value = "地区id", example = "3", dataType = "String")
    public String areaId;

    private String areaAxis;

    private String areaFullName;

    private String busiScopeName;

    @Valid
    public List<ShopEsReqForm> shopEsReqFormList;

    public Integer isPage = 0;

    @Valid
    public List<JestClientReqForm> jestClientReqFormList;
    
    /** 商品消息处理状态 （1.添加， 2.删除） */
    private String mqStatus;

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getBusiScopeName() {
        return busiScopeName;
    }

    public void setBusiScopeName(String busiScopeName) {
        this.busiScopeName = busiScopeName;
    }

    public String getBusiScopeCode() {
        return busiScopeCode;
    }

    public void setBusiScopeCode(String busiScopeCode) {
        this.busiScopeCode = busiScopeCode;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<ShopEsReqForm> getShopEsReqFormList() {
        return shopEsReqFormList;
    }

    public void setShopEsReqFormList(List<ShopEsReqForm> shopEsReqFormList) {
        this.shopEsReqFormList = shopEsReqFormList;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public List<JestClientReqForm> getJestClientReqFormList() {
        return jestClientReqFormList;
    }

    public void setJestClientReqFormList(List<JestClientReqForm> jestClientReqFormList) {
        this.jestClientReqFormList = jestClientReqFormList;
    }

	public String getMqStatus() {
		return mqStatus;
	}

	public void setMqStatus(String mqStatus) {
		this.mqStatus = mqStatus;
	}
}
