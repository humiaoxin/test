package com.nxin.etposvr.dm.base.dao.model;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/14 16:59
 */
public class BaseLivestockDmEntity {
    private Byte systemId;

    private String categoryAxis;

    private String areaAxisLike;

    private Double ztRate;

    private Double zsRate;

    private String status;


    private Long totalBreedNum;

    private Long totalBrithNum;

    private Long totalManuNum;

    private Long zsTotal;

    private Long psTotal;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getTotalBrithNum() {
        return totalBrithNum;
    }

    public void setTotalBrithNum(Long totalBrithNum) {
        this.totalBrithNum = totalBrithNum;
    }

    public Long getZsTotal() {
        return zsTotal;
    }

    public void setZsTotal(Long zsTotal) {
        this.zsTotal = zsTotal;
    }

    public Long getPsTotal() {
        return psTotal;
    }

    public void setPsTotal(Long psTotal) {
        this.psTotal = psTotal;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Double getZtRate() {
        return ztRate;
    }

    public void setZtRate(Double ztRate) {
        this.ztRate = ztRate;
    }

    public Double getZsRate() {
        return zsRate;
    }

    public void setZsRate(Double zsRate) {
        this.zsRate = zsRate;
    }

    public Long getTotalBreedNum() {
        return totalBreedNum;
    }

    public void setTotalBreedNum(Long totalBreedNum) {
        this.totalBreedNum = totalBreedNum;
    }

    public Long getTotalManuNum() {
        return totalManuNum;
    }

    public void setTotalManuNum(Long totalManuNum) {
        this.totalManuNum = totalManuNum;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("BaseLivestockDmEntity{");
        sb.append("systemId=").append(systemId);
        sb.append(", categoryAxis='").append(categoryAxis).append('\'');
        sb.append(", areaAxisLike='").append(areaAxisLike).append('\'');
        sb.append(", ztRate=").append(ztRate);
        sb.append(", zsRate=").append(zsRate);
        sb.append(", status='").append(status).append('\'');
        sb.append(", totalBreedNum=").append(totalBreedNum);
        sb.append(", totalBrithNum=").append(totalBrithNum);
        sb.append(", totalManuNum=").append(totalManuNum);
        sb.append(", zsTotal=").append(zsTotal);
        sb.append(", psTotal=").append(psTotal);
        sb.append('}');
        return sb.toString();
    }
}
