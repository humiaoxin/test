package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;

/**
 * 品类交易实体
 *
 * @author ZhangXu
 * @since 2020.1.7
 */
public class CategoryTradingDmEntity {

    /**
     * 品类交易额
     */
    private BigDecimal categoryMoney;
    /**
     * 品类名称
     */
    private String categoryName;
    /**
     * 占比
     */
    private BigDecimal percent;
    /**
     * 品类全称
     *
     * @author lpp
     * @date 2020/4/20 15:51
     */
    private String categoryFullName;

    public String getCategoryFullName() {
        return categoryFullName;
    }

    public void setCategoryFullName(String categoryFullName) {
        this.categoryFullName = categoryFullName;
    }

    public BigDecimal getCategoryMoney() {
        return categoryMoney;
    }

    public void setCategoryMoney(BigDecimal categoryMoney) {
        this.categoryMoney = categoryMoney;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getPercent() {
        return percent;
    }

    public void setPercent(BigDecimal percent) {
        this.percent = percent;
    }
}
