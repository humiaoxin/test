package com.nxin.etposvr.dm.member.controller.res;

import java.math.BigDecimal;

/**
 * @author LS
 * @date 2019/10/29
 */
public class MemberDataDmResForm {
    /**
     * 用户编号
     *
     * @author LS
     * @date 2019/10/29
     */
    private Long boId;
    /**
     * 用户类型
     *
     * @author LS
     * @date 2019/10/29
     */
    private String userType;
    /**
     * 用户昵称
     *
     * @author LS
     * @date 2019/10/29
     */
    private String userName;
    /**
     * 用户头像
     *
     * @author LS
     * @date 2019/10/29
     */
    private String headIcon;
    /**
     * 地区编号
     *
     * @author LS
     * @date 2019/10/29
     */
    private Integer areaId;
    /**
     * 地区纬度
     *
     * @author LS
     * @date 2019/10/29
     */
    private BigDecimal lat;
    /**
     * 地区经度
     *
     * @author LS
     * @date 2019/10/29
     */
    private BigDecimal lon;

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHeadIcon() {
        return headIcon;
    }

    public void setHeadIcon(String headIcon) {
        this.headIcon = headIcon;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }

    public BigDecimal getLon() {
        return lon;
    }

    public void setLon(BigDecimal lon) {
        this.lon = lon;
    }
}
