package com.nxin.etposvr.dm.elasticsearch.dao.model;

import java.util.Date;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/5/17 10:50
 */
public class CmsArticleEsEntity {


    public String id;

    public String colCode;

    public String title;

    public String listTitle;

    public String type;

    private Byte systemId;

    public String author;

    private String status;

    public Byte isTop;

    public String keywords;

    public String recmdType;

    public String sourceUrl;

    public Date createTime;

    public String areaAxises;

    public String belongType;

    public Long boId;

    public Long oprBoId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getColCode() {
        return colCode;
    }

    public void setColCode(String colCode) {
        this.colCode = colCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getListTitle() {
        return listTitle;
    }

    public void setListTitle(String listTitle) {
        this.listTitle = listTitle;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Byte getIsTop() {
        return isTop;
    }

    public void setIsTop(Byte isTop) {
        this.isTop = isTop;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getRecmdType() {
        return recmdType;
    }

    public void setRecmdType(String recmdType) {
        this.recmdType = recmdType;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getAreaAxises() {
        return areaAxises;
    }

    public void setAreaAxises(String areaAxises) {
        this.areaAxises = areaAxises;
    }

    public String getBelongType() {
        return belongType;
    }

    public void setBelongType(String belongType) {
        this.belongType = belongType;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }
}

