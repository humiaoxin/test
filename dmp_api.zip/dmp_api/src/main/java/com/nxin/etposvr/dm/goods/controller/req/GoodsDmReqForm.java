package com.nxin.etposvr.dm.goods.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup3th;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 商品请求实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class GoodsDmReqForm extends WebPageParam {

    /**状态*/
    private String status;
    /**数量*/
    private Integer count;
    private Byte systemId;
    /**品类集合*/
    private List<Long> categoryIds;

    /**
     * 地块所在纬度
     *
     * @param null
     * @return
     * @author XiaoShuai
     * @since 2020/9/1 16:26
     */
    @NotNull(message = "000001|地块所在纬度", groups = {VldGroup3th.class})
    private String latitude;

    /**
     * 地块所在经度
     *
     * @param null
     * @return
     * @author XiaoShuai
     * @since 2020/9/1 16:26
     */
    @NotNull(message = "000001|地块所在经度", groups = {VldGroup3th.class})
    private String longitude;

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
