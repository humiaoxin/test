package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatPdmgScheme;

/**
 * 方案
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:12
 * @version: v_1.0.1
 */
public class StatPdmgSchemeResForm extends StatPdmgScheme {
}
