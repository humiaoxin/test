package com.nxin.etposvr.dm.elasticsearch.dao.model;

import java.util.Date;

public class GoodsAttrEsEntity {

    private String valCode;

    private Date vno;

    private String valString;

    private Long valNumber;

    private String valDate;

    private String attrDefId;

    public String getAttrDefId() {
        return attrDefId;
    }

    public void setAttrDefId(String attrDefId) {
        this.attrDefId = attrDefId;
    }

    public String getValCode() {
        return valCode;
    }

    public void setValCode(String valCode) {
        this.valCode = valCode;
    }


    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getValString() {
        return valString;
    }

    public void setValString(String valString) {
        this.valString = valString;
    }

    public Long getValNumber() {
        return valNumber;
    }

    public void setValNumber(Long valNumber) {
        this.valNumber = valNumber;
    }

    public String getValDate() {
        return valDate;
    }

    public void setValDate(String valDate) {
        this.valDate = valDate;
    }
}
