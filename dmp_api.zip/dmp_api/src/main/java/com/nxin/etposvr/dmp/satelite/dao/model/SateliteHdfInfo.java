package com.nxin.etposvr.dmp.satelite.dao.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Title satelite_hdf_info表的实体类
 * @Description 卫星数据文件信息表
 * @version 1.0
 * @Author System
 * @Date 2020-01-08 10:05:39
 */
public class SateliteHdfInfo implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields hdfName HDF文件名，相同文件替换
     */
    private String hdfName;

    /**
     * @Fields hdfType 数据产品类型，如，TRSF_D：土壤水分日产品
     */
    private String hdfType;

    /**
     * @Fields recDate 数据日期
     */
    private Date recDate;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:satelite_hdf_info.id
     *
     * @return satelite_hdf_info.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:satelite_hdf_info.id
     *
     * @param id the value for satelite_hdf_info.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 HDF文件名，相同文件替换 字段:satelite_hdf_info.hdf_name
     *
     * @return satelite_hdf_info.hdf_name, HDF文件名，相同文件替换
     */
    public String getHdfName() {
        return hdfName;
    }

    /**
     * 设置 HDF文件名，相同文件替换 字段:satelite_hdf_info.hdf_name
     *
     * @param hdfName the value for satelite_hdf_info.hdf_name, HDF文件名，相同文件替换
     */
    public void setHdfName(String hdfName) {
        this.hdfName = hdfName == null ? null : hdfName.trim();
    }

    /**
     * 获取 数据产品类型，如，TRSF_D：土壤水分日产品 字段:satelite_hdf_info.hdf_type
     *
     * @return satelite_hdf_info.hdf_type, 数据产品类型，如，TRSF_D：土壤水分日产品
     */
    public String getHdfType() {
        return hdfType;
    }

    /**
     * 设置 数据产品类型，如，TRSF_D：土壤水分日产品 字段:satelite_hdf_info.hdf_type
     *
     * @param hdfType the value for satelite_hdf_info.hdf_type, 数据产品类型，如，TRSF_D：土壤水分日产品
     */
    public void setHdfType(String hdfType) {
        this.hdfType = hdfType == null ? null : hdfType.trim();
    }

    /**
     * 获取 数据日期 字段:satelite_hdf_info.rec_date
     *
     * @return satelite_hdf_info.rec_date, 数据日期
     */
    public Date getRecDate() {
        return recDate;
    }

    /**
     * 设置 数据日期 字段:satelite_hdf_info.rec_date
     *
     * @param recDate the value for satelite_hdf_info.rec_date, 数据日期
     */
    public void setRecDate(Date recDate) {
        this.recDate = recDate;
    }

    /**
     * 获取 所属系统 字段:satelite_hdf_info.system_id
     *
     * @return satelite_hdf_info.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:satelite_hdf_info.system_id
     *
     * @param systemId the value for satelite_hdf_info.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:satelite_hdf_info.data_remark
     *
     * @return satelite_hdf_info.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:satelite_hdf_info.data_remark
     *
     * @param dataRemark the value for satelite_hdf_info.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:satelite_hdf_info.create_time
     *
     * @return satelite_hdf_info.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:satelite_hdf_info.create_time
     *
     * @param createTime the value for satelite_hdf_info.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:satelite_hdf_info.version_remark
     *
     * @return satelite_hdf_info.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:satelite_hdf_info.version_remark
     *
     * @param versionRemark the value for satelite_hdf_info.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:satelite_hdf_info.vno
     *
     * @return satelite_hdf_info.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:satelite_hdf_info.vno
     *
     * @param vno the value for satelite_hdf_info.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:satelite_hdf_info.is_enabled
     *
     * @return satelite_hdf_info.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:satelite_hdf_info.is_enabled
     *
     * @param isEnabled the value for satelite_hdf_info.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :satelite_hdf_info
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", hdfName=").append(hdfName);
        sb.append(", hdfType=").append(hdfType);
        sb.append(", recDate=").append(recDate);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :satelite_hdf_info
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SateliteHdfInfo other = (SateliteHdfInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getHdfName() == null ? other.getHdfName() == null : this.getHdfName().equals(other.getHdfName()))
            && (this.getHdfType() == null ? other.getHdfType() == null : this.getHdfType().equals(other.getHdfType()))
            && (this.getRecDate() == null ? other.getRecDate() == null : this.getRecDate().equals(other.getRecDate()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :satelite_hdf_info
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getHdfName() == null) ? 0 : getHdfName().hashCode());
        result = prime * result + ((getHdfType() == null) ? 0 : getHdfType().hashCode());
        result = prime * result + ((getRecDate() == null) ? 0 : getRecDate().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}