package com.nxin.etposvr.dm.export.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/2/13 15:21
 */
public class ExportOrderDmReqForm extends WebPageParam {

    @ApiModelProperty(value = "订单id", dataType = "Long")
    private Long id;

    @ApiModelProperty(value = "订单状态1待结算 2 待发货 3 已收货 4待收货 5已完成 6 已关闭", dataType = "orderStatus")
    private Integer orderStatus;

    @ApiModelProperty(value = "支付方式", dataType = "Integer")
    private String payment;

    @ApiModelProperty(value = "收货人", dataType = "String")
    private String personName;

    @ApiModelProperty(value = "店铺名称", dataType = "String")
    private String shopName;

    @ApiModelProperty(value = "收货人电话", dataType = "String")
    private String tel;

    private Byte systemId;


    /**
     * 卖家姓名模糊查询
     */
    private String sellerNameLike;
    /**
     * 买家姓名模糊查询
     */
    private String buyerNameLike;
    /**
     * 下单开始时间
     */
    private Date orderTimeStart;
    /**
     * 下单结束时间
     */
    private Date orderTimeEnd;
    /**
     * 支付开始时间
     */
    private Date paymentTimeStart;
    /**
     * 支付结束时间
     */
    private Date paymentTimeEnd;
    /**
     * 收货开始时间
     */
    private Date receiveTimeStart;
    /**
     * 收货结束时间
     */
    private Date receiveTimeEnd;
    /**
     * 完成开始时间
     */
    private Date finishTimeStart;
    /**
     * 完成结束时间
     */
    private Date finishTimeEnd;

    private String voucherApprovalStatus;

    /**
     * 查询订单---地址
     */
    private String areaAxisLike;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getSellerNameLike() {
        return sellerNameLike;
    }

    public void setSellerNameLike(String sellerNameLike) {
        this.sellerNameLike = sellerNameLike;
    }

    public String getBuyerNameLike() {
        return buyerNameLike;
    }

    public void setBuyerNameLike(String buyerNameLike) {
        this.buyerNameLike = buyerNameLike;
    }

    public Date getOrderTimeStart() {
        return orderTimeStart;
    }

    public void setOrderTimeStart(Date orderTimeStart) {
        this.orderTimeStart = orderTimeStart;
    }

    public Date getOrderTimeEnd() {
        return orderTimeEnd;
    }

    public void setOrderTimeEnd(Date orderTimeEnd) {
        this.orderTimeEnd = orderTimeEnd;
    }

    public Date getPaymentTimeStart() {
        return paymentTimeStart;
    }

    public void setPaymentTimeStart(Date paymentTimeStart) {
        this.paymentTimeStart = paymentTimeStart;
    }

    public Date getPaymentTimeEnd() {
        return paymentTimeEnd;
    }

    public void setPaymentTimeEnd(Date paymentTimeEnd) {
        this.paymentTimeEnd = paymentTimeEnd;
    }

    public Date getReceiveTimeStart() {
        return receiveTimeStart;
    }

    public void setReceiveTimeStart(Date receiveTimeStart) {
        this.receiveTimeStart = receiveTimeStart;
    }

    public Date getReceiveTimeEnd() {
        return receiveTimeEnd;
    }

    public void setReceiveTimeEnd(Date receiveTimeEnd) {
        this.receiveTimeEnd = receiveTimeEnd;
    }

    public Date getFinishTimeStart() {
        return finishTimeStart;
    }

    public void setFinishTimeStart(Date finishTimeStart) {
        this.finishTimeStart = finishTimeStart;
    }

    public Date getFinishTimeEnd() {
        return finishTimeEnd;
    }

    public void setFinishTimeEnd(Date finishTimeEnd) {
        this.finishTimeEnd = finishTimeEnd;
    }

    public String getVoucherApprovalStatus() {
        return voucherApprovalStatus;
    }

    public void setVoucherApprovalStatus(String voucherApprovalStatus) {
        this.voucherApprovalStatus = voucherApprovalStatus;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    @Override
    public String toString() {
        return "ExportOrderDmReqForm{" +
                "id=" + id +
                ", orderStatus=" + orderStatus +
                ", payment='" + payment + '\'' +
                ", personName='" + personName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", tel='" + tel + '\'' +
                ", systemId=" + systemId +
                ", sellerNameLike='" + sellerNameLike + '\'' +
                ", buyerNameLike='" + buyerNameLike + '\'' +
                ", orderTimeStart=" + orderTimeStart +
                ", orderTimeEnd=" + orderTimeEnd +
                ", paymentTimeStart=" + paymentTimeStart +
                ", paymentTimeEnd=" + paymentTimeEnd +
                ", receiveTimeStart=" + receiveTimeStart +
                ", receiveTimeEnd=" + receiveTimeEnd +
                ", finishTimeStart=" + finishTimeStart +
                ", finishTimeEnd=" + finishTimeEnd +
                ", voucherApprovalStatus='" + voucherApprovalStatus + '\'' +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                '}';
    }
}
