package com.nxin.etposvr.dm.manage.controller.res;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/13 16:52
 */
public class ManufacturerResForm {
    private Byte systemId;

    private String categoryAxis;

    private double thousandProp;
    private double fTtProp;
    private double tTfProp;
    private double twoProp;
    private Integer mTotal;
    private Integer twoNum;
    private Integer tTfNum;
    private Integer fTtNum;
    private Integer thouNum;

    private String areaAxisLike;

    private Date startTime;

    private Date endTime;

    private Integer pzNum;
    private Integer dpNum;
    private Integer fyNum;
    private Integer stNum;
    private Integer xdNum;
    private Integer zlNum;
    private Integer pzCs;
    private Integer wyCs;

    private Integer zsNum;

    private Double clNum;

    private BigDecimal amount;

    private Long manuId;
    private List<Long> idList;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public double getThousandProp() {
        return thousandProp;
    }

    public void setThousandProp(double thousandProp) {
        this.thousandProp = thousandProp;
    }

    public double getfTtProp() {
        return fTtProp;
    }

    public void setfTtProp(double fTtProp) {
        this.fTtProp = fTtProp;
    }

    public double gettTfProp() {
        return tTfProp;
    }

    public void settTfProp(double tTfProp) {
        this.tTfProp = tTfProp;
    }

    public double getTwoProp() {
        return twoProp;
    }

    public void setTwoProp(double twoProp) {
        this.twoProp = twoProp;
    }

    public Integer getmTotal() {
        return mTotal;
    }

    public void setmTotal(Integer mTotal) {
        this.mTotal = mTotal;
    }

    public Integer getTwoNum() {
        return twoNum;
    }

    public void setTwoNum(Integer twoNum) {
        this.twoNum = twoNum;
    }

    public Integer gettTfNum() {
        return tTfNum;
    }

    public void settTfNum(Integer tTfNum) {
        this.tTfNum = tTfNum;
    }

    public Integer getfTtNum() {
        return fTtNum;
    }

    public void setfTtNum(Integer fTtNum) {
        this.fTtNum = fTtNum;
    }

    public Integer getThouNum() {
        return thouNum;
    }

    public void setThouNum(Integer thouNum) {
        this.thouNum = thouNum;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getPzNum() {
        return pzNum;
    }

    public void setPzNum(Integer pzNum) {
        this.pzNum = pzNum;
    }

    public Integer getDpNum() {
        return dpNum;
    }

    public void setDpNum(Integer dpNum) {
        this.dpNum = dpNum;
    }

    public Integer getFyNum() {
        return fyNum;
    }

    public void setFyNum(Integer fyNum) {
        this.fyNum = fyNum;
    }

    public Integer getStNum() {
        return stNum;
    }

    public void setStNum(Integer stNum) {
        this.stNum = stNum;
    }

    public Integer getXdNum() {
        return xdNum;
    }

    public void setXdNum(Integer xdNum) {
        this.xdNum = xdNum;
    }

    public Integer getZlNum() {
        return zlNum;
    }

    public void setZlNum(Integer zlNum) {
        this.zlNum = zlNum;
    }

    public Integer getZsNum() {
        return zsNum;
    }

    public void setZsNum(Integer zsNum) {
        this.zsNum = zsNum;
    }

    public Double getClNum() {
        return clNum;
    }

    public void setClNum(Double clNum) {
        this.clNum = clNum;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }

    public Integer getPzCs() {
        return pzCs;
    }

    public void setPzCs(Integer pzCs) {
        this.pzCs = pzCs;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public Integer getWyCs() {
        return wyCs;
    }

    public void setWyCs(Integer wyCs) {
        this.wyCs = wyCs;
    }

    @Override
    public String toString() {
        return "ManufacturerResForm{" +
                "systemId=" + systemId +
                ", categoryAxis='" + categoryAxis + '\'' +
                ", thousandProp=" + thousandProp +
                ", fTtProp=" + fTtProp +
                ", tTfProp=" + tTfProp +
                ", twoProp=" + twoProp +
                ", mTotal=" + mTotal +
                ", twoNum=" + twoNum +
                ", tTfNum=" + tTfNum +
                ", fTtNum=" + fTtNum +
                ", thouNum=" + thouNum +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", pzNum=" + pzNum +
                ", dpNum=" + dpNum +
                ", fyNum=" + fyNum +
                ", stNum=" + stNum +
                ", xdNum=" + xdNum +
                ", zlNum=" + zlNum +
                ", pzCs=" + pzCs +
                ", wyCs=" + wyCs +
                ", zsNum=" + zsNum +
                ", clNum=" + clNum +
                ", amount=" + amount +
                ", manuId=" + manuId +
                ", idList=" + idList +
                '}';
    }
}
