package com.nxin.etposvr.dmp.stat.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.List;
import java.util.Map;

/**
 * 品类
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:11
 * @version: v_1.0.1
 */
public class StatPdmgCategoryReqForm extends WebPageParam {

    /**
     * @Fields id id
     */
    private Long id;

    /**
     * @Fields categoryId 品类ID
     */
    private Long categoryId;

    /**
     * @Fields categoryAxis 品类层级串
     */
    private String categoryAxis;

    /**
     * @Fields categoryName 品类名称
     */
    private String categoryName;

    /**
     * @Fields dataDate 数据日期
     */
    private String dataDate;

    /**
     * @Fields dataYearMonth 数据年月
     */
    private String dataYearMonth;

    /**
     * @Fields dataYear 数据年份
     */
    private String dataYear;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    private Map<String, List<String>> typeMap;

    private String num;

    private String statType;

    private String categoryAxisLike;

    private String type;

    private List<String> categoryAxisLikeList;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getCategoryAxisLikeList() {
        return categoryAxisLikeList;
    }

    public void setCategoryAxisLikeList(List<String> categoryAxisLikeList) {
        this.categoryAxisLikeList = categoryAxisLikeList;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getDataYearMonth() {
        return dataYearMonth;
    }

    public void setDataYearMonth(String dataYearMonth) {
        this.dataYearMonth = dataYearMonth;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Map<String, List<String>> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(Map<String, List<String>> typeMap) {
        this.typeMap = typeMap;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }
}
