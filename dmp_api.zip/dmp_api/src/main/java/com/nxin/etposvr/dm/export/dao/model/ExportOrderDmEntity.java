package com.nxin.etposvr.dm.export.dao.model;

import java.util.Date;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/2/13 15:21
 */
public class ExportOrderDmEntity {

    /**
     * 订单id
     */
    private Long id;
    /**
     * 支付方式
     */
    private String payment;
    /**
     * 用户名称
     */
    private String personName;
    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 电话
     */
    private String tel;

    /**
     * 支付状态
     */
    private String paymentStatus;
    /**
     * 发货状态
     */
    private String sendStatus;
    /**
     * 收货状态
     */
    private String receiveStatus;
    /**
     * 结算状态
     */
    private String balanceStatus;
    /**
     * 完成状态
     */
    private String finishStatus;
    /**
     * 订单状态
     */
    private String type;
    /**
     * 系统ID
     */
    private Byte systemId;

    /**
     * 卖家姓名模糊查询
     */
    private String sellerNameLike;
    /**
     * 买家姓名模糊查询
     */
    private String buyerNameLike;
    /**
     * 下单开始时间
     */
    private Date orderTimeStart;
    /**
     * 下单结束时间
     */
    private Date orderTimeEnd;
    /**
     * 支付开始时间
     */
    private Date paymentTimeStart;
    /**
     * 支付结束时间
     */
    private Date paymentTimeEnd;
    /**
     * 收货开始时间
     */
    private Date receiveTimeStart;
    /**
     * 收货结束时间
     */
    private Date receiveTimeEnd;
    /**
     * 完成开始时间
     */
    private Date finishTimeStart;
    /**
     * 完成结束时间
     */
    private Date finishTimeEnd;

    private String voucherApprovalStatus;

    /**
     * 查询订单---地址
     */
    private String areaAxisLike;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus;
    }

    public String getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(String receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public String getBalanceStatus() {
        return balanceStatus;
    }

    public void setBalanceStatus(String balanceStatus) {
        this.balanceStatus = balanceStatus;
    }

    public String getFinishStatus() {
        return finishStatus;
    }

    public void setFinishStatus(String finishStatus) {
        this.finishStatus = finishStatus;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getSellerNameLike() {
        return sellerNameLike;
    }

    public void setSellerNameLike(String sellerNameLike) {
        this.sellerNameLike = sellerNameLike;
    }

    public String getBuyerNameLike() {
        return buyerNameLike;
    }

    public void setBuyerNameLike(String buyerNameLike) {
        this.buyerNameLike = buyerNameLike;
    }

    public Date getOrderTimeStart() {
        return orderTimeStart;
    }

    public void setOrderTimeStart(Date orderTimeStart) {
        this.orderTimeStart = orderTimeStart;
    }

    public Date getOrderTimeEnd() {
        return orderTimeEnd;
    }

    public void setOrderTimeEnd(Date orderTimeEnd) {
        this.orderTimeEnd = orderTimeEnd;
    }

    public Date getPaymentTimeStart() {
        return paymentTimeStart;
    }

    public void setPaymentTimeStart(Date paymentTimeStart) {
        this.paymentTimeStart = paymentTimeStart;
    }

    public Date getPaymentTimeEnd() {
        return paymentTimeEnd;
    }

    public void setPaymentTimeEnd(Date paymentTimeEnd) {
        this.paymentTimeEnd = paymentTimeEnd;
    }

    public Date getReceiveTimeStart() {
        return receiveTimeStart;
    }

    public void setReceiveTimeStart(Date receiveTimeStart) {
        this.receiveTimeStart = receiveTimeStart;
    }

    public Date getReceiveTimeEnd() {
        return receiveTimeEnd;
    }

    public void setReceiveTimeEnd(Date receiveTimeEnd) {
        this.receiveTimeEnd = receiveTimeEnd;
    }

    public Date getFinishTimeStart() {
        return finishTimeStart;
    }

    public void setFinishTimeStart(Date finishTimeStart) {
        this.finishTimeStart = finishTimeStart;
    }

    public Date getFinishTimeEnd() {
        return finishTimeEnd;
    }

    public void setFinishTimeEnd(Date finishTimeEnd) {
        this.finishTimeEnd = finishTimeEnd;
    }

    public String getVoucherApprovalStatus() {
        return voucherApprovalStatus;
    }

    public void setVoucherApprovalStatus(String voucherApprovalStatus) {
        this.voucherApprovalStatus = voucherApprovalStatus;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    @Override
    public String toString() {
        return "ExportOrderDmEntity{" +
                "id=" + id +
                ", payment='" + payment + '\'' +
                ", personName='" + personName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", tel='" + tel + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", sendStatus='" + sendStatus + '\'' +
                ", receiveStatus='" + receiveStatus + '\'' +
                ", balanceStatus='" + balanceStatus + '\'' +
                ", finishStatus='" + finishStatus + '\'' +
                ", type='" + type + '\'' +
                ", systemId=" + systemId +
                ", sellerNameLike='" + sellerNameLike + '\'' +
                ", buyerNameLike='" + buyerNameLike + '\'' +
                ", orderTimeStart=" + orderTimeStart +
                ", orderTimeEnd=" + orderTimeEnd +
                ", paymentTimeStart=" + paymentTimeStart +
                ", paymentTimeEnd=" + paymentTimeEnd +
                ", receiveTimeStart=" + receiveTimeStart +
                ", receiveTimeEnd=" + receiveTimeEnd +
                ", finishTimeStart=" + finishTimeStart +
                ", finishTimeEnd=" + finishTimeEnd +
                ", voucherApprovalStatus='" + voucherApprovalStatus + '\'' +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                '}';
    }
}
