package com.nxin.etposvr.dm.order.dao.model;

import java.util.List;

/**
 * 订单品类增长趋势返回实体
 *
 * @author ZhangXu
 * @since 2020.3.24
 */
public class OrderCategoryGrowthTrendDmInfo {

    private Long categoryId;
    private List<CategoryAmount> orderInfoDmEntityList;

    public OrderCategoryGrowthTrendDmInfo(Long categoryId, List<CategoryAmount> orderInfoDmEntityList) {
        this.categoryId = categoryId;
        this.orderInfoDmEntityList = orderInfoDmEntityList;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public List<CategoryAmount> getOrderInfoDmEntityList() {
        return orderInfoDmEntityList;
    }

    public void setOrderInfoDmEntityList(List<CategoryAmount> orderInfoDmEntityList) {
        this.orderInfoDmEntityList = orderInfoDmEntityList;
    }
}
