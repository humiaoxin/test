package com.nxin.etposvr.dmp.search.controller.res;

import com.nxin.etposvr.dmp.search.dao.model.SearchHistoryInfo;

/**
 * 搜索历史 reqForm
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/5/29 13:33
 */
public class SearchHistoryInfoResForm extends SearchHistoryInfo {
}
