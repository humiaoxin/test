package com.nxin.etposvr.dm.commission.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

public class CommissionInfoDmReqForm extends WebPageParam {

    /**
     * ID
     */
    private Long id;
    /**
     * 业务单类型
     */
    private String bizType;
    /**
     * 业务单ID
     */
    private Long bizId;
    /**
     * 业务单状态
     */
    private String bizStatus;
    /**
     * 业务单时间
     */
    private Date bizTime;

    /**
     * 业务单金额
     */
    private Long bizAmount;
    /**
     * 佣金状态
     */
    private String commissionStatus;
    /**
     * 佣金结算时间
     */
    private Date commissionSettleTime;
    /**
     * 佣金金额
     */
    private Long commissionAmount;
    /**
     * 返佣用户ID
     */
    private Long commissionBoId;
    /**
     * 返佣用户类型
     */
    private String commissionUserType;
    /**
     * 平台返点金额
     */
    private Long platformCommissionAmount;
    /**
     * 操作人ID
     */
    private Long oprBoId;
    /**
     *所属系统
     */
    private Byte systemId;
    /**
     *数据说明
     */
    private String dataRemark;
    /**
     *创建时间
     */
    private Date createTime;
    /**
     *版本说明
     */
    private String versionRemark;
    /**
     *版本号
     */
    private Date vno;
    /**
     *是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    /**页数*/
    private Integer pageNum;
    /**页数大小*/
    private Integer pageSize;

    //佣金结算开始时间
    private String commissionSettleTimeStart;
    //佣金结算结束时间
    private String commissionSettleTimeEnd;
    //佣金业务单开始时间
    private String bizTimeStart;
    //佣金业务单结束时间
    private String bizTimeEnd;

    //佣金月时间
    private String monthTime;

    //是否查询取消状态
    private String isCancel;


    public String getIsCancel() {
        return isCancel;
    }

    public void setIsCancel(String isCancel) {
        this.isCancel = isCancel;
    }

    public String getMonthTime() {
        return monthTime;
    }

    public void setMonthTime(String monthTime) {
        this.monthTime = monthTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public Long getBizId() {
        return bizId;
    }

    public void setBizId(Long bizId) {
        this.bizId = bizId;
    }

    public String getBizStatus() {
        return bizStatus;
    }

    public void setBizStatus(String bizStatus) {
        this.bizStatus = bizStatus;
    }

    public Date getBizTime() {
        return bizTime;
    }

    public void setBizTime(Date bizTime) {
        this.bizTime = bizTime;
    }

    public Long getBizAmount() {
        return bizAmount;
    }

    public void setBizAmount(Long bizAmount) {
        this.bizAmount = bizAmount;
    }

    public String getCommissionStatus() {
        return commissionStatus;
    }

    public void setCommissionStatus(String commissionStatus) {
        this.commissionStatus = commissionStatus;
    }

    public Date getCommissionSettleTime() {
        return commissionSettleTime;
    }

    public void setCommissionSettleTime(Date commissionSettleTime) {
        this.commissionSettleTime = commissionSettleTime;
    }

    public Long getCommissionAmount() {
        return commissionAmount;
    }

    public void setCommissionAmount(Long commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    public Long getCommissionBoId() {
        return commissionBoId;
    }

    public void setCommissionBoId(Long commissionBoId) {
        this.commissionBoId = commissionBoId;
    }

    public String getCommissionUserType() {
        return commissionUserType;
    }

    public void setCommissionUserType(String commissionUserType) {
        this.commissionUserType = commissionUserType;
    }

    public Long getPlatformCommissionAmount() {
        return platformCommissionAmount;
    }

    public void setPlatformCommissionAmount(Long platformCommissionAmount) {
        this.platformCommissionAmount = platformCommissionAmount;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getCommissionSettleTimeStart() {
        return commissionSettleTimeStart;
    }

    public void setCommissionSettleTimeStart(String commissionSettleTimeStart) {
        this.commissionSettleTimeStart = commissionSettleTimeStart;
    }

    public String getCommissionSettleTimeEnd() {
        return commissionSettleTimeEnd;
    }

    public void setCommissionSettleTimeEnd(String commissionSettleTimeEnd) {
        this.commissionSettleTimeEnd = commissionSettleTimeEnd;
    }

    public String getBizTimeStart() {
        return bizTimeStart;
    }

    public void setBizTimeStart(String bizTimeStart) {
        this.bizTimeStart = bizTimeStart;
    }

    public String getBizTimeEnd() {
        return bizTimeEnd;
    }

    public void setBizTimeEnd(String bizTimeEnd) {
        this.bizTimeEnd = bizTimeEnd;
    }
}
