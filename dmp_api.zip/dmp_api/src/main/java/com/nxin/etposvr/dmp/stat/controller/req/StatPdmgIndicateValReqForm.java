package com.nxin.etposvr.dmp.stat.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 指标数值
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:12
 * @version: v_1.0.1
 */
public class StatPdmgIndicateValReqForm extends WebPageParam {

    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields statId 统计ID
     */
    private Long statId;

    /**
     * @Fields statType 统计类型
     */
    private String statType;

    /**
     * @Fields indicateDefId 指标定义表ID
     */
    private Long indicateDefId;

    /**
     * @Fields indicateVal 指标值
     */
    private String indicateVal;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    private String  StatLevel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStatId() {
        return statId;
    }

    public void setStatId(Long statId) {
        this.statId = statId;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public Long getIndicateDefId() {
        return indicateDefId;
    }

    public void setIndicateDefId(Long indicateDefId) {
        this.indicateDefId = indicateDefId;
    }

    public String getIndicateVal() {
        return indicateVal;
    }

    public void setIndicateVal(String indicateVal) {
        this.indicateVal = indicateVal;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getStatLevel() {
        return StatLevel;
    }

    public void setStatLevel(String statLevel) {
        StatLevel = statLevel;
    }
}
