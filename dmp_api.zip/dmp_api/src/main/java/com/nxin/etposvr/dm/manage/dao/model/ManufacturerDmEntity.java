package com.nxin.etposvr.dm.manage.dao.model;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/13 16:41
 */
public class ManufacturerDmEntity {

    private Byte systemId;

    private String categoryAxis;

    private double thousandProp;
    private double fTtProp;
    private double tTfProp;
    private double twoProp;
    private Integer mTotal;
    private Integer twoNum;
    private Integer tTfNum;
    private Integer fTtNum;
    private Integer thouNum;

    private String areaAxisLike;

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public double getThousandProp() {
        return thousandProp;
    }

    public void setThousandProp(double thousandProp) {
        this.thousandProp = thousandProp;
    }

    public double getfTtProp() {
        return fTtProp;
    }

    public void setfTtProp(double fTtProp) {
        this.fTtProp = fTtProp;
    }

    public double gettTfProp() {
        return tTfProp;
    }

    public void settTfProp(double tTfProp) {
        this.tTfProp = tTfProp;
    }

    public double getTwoProp() {
        return twoProp;
    }

    public void setTwoProp(double twoProp) {
        this.twoProp = twoProp;
    }

    public Integer getmTotal() {
        return mTotal;
    }

    public void setmTotal(Integer mTotal) {
        this.mTotal = mTotal;
    }

    public Integer getTwoNum() {
        return twoNum;
    }

    public void setTwoNum(Integer twoNum) {
        this.twoNum = twoNum;
    }

    public Integer gettTfNum() {
        return tTfNum;
    }

    public void settTfNum(Integer tTfNum) {
        this.tTfNum = tTfNum;
    }

    public Integer getfTtNum() {
        return fTtNum;
    }

    public void setfTtNum(Integer fTtNum) {
        this.fTtNum = fTtNum;
    }

    public Integer getThouNum() {
        return thouNum;
    }

    public void setThouNum(Integer thouNum) {
        this.thouNum = thouNum;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }
}
