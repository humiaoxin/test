package com.nxin.etposvr.dm.system.dao.model;

import java.util.Date;
import java.util.List;

public class SystemEvaluateDmEntity {
    private Long id;

    private String busType;

    private String busId;

    private Long evaluatedBoId;

    private Long boId;

    private Integer compositeScore;

    private String labels;

    private Date evaluateTime;

    private String evaluateTimeStr;

    private String versionRemark;

    private Date createTime;

    private String dataRemark;

    private Date vno;

    private Byte isEnabled;

    private Byte systemId;

    private String cmtBody;

    private String userName;

    private String headIcon;

    private List<String> labelList;

    public String getEvaluateTimeStr() {
        return evaluateTimeStr;
    }

    public void setEvaluateTimeStr(String evaluateTimeStr) {
        this.evaluateTimeStr = evaluateTimeStr;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusType() {
        return busType;
    }

    public void setBusType(String busType) {
        this.busType = busType == null ? null : busType.trim();
    }

    public String getBusId() {
        return busId;
    }

    public void setBusId(String busId) {
        this.busId = busId == null ? null : busId.trim();
    }

    public Long getEvaluatedBoId() {
        return evaluatedBoId;
    }

    public void setEvaluatedBoId(Long evaluatedBoId) {
        this.evaluatedBoId = evaluatedBoId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Integer getCompositeScore() {
        return compositeScore;
    }

    public void setCompositeScore(Integer compositeScore) {
        this.compositeScore = compositeScore;
    }

    public String getLabels() {
        return labels;
    }

    public void setLabels(String labels) {
        this.labels = labels == null ? null : labels.trim();
    }

    public Date getEvaluateTime() {
        return evaluateTime;
    }

    public void setEvaluateTime(Date evaluateTime) {
        this.evaluateTime = evaluateTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCmtBody() {
        return cmtBody;
    }

    public void setCmtBody(String cmtBody) {
        this.cmtBody = cmtBody == null ? null : cmtBody.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<String> getLabelList() {
        return labelList;
    }

    public void setLabelList(List<String> labelList) {
        this.labelList = labelList;
    }

    public String getHeadIcon() {
        return headIcon;
    }

    public void setHeadIcon(String headIcon) {
        this.headIcon = headIcon;
    }

    @Override
    public String toString() {
        return "SystemEvaluateDmEntity{" +
                "id=" + id +
                ", busType='" + busType + '\'' +
                ", busId='" + busId + '\'' +
                ", evaluatedBoId=" + evaluatedBoId +
                ", boId=" + boId +
                ", compositeScore=" + compositeScore +
                ", labels='" + labels + '\'' +
                ", evaluateTime=" + evaluateTime +
                ", evaluateTimeStr='" + evaluateTimeStr + '\'' +
                ", versionRemark='" + versionRemark + '\'' +
                ", createTime=" + createTime +
                ", dataRemark='" + dataRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                ", systemId=" + systemId +
                ", cmtBody='" + cmtBody + '\'' +
                ", userName='" + userName + '\'' +
                ", headIcon='" + headIcon + '\'' +
                ", labelList=" + labelList +
                '}';
    }
}