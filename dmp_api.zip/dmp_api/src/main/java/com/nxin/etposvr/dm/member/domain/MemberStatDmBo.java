package com.nxin.etposvr.dm.member.domain;

import com.nxin.etpojar.common.bean.BeanCopierDsUtil;
import com.nxin.etposvr.dm.member.controller.res.MemberStatDmResForm;
import org.apache.commons.collections.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * @author LS
 * @date 2019/10/28
 */
public class MemberStatDmBo {
    private Integer pageNum;
    private Integer pageSize;
    /**
     * 开始时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date startTime;
    /**
     * 结束时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date endTime;

    /**
     * 统计类型
     * DAY-按日统计
     * MON-按月统计
     * YEAR-按年统计
     * 其他-全部统计
     *
     * @author LS
     * @date 2019/10/28
     */
    private String statType;

    /**
     * 时间
     * 日(yyyy-MM-dd)
     * 月(yyyy-MM)
     * 年(yyyy)
     *
     * @author LS
     * @date 2019/10/28
     */
    private String period;
    /**
     * 用户类型
     * GR-个人
     * GT-个体
     * QY-企业
     *
     * @author LS
     * @date 2019/10/28
     */
    private String userType;
    /**
     * 总数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long totalNum = 0L;
    /**
     * 个人用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long grNum = 0L;
    /**
     * 个体用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long gtNum = 0L;
    /**
     * 企业用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long qyNum = 0L;
    /**
     * 其他用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long otherNum = 0L;
    /**
     * 地区编号
     *
     * @author LS
     * @date 2019/10/29
     */
    private Integer areaId;
    /**
     * 所属系统
     *
     * @author LS
     * @date 2019/10/28
     */
    private Byte systemId;

    /**
     * 来源
     *
     * @author lpp
     * @date 2020/4/17 13:59
     */
    private String source;
    /**
     * 用户信息集合
     *
     * @author lpp
     * @date 2020/4/17 14:35
     */
    private List<MemberStatDmBo> memberStatDmList;

    /**
     * 地区等级
     *
     * @author lpp
     * @date 2020/4/17 15:11
     */
    private Integer areaRank;
    /**
     * 地区层级串
     *
     * @author lpp
     * @date 2020/4/17 15:17
     */
    private String areaAxis;
    /**
     * 地区名称
     *
     * @author lpp
     * @date 2020/4/17 15:18
     */
    private String areaName;

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getAreaRank() {
        return areaRank;
    }

    public void setAreaRank(Integer areaRank) {
        this.areaRank = areaRank;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public List<MemberStatDmBo> getMemberStatDmList() {
        return memberStatDmList;
    }

    public void setMemberStatDmList(List<MemberStatDmBo> memberStatDmList) {
        this.memberStatDmList = memberStatDmList;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Long getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Long totalNum) {
        this.totalNum = totalNum;
    }

    public Long getGrNum() {
        return grNum;
    }

    public void setGrNum(Long grNum) {
        this.grNum = grNum;
    }

    public Long getGtNum() {
        return gtNum;
    }

    public void setGtNum(Long gtNum) {
        this.gtNum = gtNum;
    }

    public Long getQyNum() {
        return qyNum;
    }

    public void setQyNum(Long qyNum) {
        this.qyNum = qyNum;
    }

    public Long getOtherNum() {
        return otherNum;
    }

    public void setOtherNum(Long otherNum) {
        this.otherNum = otherNum;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public static MemberStatDmResForm boToResForm(MemberStatDmBo bo) {
        if (bo == null) {
            return null;
        }
        MemberStatDmResForm cmsArticleResForm = BeanCopierDsUtil.copyProperties(bo, MemberStatDmResForm.class);
        if (CollectionUtils.isNotEmpty(bo.getMemberStatDmList())) {
            List<MemberStatDmResForm> list = BeanCopierDsUtil.copyPropertiesOfList(bo.getMemberStatDmList(), MemberStatDmResForm.class);
            cmsArticleResForm.setMemberStatDmList(list);
        }
        return cmsArticleResForm;
    }

    @Override
    public String toString() {
        return "MemberStatDmBo{" +
                "startTime=" + startTime +
                ", endTime=" + endTime +
                ", statType='" + statType + '\'' +
                ", period='" + period + '\'' +
                ", userType='" + userType + '\'' +
                ", totalNum=" + totalNum +
                ", grNum=" + grNum +
                ", gtNum=" + gtNum +
                ", qyNum=" + qyNum +
                ", otherNum=" + otherNum +
                ", systemId=" + systemId +
                ", areaId=" + areaId +
                '}';
    }
}

