package com.nxin.etposvr.dm.member.dao.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.nxin.etposvr.dm.goods.dao.model.GoodsInfoDmEntity;
import com.nxin.etposvr.dm.system.dao.model.SystemEvaluateDmEntity;

import java.util.List;

public class MemberDmEntity {
    /**
     * 服务人员boId
     */
    private Long boId;
    /**
     * 客户boId集合
     */
    public List<Long> boIdList;
    /**
     * 所有客户的猪场个数
     */
    public int manuCount;
    /**
     * 商品类型集合
     */
    public String type;

    private Byte systemId;

    /**
     * 商品集合
     */
    public List<GoodsInfoDmEntity> spGoodsList;

    /**
     * 求购集合
     */
    public List<GoodsInfoDmEntity> qgGoodsList;

    /**
     * 评价集合
     */
    public List<SystemEvaluateDmEntity> pjList;

    /**
     * 用户集合
     */
    public List<MemberInfoDmEntity> memberInfoList;
    /**
     * 第几页
     */
    private Integer pageNum;
    /**
     * 条数
     */
    private Integer pageSize;
    /**
     * 排序参数
     */
    private Integer sortParam;
    /**
     * 分组参数
     */
    private Integer groupParam;
    /**
     * 查询条件参数
     */
    private Integer typeParam;
    /**
     * 总条数
     */
    private Integer total;

    /**
     * 成长值
     */
    private Integer growthValue;
    /**
     * 等级
     *
     * @author LS
     * @since 2020/9/17 19:17
     */
    private Integer rank;
    /**
     * 会员等级名称
     */
    private String rankName;

    /**
     * 姓名
     */
    private String realName;

    /**
     * 手机号
     */
    private String mobilePhone;

    private String userName;

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public int getManuCount() {
        return manuCount;
    }

    public void setManuCount(int manuCount) {
        this.manuCount = manuCount;
    }

    public List<GoodsInfoDmEntity> getSpGoodsList() {
        return spGoodsList;
    }

    public void setSpGoodsList(List<GoodsInfoDmEntity> spGoodsList) {
        this.spGoodsList = spGoodsList;
    }

    public List<GoodsInfoDmEntity> getQgGoodsList() {
        return qgGoodsList;
    }

    public void setQgGoodsList(List<GoodsInfoDmEntity> qgGoodsList) {
        this.qgGoodsList = qgGoodsList;
    }

    public List<SystemEvaluateDmEntity> getPjList() {
        return pjList;
    }

    public void setPjList(List<SystemEvaluateDmEntity> pjList) {
        this.pjList = pjList;
    }

    public List<MemberInfoDmEntity> getMemberInfoList() {
        return memberInfoList;
    }

    public void setMemberInfoList(List<MemberInfoDmEntity> memberInfoList) {
        this.memberInfoList = memberInfoList;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getSortParam() {
        return sortParam;
    }

    public void setSortParam(Integer sortParam) {
        this.sortParam = sortParam;
    }

    public Integer getGroupParam() {
        return groupParam;
    }

    public void setGroupParam(Integer groupParam) {
        this.groupParam = groupParam;
    }

    public Integer getTypeParam() {
        return typeParam;
    }

    public void setTypeParam(Integer typeParam) {
        this.typeParam = typeParam;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(Integer growthValue) {
        this.growthValue = growthValue;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, new SerializerFeature[]{
                SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty,
                SerializerFeature.WriteNullStringAsEmpty,
                SerializerFeature.WriteNullNumberAsZero,
                SerializerFeature.WriteNullBooleanAsFalse,
                SerializerFeature.WriteDateUseDateFormat});
    }
}
