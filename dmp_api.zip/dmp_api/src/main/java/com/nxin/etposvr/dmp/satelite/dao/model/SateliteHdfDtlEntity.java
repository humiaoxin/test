package com.nxin.etposvr.dmp.satelite.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class SateliteHdfDtlEntity {

    /**
     * 主键
     */
    private Long id;

    /**
     * @Fields longtitude 经度
     */
    private String longtitude;

    /**
     * @Fields latitude 纬度
     */
    private String latitude;

    /**
     * @Fields val 数值
     */
    private BigDecimal val;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * 数据文件开始时间
     */
    private Date hdfInfoRecDateStart;
    /**
     * 数据文件结束时间
     */
    private Date hdfInfoRecDateEnd;
    /**
     * 数据文件类型
     */
    private String hdfInfoHdfType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getVal() {
        return val;
    }

    public void setVal(BigDecimal val) {
        this.val = val;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getHdfInfoRecDateStart() {
        return hdfInfoRecDateStart;
    }

    public void setHdfInfoRecDateStart(Date hdfInfoRecDateStart) {
        this.hdfInfoRecDateStart = hdfInfoRecDateStart;
    }

    public Date getHdfInfoRecDateEnd() {
        return hdfInfoRecDateEnd;
    }

    public void setHdfInfoRecDateEnd(Date hdfInfoRecDateEnd) {
        this.hdfInfoRecDateEnd = hdfInfoRecDateEnd;
    }

    public String getHdfInfoHdfType() {
        return hdfInfoHdfType;
    }

    public void setHdfInfoHdfType(String hdfInfoHdfType) {
        this.hdfInfoHdfType = hdfInfoHdfType;
    }

    @Override
    public String toString() {
        return "SateliteHdfDtlEntity{" +
                "longtitude='" + longtitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", val=" + val +
                ", systemId=" + systemId +
                ", hdfInfoRecDateStart=" + hdfInfoRecDateStart +
                ", hdfInfoRecDateEnd=" + hdfInfoRecDateEnd +
                ", hdfInfoHdfType='" + hdfInfoHdfType + '\'' +
                '}';
    }
}
