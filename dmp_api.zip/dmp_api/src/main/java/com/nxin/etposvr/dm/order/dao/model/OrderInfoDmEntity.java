package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class OrderInfoDmEntity {
    private Long id;

    private Long buyerBoId;

    private Long buyerOperatorBoId;

    private String buyerUserType;

    private Long shopId;

    private Long sellerBoId;

    private Long sellerOperatorBoId;

    private String sellerUserType;

    private Long origShopId;

    private Long origSellerBoId;

    private String saleType;

    private String type;

    private String paymentStatus;

    private String sendStatus;

    private String receiveStatus;

    private String balanceStatus;

    private String returnGoodsStatus;

    private String refundsStatus;

    private String refundsReason;

    private Date refundsApplyTime;

    private String buyerVoucherStatus;

    private String sellerVoucherStatus;

    private String voucherApprovalStatus;

    private String finishStatus;

    private String serviceFeeType;

    private String changeType;

    private String changeStatus;

    private Byte buyerFeedback;

    private Byte sellerFeedback;

    private Byte buyerDefault;

    private Byte sellerDefault;

    private Byte buyerInsure;

    private Byte sellerInsure;

    private Byte buyerHide;

    private Byte sellerHide;

    private BigDecimal goodsOrigMoney;

    private BigDecimal goodsDealMoney;

    private BigDecimal goodsDiscountMoney;

    private BigDecimal goodsPayableMoney;

    private BigDecimal freightPayableMoney;

    private BigDecimal otherPayableMoney;

    private BigDecimal insuranceMoney;

    private BigDecimal advancePaymentMoney;

    private BigDecimal deductionMoney;

    private BigDecimal ignoreMoney;

    private BigDecimal buyerServiceFee;

    private BigDecimal sellerServiceFee;

    private BigDecimal refundsApplyMoney;

    private BigDecimal refundsActualMoney;

    private BigDecimal payableMoney;

    private BigDecimal paidMoney;

    private BigDecimal cashMoney;

    private BigDecimal paidFreightMoney;

    private BigDecimal paidGoodsMoney;

    private BigDecimal couponMoney;

    private Date orderTime;

    private Date paymentTime;

    private Date sendTime;

    private Date expectedArrivalTime;

    private Date receiveTime;

    private Date balanceTime;

    private Date cancelTime;

    private Date returnGoodsTime;

    private Date refundsTime;

    private Date finishTime;

    private String payment;

    private String balance;

    private String logistics;

    private Long invoiceId;

    private Long addrId;

    private String cancelType;

    private String cancelStatus;

    private String cancelReason;

    private Byte isDeposit;

    private Byte isAuction;

    private Byte isHangup;

    private String memo;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Date arrivalTime;

    private Byte isEnabled;

    private String shopName;

    //收货人
    private String personName;
    //收货人电话
    private String tel;

    //查询订单---地址
    private String areaAxisLike;

    //订单类型集合
    private List<String> typesList;

    /**
     * 下单开始时间
     */
    private String startOrderTime;
    /**
     * 下单截至时间
     */
    private String endOrderTime;
    /**
     * 结算/成交开始时间
     */
    private String startBalanceTime;
    /**
     * 结算/成交截至时间
     */
    private String endBalanceTime;

    /**
     * @Fields realName 姓名/企业名称
     */
    private String realName;

    /**
     * @Fields mobilePhone 买家手机号码
     */
    private String mobilePhone;

    /**
     * @Fields mobilePhone 卖家手机号码
     */
    private String shopPhone;


    //订单人员id集合
    private List<Long> buyerBoIdList;

    //订单卖家人员id集合
    private List<Long> sellerBoIdList;

    /**交易额*/
    private BigDecimal amount;
    /**交易量（笔）*/
    private BigDecimal businessCount;
    /**今日交易量（笔）*/
    private BigDecimal todayBusinessCount;
    /**交易量（商品数）*/
    private BigDecimal businessNum;
    /**今日交易量（商品数）*/
    private BigDecimal todayBusinessNum;
    /**今日交易额*/
    private BigDecimal todayVolume;
    /**近X天交易额*/
    private BigDecimal rangeVolume;
    /**近X天交易量（笔）*/
    private BigDecimal rangeBusinessCount;
    /**近X天交易量（商品数）*/
    private BigDecimal rangeBusinessNum;
    /**今日新增店铺*/
    private Integer newShopNum;
    /**近X日新增店铺*/
    private Integer newShopRangeNum;
    /**在售商品数*/
    private BigDecimal saleGoodsNum;
    /**日期*/
    private String dates;
    /**
     * 品类ID
     */
    private Long categoryId;
    /**
     * 品类名称
     */
    private String categoryName;
    /**
     * 均重
     */
    private BigDecimal avgWeight;
    /**
     * 卖家经度
     */
    private BigDecimal buyerAddrLon;
    /**
     * 卖家纬度
     */
    private BigDecimal buyerAddrLat;
    /**
     * 卖家地区
     */
    private String sellerAreaName;
    /**
     * 卖家地区全名称
     */
    private String sellerAreaFullName;
    /**
     * 卖家详细地址
     */
    private String sellerAddr;
    /**
     * 买家经度
     */
    private BigDecimal sellerAddrLon;
    /**
     * 买家纬度
     */
    private BigDecimal sellerAddrLat;
    /**
     * 买家地区
     */
    private String buyerAreaName;
    /**
     * 买家地区全名称
     */
    private String buyerAreaFullName;
    /**
     * 买家详细地址
     */
    private String buyerAddr;
    /**
     * 订单金额
     */
    private BigDecimal orderMoney;
    /**
     * 卖家姓名
     */
    private String sellerName;
    /**
     * 买家数量
     */
    private Long buyerCount;

    /**
     * @Fields landCirculationStatus 土地流转状态
     */
    private String landCirculationStatus;

    /**
     * @Fields serviceDemandStatus 服务需求状态
     */
    private String serviceDemandStatus;

    /**
     * @Fields serviceDemandStatus 服务需求状态集合
     */
    private List<String> serviceStatusList;


    //订单id集合
    private List<Long> idsList;

    //订单销售类型集合
    private List<String> saleTypeList;
    /**
     * @Fields traceNo 溯源编码
     */
    private String traceNo;

    /**
     * 地区全名称
     */
    private String areaFullName;
    /**
     * 详细地址
     */
    private String addr;

    /**
     * 买家经纬度字符串
     */
    private String buyerLocation;
    /**
     * 卖家经纬度字符串
     */
    private String sellerLocation;
    /**
     * 卖家电话/供应方电话
     */
    private String sellerTel;

    public String getSellerTel() {
        return sellerTel;
    }

    public void setSellerTel(String sellerTel) {
        this.sellerTel = sellerTel;
    }

    public String getBuyerLocation() {
        return buyerLocation;
    }

    public void setBuyerLocation(String buyerLocation) {
        this.buyerLocation = buyerLocation;
    }

    public String getSellerLocation() {
        return sellerLocation;
    }

    public void setSellerLocation(String sellerLocation) {
        this.sellerLocation = sellerLocation;
    }

    public String getSellerAreaFullName() {
        return sellerAreaFullName;
    }

    public void setSellerAreaFullName(String sellerAreaFullName) {
        this.sellerAreaFullName = sellerAreaFullName;
    }

    public String getSellerAddr() {
        return sellerAddr;
    }

    public void setSellerAddr(String sellerAddr) {
        this.sellerAddr = sellerAddr;
    }

    public String getBuyerAreaFullName() {
        return buyerAreaFullName;
    }

    public void setBuyerAreaFullName(String buyerAreaFullName) {
        this.buyerAreaFullName = buyerAreaFullName;
    }

    public String getBuyerAddr() {
        return buyerAddr;
    }

    public void setBuyerAddr(String buyerAddr) {
        this.buyerAddr = buyerAddr;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo;
    }

    public String getBuyerAreaName() {
        return buyerAreaName;
    }

    public void setBuyerAreaName(String buyerAreaName) {
        this.buyerAreaName = buyerAreaName;
    }

    public String getSellerAreaName() {
        return sellerAreaName;
    }

    public void setSellerAreaName(String sellerAreaName) {
        this.sellerAreaName = sellerAreaName;
    }

    public List<String> getSaleTypeList() {
        return saleTypeList;
    }

    public void setSaleTypeList(List<String> saleTypeList) {
        this.saleTypeList = saleTypeList;
    }

    public Long getBuyerCount() {
        return buyerCount;
    }

    public void setBuyerCount(Long buyerCount) {
        this.buyerCount = buyerCount;
    }

    public List<String> getServiceStatusList() {
        return serviceStatusList;
    }

    public void setServiceStatusList(List<String> serviceStatusList) {
        this.serviceStatusList = serviceStatusList;
    }

    public String getLandCirculationStatus() {
        return landCirculationStatus;
    }

    public void setLandCirculationStatus(String landCirculationStatus) {
        this.landCirculationStatus = landCirculationStatus;
    }

    public String getServiceDemandStatus() {
        return serviceDemandStatus;
    }

    public void setServiceDemandStatus(String serviceDemandStatus) {
        this.serviceDemandStatus = serviceDemandStatus;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }


    public List<Long> getIdsList() {
        return idsList;
    }

    public void setIdsList(List<Long> idsList) {
        this.idsList = idsList;
    }

    public BigDecimal getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(BigDecimal orderMoney) {
        this.orderMoney = orderMoney;
    }

    public BigDecimal getBuyerAddrLon() {
        return buyerAddrLon;
    }

    public void setBuyerAddrLon(BigDecimal buyerAddrLon) {
        this.buyerAddrLon = buyerAddrLon;
    }

    public BigDecimal getBuyerAddrLat() {
        return buyerAddrLat;
    }

    public void setBuyerAddrLat(BigDecimal buyerAddrLat) {
        this.buyerAddrLat = buyerAddrLat;
    }

    public BigDecimal getSellerAddrLon() {
        return sellerAddrLon;
    }

    public void setSellerAddrLon(BigDecimal sellerAddrLon) {
        this.sellerAddrLon = sellerAddrLon;
    }

    public BigDecimal getSellerAddrLat() {
        return sellerAddrLat;
    }

    public void setSellerAddrLat(BigDecimal sellerAddrLat) {
        this.sellerAddrLat = sellerAddrLat;
    }

    public BigDecimal getAvgWeight() {
        return avgWeight;
    }

    public void setAvgWeight(BigDecimal avgWeight) {
        this.avgWeight = avgWeight;
    }

    public BigDecimal getSaleGoodsNum() {
        return saleGoodsNum;
    }

    public void setSaleGoodsNum(BigDecimal saleGoodsNum) {
        this.saleGoodsNum = saleGoodsNum;
    }

    public BigDecimal getTodayBusinessCount() {
        return todayBusinessCount;
    }

    public void setTodayBusinessCount(BigDecimal todayBusinessCount) {
        this.todayBusinessCount = todayBusinessCount;
    }

    public BigDecimal getTodayBusinessNum() {
        return todayBusinessNum;
    }

    public void setTodayBusinessNum(BigDecimal todayBusinessNum) {
        this.todayBusinessNum = todayBusinessNum;
    }

    public BigDecimal getRangeBusinessCount() {
        return rangeBusinessCount;
    }

    public void setRangeBusinessCount(BigDecimal rangeBusinessCount) {
        this.rangeBusinessCount = rangeBusinessCount;
    }

    public BigDecimal getRangeBusinessNum() {
        return rangeBusinessNum;
    }

    public void setRangeBusinessNum(BigDecimal rangeBusinessNum) {
        this.rangeBusinessNum = rangeBusinessNum;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getTodayVolume() {
        return todayVolume;
    }

    public void setTodayVolume(BigDecimal todayVolume) {
        this.todayVolume = todayVolume;
    }

    public BigDecimal getRangeVolume() {
        return rangeVolume;
    }

    public void setRangeVolume(BigDecimal rangeVolume) {
        this.rangeVolume = rangeVolume;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public Integer getNewShopNum() {
        return newShopNum;
    }

    public void setNewShopNum(Integer newShopNum) {
        this.newShopNum = newShopNum;
    }

    public Integer getNewShopRangeNum() {
        return newShopRangeNum;
    }

    public void setNewShopRangeNum(Integer newShopRangeNum) {
        this.newShopRangeNum = newShopRangeNum;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBusinessCount() {
        return businessCount;
    }

    public void setBusinessCount(BigDecimal businessCount) {
        this.businessCount = businessCount;
    }

    public BigDecimal getBusinessNum() {
        return businessNum;
    }

    public void setBusinessNum(BigDecimal businessNum) {
        this.businessNum = businessNum;
    }

    public List<Long> getSellerBoIdList() {
        return sellerBoIdList;
    }

    public void setSellerBoIdList(List<Long> sellerBoIdList) {
        this.sellerBoIdList = sellerBoIdList;
    }

    public List<Long> getBuyerBoIdList() {
        return buyerBoIdList;
    }

    public void setBuyerBoIdList(List<Long> buyerBoIdList) {
        this.buyerBoIdList = buyerBoIdList;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getShopPhone() {
        return shopPhone;
    }

    public void setShopPhone(String shopPhone) {
        this.shopPhone = shopPhone;
    }

    public String getStartOrderTime() {
        return startOrderTime;
    }

    public void setStartOrderTime(String startOrderTime) {
        this.startOrderTime = startOrderTime;
    }

    public String getEndOrderTime() {
        return endOrderTime;
    }

    public void setEndOrderTime(String endOrderTime) {
        this.endOrderTime = endOrderTime;
    }

    public String getStartBalanceTime() {
        return startBalanceTime;
    }

    public void setStartBalanceTime(String startBalanceTime) {
        this.startBalanceTime = startBalanceTime;
    }

    public String getEndBalanceTime() {
        return endBalanceTime;
    }

    public void setEndBalanceTime(String endBalanceTime) {
        this.endBalanceTime = endBalanceTime;
    }

    public List<String> getTypesList() {
        return typesList;
    }

    public void setTypesList(List<String> typesList) {
        this.typesList = typesList;
    }



    public Date getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(Date arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBuyerBoId() {
        return buyerBoId;
    }

    public void setBuyerBoId(Long buyerBoId) {
        this.buyerBoId = buyerBoId;
    }

    public Long getBuyerOperatorBoId() {
        return buyerOperatorBoId;
    }

    public void setBuyerOperatorBoId(Long buyerOperatorBoId) {
        this.buyerOperatorBoId = buyerOperatorBoId;
    }

    public String getBuyerUserType() {
        return buyerUserType;
    }

    public void setBuyerUserType(String buyerUserType) {
        this.buyerUserType = buyerUserType == null ? null : buyerUserType.trim();
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public Long getSellerOperatorBoId() {
        return sellerOperatorBoId;
    }

    public void setSellerOperatorBoId(Long sellerOperatorBoId) {
        this.sellerOperatorBoId = sellerOperatorBoId;
    }

    public String getSellerUserType() {
        return sellerUserType;
    }

    public void setSellerUserType(String sellerUserType) {
        this.sellerUserType = sellerUserType == null ? null : sellerUserType.trim();
    }

    public Long getOrigShopId() {
        return origShopId;
    }

    public void setOrigShopId(Long origShopId) {
        this.origShopId = origShopId;
    }

    public Long getOrigSellerBoId() {
        return origSellerBoId;
    }

    public void setOrigSellerBoId(Long origSellerBoId) {
        this.origSellerBoId = origSellerBoId;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType == null ? null : saleType.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus == null ? null : paymentStatus.trim();
    }

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus == null ? null : sendStatus.trim();
    }

    public String getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(String receiveStatus) {
        this.receiveStatus = receiveStatus == null ? null : receiveStatus.trim();
    }

    public String getBalanceStatus() {
        return balanceStatus;
    }

    public void setBalanceStatus(String balanceStatus) {
        this.balanceStatus = balanceStatus == null ? null : balanceStatus.trim();
    }

    public String getReturnGoodsStatus() {
        return returnGoodsStatus;
    }

    public void setReturnGoodsStatus(String returnGoodsStatus) {
        this.returnGoodsStatus = returnGoodsStatus == null ? null : returnGoodsStatus.trim();
    }

    public String getRefundsStatus() {
        return refundsStatus;
    }

    public void setRefundsStatus(String refundsStatus) {
        this.refundsStatus = refundsStatus == null ? null : refundsStatus.trim();
    }

    public String getRefundsReason() {
        return refundsReason;
    }

    public void setRefundsReason(String refundsReason) {
        this.refundsReason = refundsReason == null ? null : refundsReason.trim();
    }

    public Date getRefundsApplyTime() {
        return refundsApplyTime;
    }

    public void setRefundsApplyTime(Date refundsApplyTime) {
        this.refundsApplyTime = refundsApplyTime;
    }

    public String getBuyerVoucherStatus() {
        return buyerVoucherStatus;
    }

    public void setBuyerVoucherStatus(String buyerVoucherStatus) {
        this.buyerVoucherStatus = buyerVoucherStatus == null ? null : buyerVoucherStatus.trim();
    }

    public String getSellerVoucherStatus() {
        return sellerVoucherStatus;
    }

    public void setSellerVoucherStatus(String sellerVoucherStatus) {
        this.sellerVoucherStatus = sellerVoucherStatus == null ? null : sellerVoucherStatus.trim();
    }

    public String getVoucherApprovalStatus() {
        return voucherApprovalStatus;
    }

    public void setVoucherApprovalStatus(String voucherApprovalStatus) {
        this.voucherApprovalStatus = voucherApprovalStatus == null ? null : voucherApprovalStatus.trim();
    }

    public String getFinishStatus() {
        return finishStatus;
    }

    public void setFinishStatus(String finishStatus) {
        this.finishStatus = finishStatus == null ? null : finishStatus.trim();
    }

    public String getServiceFeeType() {
        return serviceFeeType;
    }

    public void setServiceFeeType(String serviceFeeType) {
        this.serviceFeeType = serviceFeeType == null ? null : serviceFeeType.trim();
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType == null ? null : changeType.trim();
    }

    public String getChangeStatus() {
        return changeStatus;
    }

    public void setChangeStatus(String changeStatus) {
        this.changeStatus = changeStatus == null ? null : changeStatus.trim();
    }

    public Byte getBuyerFeedback() {
        return buyerFeedback;
    }

    public void setBuyerFeedback(Byte buyerFeedback) {
        this.buyerFeedback = buyerFeedback;
    }

    public Byte getSellerFeedback() {
        return sellerFeedback;
    }

    public void setSellerFeedback(Byte sellerFeedback) {
        this.sellerFeedback = sellerFeedback;
    }

    public Byte getBuyerDefault() {
        return buyerDefault;
    }

    public void setBuyerDefault(Byte buyerDefault) {
        this.buyerDefault = buyerDefault;
    }

    public Byte getSellerDefault() {
        return sellerDefault;
    }

    public void setSellerDefault(Byte sellerDefault) {
        this.sellerDefault = sellerDefault;
    }

    public Byte getBuyerInsure() {
        return buyerInsure;
    }

    public void setBuyerInsure(Byte buyerInsure) {
        this.buyerInsure = buyerInsure;
    }

    public Byte getSellerInsure() {
        return sellerInsure;
    }

    public void setSellerInsure(Byte sellerInsure) {
        this.sellerInsure = sellerInsure;
    }

    public Byte getBuyerHide() {
        return buyerHide;
    }

    public void setBuyerHide(Byte buyerHide) {
        this.buyerHide = buyerHide;
    }

    public Byte getSellerHide() {
        return sellerHide;
    }

    public void setSellerHide(Byte sellerHide) {
        this.sellerHide = sellerHide;
    }

    public BigDecimal getGoodsOrigMoney() {
        return goodsOrigMoney;
    }

    public void setGoodsOrigMoney(BigDecimal goodsOrigMoney) {
        this.goodsOrigMoney = goodsOrigMoney;
    }

    public BigDecimal getGoodsDealMoney() {
        return goodsDealMoney;
    }

    public void setGoodsDealMoney(BigDecimal goodsDealMoney) {
        this.goodsDealMoney = goodsDealMoney;
    }

    public BigDecimal getGoodsDiscountMoney() {
        return goodsDiscountMoney;
    }

    public void setGoodsDiscountMoney(BigDecimal goodsDiscountMoney) {
        this.goodsDiscountMoney = goodsDiscountMoney;
    }

    public BigDecimal getGoodsPayableMoney() {
        return goodsPayableMoney;
    }

    public void setGoodsPayableMoney(BigDecimal goodsPayableMoney) {
        this.goodsPayableMoney = goodsPayableMoney;
    }

    public BigDecimal getFreightPayableMoney() {
        return freightPayableMoney;
    }

    public void setFreightPayableMoney(BigDecimal freightPayableMoney) {
        this.freightPayableMoney = freightPayableMoney;
    }

    public BigDecimal getOtherPayableMoney() {
        return otherPayableMoney;
    }

    public void setOtherPayableMoney(BigDecimal otherPayableMoney) {
        this.otherPayableMoney = otherPayableMoney;
    }

    public BigDecimal getInsuranceMoney() {
        return insuranceMoney;
    }

    public void setInsuranceMoney(BigDecimal insuranceMoney) {
        this.insuranceMoney = insuranceMoney;
    }

    public BigDecimal getAdvancePaymentMoney() {
        return advancePaymentMoney;
    }

    public void setAdvancePaymentMoney(BigDecimal advancePaymentMoney) {
        this.advancePaymentMoney = advancePaymentMoney;
    }

    public BigDecimal getDeductionMoney() {
        return deductionMoney;
    }

    public void setDeductionMoney(BigDecimal deductionMoney) {
        this.deductionMoney = deductionMoney;
    }

    public BigDecimal getIgnoreMoney() {
        return ignoreMoney;
    }

    public void setIgnoreMoney(BigDecimal ignoreMoney) {
        this.ignoreMoney = ignoreMoney;
    }

    public BigDecimal getBuyerServiceFee() {
        return buyerServiceFee;
    }

    public void setBuyerServiceFee(BigDecimal buyerServiceFee) {
        this.buyerServiceFee = buyerServiceFee;
    }

    public BigDecimal getSellerServiceFee() {
        return sellerServiceFee;
    }

    public void setSellerServiceFee(BigDecimal sellerServiceFee) {
        this.sellerServiceFee = sellerServiceFee;
    }

    public BigDecimal getRefundsApplyMoney() {
        return refundsApplyMoney;
    }

    public void setRefundsApplyMoney(BigDecimal refundsApplyMoney) {
        this.refundsApplyMoney = refundsApplyMoney;
    }

    public BigDecimal getRefundsActualMoney() {
        return refundsActualMoney;
    }

    public void setRefundsActualMoney(BigDecimal refundsActualMoney) {
        this.refundsActualMoney = refundsActualMoney;
    }

    public BigDecimal getPayableMoney() {
        return payableMoney;
    }

    public void setPayableMoney(BigDecimal payableMoney) {
        this.payableMoney = payableMoney;
    }

    public BigDecimal getPaidMoney() {
        return paidMoney;
    }

    public void setPaidMoney(BigDecimal paidMoney) {
        this.paidMoney = paidMoney;
    }

    public BigDecimal getCashMoney() {
        return cashMoney;
    }

    public void setCashMoney(BigDecimal cashMoney) {
        this.cashMoney = cashMoney;
    }

    public BigDecimal getPaidFreightMoney() {
        return paidFreightMoney;
    }

    public void setPaidFreightMoney(BigDecimal paidFreightMoney) {
        this.paidFreightMoney = paidFreightMoney;
    }

    public BigDecimal getPaidGoodsMoney() {
        return paidGoodsMoney;
    }

    public void setPaidGoodsMoney(BigDecimal paidGoodsMoney) {
        this.paidGoodsMoney = paidGoodsMoney;
    }

    public BigDecimal getCouponMoney() {
        return couponMoney;
    }

    public void setCouponMoney(BigDecimal couponMoney) {
        this.couponMoney = couponMoney;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public Date getExpectedArrivalTime() {
        return expectedArrivalTime;
    }

    public void setExpectedArrivalTime(Date expectedArrivalTime) {
        this.expectedArrivalTime = expectedArrivalTime;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public Date getBalanceTime() {
        return balanceTime;
    }

    public void setBalanceTime(Date balanceTime) {
        this.balanceTime = balanceTime;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Date getReturnGoodsTime() {
        return returnGoodsTime;
    }

    public void setReturnGoodsTime(Date returnGoodsTime) {
        this.returnGoodsTime = returnGoodsTime;
    }

    public Date getRefundsTime() {
        return refundsTime;
    }

    public void setRefundsTime(Date refundsTime) {
        this.refundsTime = refundsTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment == null ? null : payment.trim();
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance == null ? null : balance.trim();
    }

    public String getLogistics() {
        return logistics;
    }

    public void setLogistics(String logistics) {
        this.logistics = logistics == null ? null : logistics.trim();
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Long getAddrId() {
        return addrId;
    }

    public void setAddrId(Long addrId) {
        this.addrId = addrId;
    }

    public String getCancelType() {
        return cancelType;
    }

    public void setCancelType(String cancelType) {
        this.cancelType = cancelType == null ? null : cancelType.trim();
    }

    public String getCancelStatus() {
        return cancelStatus;
    }

    public void setCancelStatus(String cancelStatus) {
        this.cancelStatus = cancelStatus == null ? null : cancelStatus.trim();
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason == null ? null : cancelReason.trim();
    }

    public Byte getIsDeposit() {
        return isDeposit;
    }

    public void setIsDeposit(Byte isDeposit) {
        this.isDeposit = isDeposit;
    }

    public Byte getIsAuction() {
        return isAuction;
    }

    public void setIsAuction(Byte isAuction) {
        this.isAuction = isAuction;
    }

    public Byte getIsHangup() {
        return isHangup;
    }

    public void setIsHangup(Byte isHangup) {
        this.isHangup = isHangup;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        return "OrderInfoEntity{" +
                "id=" + id +
                ", buyerBoId=" + buyerBoId +
                ", buyerOperatorBoId=" + buyerOperatorBoId +
                ", buyerUserType='" + buyerUserType + '\'' +
                ", shopId=" + shopId +
                ", sellerBoId=" + sellerBoId +
                ", sellerOperatorBoId=" + sellerOperatorBoId +
                ", sellerUserType='" + sellerUserType + '\'' +
                ", origShopId=" + origShopId +
                ", origSellerBoId=" + origSellerBoId +
                ", saleType='" + saleType + '\'' +
                ", type='" + type + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", sendStatus='" + sendStatus + '\'' +
                ", receiveStatus='" + receiveStatus + '\'' +
                ", balanceStatus='" + balanceStatus + '\'' +
                ", returnGoodsStatus='" + returnGoodsStatus + '\'' +
                ", refundsStatus='" + refundsStatus + '\'' +
                ", refundsReason='" + refundsReason + '\'' +
                ", refundsApplyTime=" + refundsApplyTime +
                ", buyerVoucherStatus='" + buyerVoucherStatus + '\'' +
                ", sellerVoucherStatus='" + sellerVoucherStatus + '\'' +
                ", voucherApprovalStatus='" + voucherApprovalStatus + '\'' +
                ", finishStatus='" + finishStatus + '\'' +
                ", serviceFeeType='" + serviceFeeType + '\'' +
                ", changeType='" + changeType + '\'' +
                ", changeStatus='" + changeStatus + '\'' +
                ", buyerFeedback=" + buyerFeedback +
                ", sellerFeedback=" + sellerFeedback +
                ", buyerDefault=" + buyerDefault +
                ", sellerDefault=" + sellerDefault +
                ", buyerInsure=" + buyerInsure +
                ", sellerInsure=" + sellerInsure +
                ", buyerHide=" + buyerHide +
                ", sellerHide=" + sellerHide +
                ", goodsOrigMoney=" + goodsOrigMoney +
                ", goodsDealMoney=" + goodsDealMoney +
                ", goodsDiscountMoney=" + goodsDiscountMoney +
                ", goodsPayableMoney=" + goodsPayableMoney +
                ", freightPayableMoney=" + freightPayableMoney +
                ", otherPayableMoney=" + otherPayableMoney +
                ", insuranceMoney=" + insuranceMoney +
                ", advancePaymentMoney=" + advancePaymentMoney +
                ", deductionMoney=" + deductionMoney +
                ", ignoreMoney=" + ignoreMoney +
                ", buyerServiceFee=" + buyerServiceFee +
                ", sellerServiceFee=" + sellerServiceFee +
                ", refundsApplyMoney=" + refundsApplyMoney +
                ", refundsActualMoney=" + refundsActualMoney +
                ", payableMoney=" + payableMoney +
                ", paidMoney=" + paidMoney +
                ", cashMoney=" + cashMoney +
                ", paidFreightMoney=" + paidFreightMoney +
                ", paidGoodsMoney=" + paidGoodsMoney +
                ", couponMoney=" + couponMoney +
                ", orderTime=" + orderTime +
                ", paymentTime=" + paymentTime +
                ", sendTime=" + sendTime +
                ", expectedArrivalTime=" + expectedArrivalTime +
                ", receiveTime=" + receiveTime +
                ", balanceTime=" + balanceTime +
                ", cancelTime=" + cancelTime +
                ", returnGoodsTime=" + returnGoodsTime +
                ", refundsTime=" + refundsTime +
                ", finishTime=" + finishTime +
                ", payment='" + payment + '\'' +
                ", balance='" + balance + '\'' +
                ", logistics='" + logistics + '\'' +
                ", invoiceId=" + invoiceId +
                ", addrId=" + addrId +
                ", cancelType='" + cancelType + '\'' +
                ", cancelStatus='" + cancelStatus + '\'' +
                ", cancelReason='" + cancelReason + '\'' +
                ", isDeposit=" + isDeposit +
                ", isAuction=" + isAuction +
                ", isHangup=" + isHangup +
                ", memo='" + memo + '\'' +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                '}';
    }
}
