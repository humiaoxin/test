package com.nxin.etposvr.dm.report.controller.res;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 收支分析返回参数
 */
public class RecordBookkeepingDmResForm {

    /** 累计收入 */
    private BigDecimal srTotalMoney;
    /** 累计支出 */
    private BigDecimal zcTotalMoney;
    /** 日期 */
    private Date bookkeepingDate;
    /** 类型 */
    private String type;
    /** 类型名称 */
    private String typeCn;
    /** 类别 */
    private String way;
    /** 类别 */
    private String wayCn;
    /** 金额 */
    private String money;

    private String entryType;

    private String entryTypeCn;

    private List<RecordBookkeepingDmResForm> resFormList;

    public BigDecimal getSrTotalMoney() {
        return srTotalMoney;
    }

    public void setSrTotalMoney(BigDecimal srTotalMoney) {
        this.srTotalMoney = srTotalMoney;
    }

    public BigDecimal getZcTotalMoney() {
        return zcTotalMoney;
    }

    public void setZcTotalMoney(BigDecimal zcTotalMoney) {
        this.zcTotalMoney = zcTotalMoney;
    }

    public Date getBookkeepingDate() {
        return bookkeepingDate;
    }

    public void setBookkeepingDate(Date bookkeepingDate) {
        this.bookkeepingDate = bookkeepingDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeCn() {
        return typeCn;
    }

    public void setTypeCn(String typeCn) {
        this.typeCn = typeCn;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getWayCn() {
        return wayCn;
    }

    public void setWayCn(String wayCn) {
        this.wayCn = wayCn;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public List<RecordBookkeepingDmResForm> getResFormList() {
        return resFormList;
    }

    public void setResFormList(List<RecordBookkeepingDmResForm> resFormList) {
        this.resFormList = resFormList;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public String getEntryTypeCn() {
        return entryTypeCn;
    }

    public void setEntryTypeCn(String entryTypeCn) {
        this.entryTypeCn = entryTypeCn;
    }

    @Override
    public String toString() {
        return "RecordBookkeepingDmResForm{" +
                "srTotalMoney=" + srTotalMoney +
                ", zcTotalMoney=" + zcTotalMoney +
                ", bookkeepingDate=" + bookkeepingDate +
                ", type='" + type + '\'' +
                ", typeCn='" + typeCn + '\'' +
                ", way='" + way + '\'' +
                ", wayCn='" + wayCn + '\'' +
                ", money='" + money + '\'' +
                ", entryType='" + entryType + '\'' +
                ", entryTypeCn='" + entryTypeCn + '\'' +
                ", resFormList=" + resFormList +
                '}';
    }
}
