package com.nxin.etposvr.dm.remind.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * 提醒
 *
 * @author sjw
 * @version v_1.0.1
 * @since 2019/11/16
 */
public class RemindDmReqForm extends WebPageParam {
    @ApiModelProperty(value = "提醒类别", example = "4")
    @NotNull(message = "000001|提醒类别", groups = {VldGroup1th.class})
    private String type;

    @ApiModelProperty(value = "所属系统", example = "4")
    private Byte systemId;

    /**
     * 主体用户ID
     */
    private Long boId;
    /**
     * 操作人用户ID
     */
    private Long oprBoId;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }
}
