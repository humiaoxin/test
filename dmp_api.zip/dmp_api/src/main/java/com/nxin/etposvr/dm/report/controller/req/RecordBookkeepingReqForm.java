package com.nxin.etposvr.dm.report.controller.req;

import java.util.Date;

/**
 * 收支分析实体
 */
public class RecordBookkeepingReqForm {
    /**
     * 基础信息ID
     */
    private Long infoId;
    /** 类别 */
    private String way;
    private String entryType;

    /** 开始日期 */
    private Date startDate;
    /** 结束日期 */
    private Date endDate;
    /** 主体用户ID */
    private Long boId;
    /** 操作人用户ID */
    private Long oprBoId;

    private Byte systemId;

    public Long getInfoId() {
        return infoId;
    }

    public void setInfoId(Long infoId) {
        this.infoId = infoId;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "RecordBookkeepingReqForm{" +
                "infoId=" + infoId +
                ", way='" + way + '\'' +
                ", entryType='" + entryType + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", boId=" + boId +
                ", oprBoId=" + oprBoId +
                ", systemId=" + systemId +
                '}';
    }
}
