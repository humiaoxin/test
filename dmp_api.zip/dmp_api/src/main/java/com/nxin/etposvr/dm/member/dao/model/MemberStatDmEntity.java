package com.nxin.etposvr.dm.member.dao.model;

import java.util.Date;

/**
 * @author LS
 * @date 2019/10/28
 */
public class MemberStatDmEntity {
    /**
     * 开始时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date startTime;
    /**
     * 结束时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date endTime;

    /**
     * 统计类型
     * DAY-按日统计
     * MON-按月统计
     * YEAR-按年统计
     * 其他-全部统计
     *
     * @author LS
     * @date 2019/10/28
     */
    private String statType;

    /**
     * 时间
     * 日(yyyy-MM-dd)
     * 月(yyyy-MM)
     * 年(yyyy)
     *
     * @author LS
     * @date 2019/10/28
     */
    private String period;
    /**
     * 用户类型
     * GR-个人
     * GT-个体
     * QY-企业
     *
     * @author LS
     * @date 2019/10/28
     */
    private String userType;
    /**
     * 总数量
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long totalNum = 0L;

    /**
     * 所属系统
     *
     * @author LS
     * @date 2019/10/28
     */
    private Byte systemId;

    /**
     * 地区层级串模糊
     *
     * @author LS
     * @date 2019/10/29
     */
    private String areaAxisLike;

    /**
     * 来源
     *
     * @author lpp
     * @date 2020/4/17 13:59
     */
    private String source;

    /**
     * 地区等级
     *
     * @author lpp
     * @date 2020/4/17 15:11
     */
    private Integer areaRank = 1;
    /**
     * 地区层级串
     *
     * @author lpp
     * @date 2020/4/17 15:17
     */
    private String areaAxis;

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public Integer getAreaRank() {
        return areaRank;
    }

    public void setAreaRank(Integer areaRank) {
        this.areaRank = areaRank;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Long getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Long totalNum) {
        this.totalNum = totalNum;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    @Override
    public String toString() {
        return "MemberStatDmEntity{" +
                "startTime=" + startTime +
                ", endTime=" + endTime +
                ", statType='" + statType + '\'' +
                ", period='" + period + '\'' +
                ", userType='" + userType + '\'' +
                ", totalNum=" + totalNum +
                ", systemId=" + systemId +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                '}';
    }
}
