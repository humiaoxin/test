package com.nxin.etposvr.dm.shop.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

public class ShopInfoDmReqForm extends WebPageParam {

    public String id;

    public String name;

    private String systemId;

    public String busiScopeCode;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    private String areaAxis;

    private String areaFullName;

    private String busiScopeName;

    private String shopName;

    private String logo;

    private int goodsCount;
    /**
     * 编码模糊查询
     */
    private String idLike;
    /**
     * 店铺名称模糊查询
     */
    private String shopNameLike;
    /**
     * 店主姓名模糊查询
     */
    private String linkmanLike;
    /**
     * 店主电话模糊查询
     */
    private String telLike;
    /**
     * 审核状态查询
     */
    private String auditStatus;
    /**
     * 地区AXIS模糊查询
     */
    private String areaAxisLike;
    /**
     * 身份类型
     */
    private String userType;
    /**
     * 申请开始时间
     */
    private Date applyTimeStart;
    /**
     * 申请结束时间
     */
    private Date applyTimeEnd;
    /**
     * 客户boId集合
     */
    @ApiModelProperty(value = "客户boId集合", example = "110119011415270001", dataType = "List")
    @NotNull(message = "000001|客户boId集合", groups = {VldGroup2th.class})
    public List<Long> boIdList;

    /**
     * 店铺企业名称模糊查询
     *
     * @author lpp
     * @date 2020/3/16 14:23
     */
    private String realNameLike;
    /**
     * 创建时间开始
     *
     * @author lpp
     * @date 2020/3/16 14:23
     */
    private Date createTimeStart;
    /**
     * 创建时间结束
     *
     * @author lpp
     * @date 2020/3/16 14:23
     */
    private Date createTimeEnd;
    /**
     * 店铺电话
     *
     * @author lpp
     * @date 2020/3/16 15:17
     */
    private String tel;

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getRealNameLike() {
        return realNameLike;
    }

    public void setRealNameLike(String realNameLike) {
        this.realNameLike = realNameLike;
    }

    public Date getCreateTimeStart() {
        return createTimeStart;
    }

    public void setCreateTimeStart(Date createTimeStart) {
        this.createTimeStart = createTimeStart;
    }

    public Date getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(Date createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getBusiScopeName() {
        return busiScopeName;
    }

    public void setBusiScopeName(String busiScopeName) {
        this.busiScopeName = busiScopeName;
    }

    public String getBusiScopeCode() {
        return busiScopeCode;
    }

    public void setBusiScopeCode(String busiScopeCode) {
        this.busiScopeCode = busiScopeCode;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public int getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(int goodsCount) {
        this.goodsCount = goodsCount;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public String getIdLike() {
        return idLike;
    }

    public void setIdLike(String idLike) {
        this.idLike = idLike;
    }

    public String getShopNameLike() {
        return shopNameLike;
    }

    public void setShopNameLike(String shopNameLike) {
        this.shopNameLike = shopNameLike;
    }

    public String getLinkmanLike() {
        return linkmanLike;
    }

    public void setLinkmanLike(String linkmanLike) {
        this.linkmanLike = linkmanLike;
    }

    public String getTelLike() {
        return telLike;
    }

    public void setTelLike(String telLike) {
        this.telLike = telLike;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Date getApplyTimeStart() {
        return applyTimeStart;
    }

    public void setApplyTimeStart(Date applyTimeStart) {
        this.applyTimeStart = applyTimeStart;
    }

    public Date getApplyTimeEnd() {
        return applyTimeEnd;
    }

    public void setApplyTimeEnd(Date applyTimeEnd) {
        this.applyTimeEnd = applyTimeEnd;
    }

    @Override
    public String toString() {
        return "ShopInfoDmReqForm{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", systemId='" + systemId + '\'' +
                ", busiScopeCode='" + busiScopeCode + '\'' +
                ", oneAreaId='" + oneAreaId + '\'' +
                ", twoAreaId='" + twoAreaId + '\'' +
                ", areaId='" + areaId + '\'' +
                ", areaAxis='" + areaAxis + '\'' +
                ", areaFullName='" + areaFullName + '\'' +
                ", busiScopeName='" + busiScopeName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", logo='" + logo + '\'' +
                ", goodsCount=" + goodsCount +
                ", idLike='" + idLike + '\'' +
                ", shopNameLike='" + shopNameLike + '\'' +
                ", linkmanLike='" + linkmanLike + '\'' +
                ", telLike='" + telLike + '\'' +
                ", auditStatus='" + auditStatus + '\'' +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                ", userType='" + userType + '\'' +
                ", applyTimeStart='" + applyTimeStart + '\'' +
                ", applyTimeEnd='" + applyTimeEnd + '\'' +
                ", boIdList=" + boIdList +
                '}';
    }
}
