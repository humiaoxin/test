package com.nxin.etposvr.dm.elasticsearch.dao.model;

/**
 * 用户标签
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/6/11 20:42
 */
public class MemberTagEsEntity {

    private String tagsType;

    private String tagsCode;

    private String tags;

    public String getTagsType() {
        return tagsType;
    }

    public void setTagsType(String tagsType) {
        this.tagsType = tagsType;
    }

    public String getTagsCode() {
        return tagsCode;
    }

    public void setTagsCode(String tagsCode) {
        this.tagsCode = tagsCode;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }
}
