package com.nxin.etposvr.dm.elasticsearch.controller.res;

import com.nxin.etposvr.dm.elasticsearch.dao.model.ShopEsEntity;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/9 21:31
 */
public class ShopEsResForm  extends ShopEsEntity {

}
