package com.nxin.etposvr.dm.order.controller.res;

import java.math.BigDecimal;

/**
 * 交易量趋势返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class OrderBusinessTrendResForm {

    /**交易额*/
    private BigDecimal amount;
    /**交易量（笔）*/
    private BigDecimal businessCount;
    /**日期*/
    private String dates;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBusinessCount() {
        return businessCount;
    }

    public void setBusinessCount(BigDecimal businessCount) {
        this.businessCount = businessCount;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }
}
