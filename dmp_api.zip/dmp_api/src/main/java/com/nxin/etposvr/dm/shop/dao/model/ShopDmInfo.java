package com.nxin.etposvr.dm.shop.dao.model;

/**
 * 店铺增长趋势返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class ShopDmInfo {

    /**店铺数量*/
    private Integer num;
    /**店铺类型*/
    public String userType;

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
}
