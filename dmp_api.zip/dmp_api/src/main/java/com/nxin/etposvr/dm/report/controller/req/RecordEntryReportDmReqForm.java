package com.nxin.etposvr.dm.report.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;
import java.util.Map;

/**
 * 报表入参
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/11/18 15:16
 */

public class RecordEntryReportDmReqForm extends WebPageParam {
    @ApiModelProperty(value = "地块id", example = "", dataType = "String")
    private Long baseInfoId;
    @ApiModelProperty(value = "查询开始时间", example = "", dataType = "String")
    private String timeStart;
    @ApiModelProperty(value = "查询结束时间", example = "", dataType = "String")
    private String timeEnd;

    private Long boId;

    private Long manufacturerId;

    private String recordType;

    private String baseInfoType;

    private String groupType;;

    private String recordAttrType;

    private String recordAttrInfoDefType;

    private Byte systemId;

    private List<Long> categoryIdList;

    private  String numUnit;

    private List<String> categoryAxisLikeList;

    private String categoryAxisLike;

    private Map<String, List<String>> typeMap;

    private String statType;

    private String dataYear;

    private String dataYearNum;

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public String getDataYearNum() {
        return dataYearNum;
    }

    public void setDataYearNum(String dataYearNum) {
        this.dataYearNum = dataYearNum;
    }

    public List<String> getCategoryAxisLikeList() {
        return categoryAxisLikeList;
    }

    public void setCategoryAxisLikeList(List<String> categoryAxisLikeList) {
        this.categoryAxisLikeList = categoryAxisLikeList;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Map<String, List<String>> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(Map<String, List<String>> typeMap) {
        this.typeMap = typeMap;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getNumUnit() {
        return numUnit;
    }

    public void setNumUnit(String numUnit) {
        this.numUnit = numUnit;
    }

    public List<Long> getCategoryIdList() {
        return categoryIdList;
    }

    public void setCategoryIdList(List<Long> categoryIdList) {
        this.categoryIdList = categoryIdList;
    }

    public String getRecordAttrInfoDefType() {
        return recordAttrInfoDefType;
    }

    public void setRecordAttrInfoDefType(String recordAttrInfoDefType) {
        this.recordAttrInfoDefType = recordAttrInfoDefType;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getBaseInfoType() {
        return baseInfoType;
    }

    public void setBaseInfoType(String baseInfoType) {
        this.baseInfoType = baseInfoType;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getRecordAttrType() {
        return recordAttrType;
    }

    public void setRecordAttrType(String recordAttrType) {
        this.recordAttrType = recordAttrType;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Long baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public Long getManufacturerId() {
        return manufacturerId;
    }

    public void setManufacturerId(Long manufacturerId) {
        this.manufacturerId = manufacturerId;
    }

    @Override
    public String toString() {
        return "RecordEntryReportDmReqForm{" +
                "baseInfoId=" + baseInfoId +
                ", timeStart='" + timeStart + '\'' +
                ", timeEnd='" + timeEnd + '\'' +
                ", boId=" + boId +
                ", manufacturerId=" + manufacturerId +
                ", recordType='" + recordType + '\'' +
                ", baseInfoType='" + baseInfoType + '\'' +
                ", groupType='" + groupType + '\'' +
                ", recordAttrType='" + recordAttrType + '\'' +
                ", recordAttrInfoDefType='" + recordAttrInfoDefType + '\'' +
                ", systemId=" + systemId +
                ", categoryIdList=" + categoryIdList +
                ", numUnit='" + numUnit + '\'' +
                '}';
    }
}
