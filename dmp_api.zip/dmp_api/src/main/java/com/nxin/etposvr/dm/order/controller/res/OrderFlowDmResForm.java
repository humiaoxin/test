package com.nxin.etposvr.dm.order.controller.res;

import java.math.BigDecimal;

/**
 * 订单流转返回实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class OrderFlowDmResForm {

    /**卖家经度*/
    private BigDecimal buyerAddrLon;
    /**卖家纬度*/
    private BigDecimal buyerAddrLat;
    /**买家经度*/
    private BigDecimal sellerAddrLon;
    /**买家纬度*/
    private BigDecimal sellerAddrLat;
    /**订单金额*/
    private BigDecimal orderMoney;
    /**买家地区*/
    private String buyerAreaName;
    /**卖家地区*/
    private String sellerAreaName;

    public String getBuyerAreaName() {
        return buyerAreaName;
    }

    public void setBuyerAreaName(String buyerAreaName) {
        this.buyerAreaName = buyerAreaName;
    }

    public String getSellerAreaName() {
        return sellerAreaName;
    }

    public void setSellerAreaName(String sellerAreaName) {
        this.sellerAreaName = sellerAreaName;
    }

    public BigDecimal getBuyerAddrLon() {
        return buyerAddrLon;
    }

    public void setBuyerAddrLon(BigDecimal buyerAddrLon) {
        this.buyerAddrLon = buyerAddrLon;
    }

    public BigDecimal getBuyerAddrLat() {
        return buyerAddrLat;
    }

    public void setBuyerAddrLat(BigDecimal buyerAddrLat) {
        this.buyerAddrLat = buyerAddrLat;
    }

    public BigDecimal getSellerAddrLon() {
        return sellerAddrLon;
    }

    public void setSellerAddrLon(BigDecimal sellerAddrLon) {
        this.sellerAddrLon = sellerAddrLon;
    }

    public BigDecimal getSellerAddrLat() {
        return sellerAddrLat;
    }

    public void setSellerAddrLat(BigDecimal sellerAddrLat) {
        this.sellerAddrLat = sellerAddrLat;
    }

    public BigDecimal getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(BigDecimal orderMoney) {
        this.orderMoney = orderMoney;
    }
}
