package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class OrderDmEntity {

    private Integer pageNum;
    private Integer pageSize;

    private List<Long> goodsIdList;

    public List<Long> boIdList;

    //店铺名称
    private String shopName;
    //卖家名称
    private String linkMan;
    //收货人
    private String personName;
    //收货人电话
    private String tel;

    private String  areaAxisLike;

    private Long id;

    private String type;

    private String payment;
    /**
     * 支付状态
     */
    private String paymentStatus;
    /**
     * 发货状态
     */
    private String sendStatus;
    /**
     * 收货状态
     */
    private String receiveStatus;
    /**
     * 结算状态
     */
    private String balanceStatus;

    private Byte systemId;

    private Long buyerBoId;

    private Long buyerOperatorBoId;

    private String buyerUserType;

    private Long shopId;

    private Long sellerBoId;

    private Long sellerOperatorBoId;

    private String sellerUserType;

    private Long origShopId;

    private Long origSellerBoId;

    private String saleType;

    private String returnGoodsStatus;

    private String refundsStatus;

    private String refundsReason;

    private Date refundsApplyTime;

    private String buyerVoucherStatus;

    private String sellerVoucherStatus;

    private String voucherApprovalStatus;

    private String finishStatus;

    private String serviceFeeType;

    private String changeType;

    private String changeStatus;

    private Byte buyerFeedback;

    private Byte sellerFeedback;

    private Byte buyerDefault;

    private Byte sellerDefault;

    private Byte buyerInsure;

    private Byte sellerInsure;

    private Byte buyerHide;

    private Byte sellerHide;

    private BigDecimal goodsOrigMoney;

    private BigDecimal goodsDealMoney;

    private BigDecimal goodsDiscountMoney;

    private BigDecimal goodsPayableMoney;

    private BigDecimal freightPayableMoney;

    private BigDecimal otherPayableMoney;

    private BigDecimal insuranceMoney;

    private BigDecimal advancePaymentMoney;

    private BigDecimal deductionMoney;

    private BigDecimal ignoreMoney;

    private BigDecimal buyerServiceFee;

    private BigDecimal sellerServiceFee;

    private BigDecimal refundsApplyMoney;

    private BigDecimal refundsActualMoney;

    private BigDecimal payableMoney;

    private BigDecimal paidMoney;

    private BigDecimal cashMoney;

    private BigDecimal paidFreightMoney;

    private BigDecimal paidGoodsMoney;

    private BigDecimal couponMoney;

    private Date orderTime;

    private Date paymentTime;

    private Date sendTime;

    private Date expectedArrivalTime;

    private Date receiveTime;

    private Date balanceTime;

    private Date cancelTime;

    private Date returnGoodsTime;

    private Date refundsTime;

    private Date finishTime;

    private String balance;

    private String logistics;

    private Long invoiceId;

    private Long addrId;

    private String cancelType;

    private String cancelStatus;

    private String cancelReason;

    private Byte isDeposit;

    private Byte isAuction;

    private Byte isHangup;

    private String memo;


    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Date arrivalTime;

    private Byte isEnabled;

    /**品类集合*/
    private List<Long> categoryIds;
    /**范围（天数、月数、年数）*/
    private Integer range;
    /**查询类型（按日DAY、按月MONTH、按年YEAR）*/
    private String statType;
    /**开始时间*/
    private Date startTime;
    /**结束时间*/
    private Date endTime;
    /**
     * 开始时间
     */
    private String startTimeStr;
    /**
     * 结束时间
     */
    private String endTimeStr;
    /**
     * 日期类型
     */
    private String pattern;
    /**
     * 截止查询时间
     */
    private String limitDate;

    /**
     * 品类ID
     */
    private Long categoryId;

    /**
     * 排除的品类集合
     */
    private List<Long> removeCategoryIds;

    /**
     * 品类层级
     */
    private Integer rank;

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getStartTimeStr() {
        return startTimeStr;
    }

    public void setStartTimeStr(String startTimeStr) {
        this.startTimeStr = startTimeStr;
    }

    public String getEndTimeStr() {
        return endTimeStr;
    }

    public void setEndTimeStr(String endTimeStr) {
        this.endTimeStr = endTimeStr;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getLimitDate() {
        return limitDate;
    }

    public void setLimitDate(String limitDate) {
        this.limitDate = limitDate;
    }

    public List<Long> getRemoveCategoryIds() {
        return removeCategoryIds;
    }

    public void setRemoveCategoryIds(List<Long> removeCategoryIds) {
        this.removeCategoryIds = removeCategoryIds;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public Long getBuyerBoId() {
        return buyerBoId;
    }

    public void setBuyerBoId(Long buyerBoId) {
        this.buyerBoId = buyerBoId;
    }

    public Long getBuyerOperatorBoId() {
        return buyerOperatorBoId;
    }

    public void setBuyerOperatorBoId(Long buyerOperatorBoId) {
        this.buyerOperatorBoId = buyerOperatorBoId;
    }

    public String getBuyerUserType() {
        return buyerUserType;
    }

    public void setBuyerUserType(String buyerUserType) {
        this.buyerUserType = buyerUserType;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public Long getSellerOperatorBoId() {
        return sellerOperatorBoId;
    }

    public void setSellerOperatorBoId(Long sellerOperatorBoId) {
        this.sellerOperatorBoId = sellerOperatorBoId;
    }

    public String getSellerUserType() {
        return sellerUserType;
    }

    public void setSellerUserType(String sellerUserType) {
        this.sellerUserType = sellerUserType;
    }

    public Long getOrigShopId() {
        return origShopId;
    }

    public void setOrigShopId(Long origShopId) {
        this.origShopId = origShopId;
    }

    public Long getOrigSellerBoId() {
        return origSellerBoId;
    }

    public void setOrigSellerBoId(Long origSellerBoId) {
        this.origSellerBoId = origSellerBoId;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getReturnGoodsStatus() {
        return returnGoodsStatus;
    }

    public void setReturnGoodsStatus(String returnGoodsStatus) {
        this.returnGoodsStatus = returnGoodsStatus;
    }

    public String getRefundsStatus() {
        return refundsStatus;
    }

    public void setRefundsStatus(String refundsStatus) {
        this.refundsStatus = refundsStatus;
    }

    public String getRefundsReason() {
        return refundsReason;
    }

    public void setRefundsReason(String refundsReason) {
        this.refundsReason = refundsReason;
    }

    public Date getRefundsApplyTime() {
        return refundsApplyTime;
    }

    public void setRefundsApplyTime(Date refundsApplyTime) {
        this.refundsApplyTime = refundsApplyTime;
    }

    public String getBuyerVoucherStatus() {
        return buyerVoucherStatus;
    }

    public void setBuyerVoucherStatus(String buyerVoucherStatus) {
        this.buyerVoucherStatus = buyerVoucherStatus;
    }

    public String getSellerVoucherStatus() {
        return sellerVoucherStatus;
    }

    public void setSellerVoucherStatus(String sellerVoucherStatus) {
        this.sellerVoucherStatus = sellerVoucherStatus;
    }

    public String getVoucherApprovalStatus() {
        return voucherApprovalStatus;
    }

    public void setVoucherApprovalStatus(String voucherApprovalStatus) {
        this.voucherApprovalStatus = voucherApprovalStatus;
    }

    public String getFinishStatus() {
        return finishStatus;
    }

    public void setFinishStatus(String finishStatus) {
        this.finishStatus = finishStatus;
    }

    public String getServiceFeeType() {
        return serviceFeeType;
    }

    public void setServiceFeeType(String serviceFeeType) {
        this.serviceFeeType = serviceFeeType;
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType;
    }

    public String getChangeStatus() {
        return changeStatus;
    }

    public void setChangeStatus(String changeStatus) {
        this.changeStatus = changeStatus;
    }

    public Byte getBuyerFeedback() {
        return buyerFeedback;
    }

    public void setBuyerFeedback(Byte buyerFeedback) {
        this.buyerFeedback = buyerFeedback;
    }

    public Byte getSellerFeedback() {
        return sellerFeedback;
    }

    public void setSellerFeedback(Byte sellerFeedback) {
        this.sellerFeedback = sellerFeedback;
    }

    public Byte getBuyerDefault() {
        return buyerDefault;
    }

    public void setBuyerDefault(Byte buyerDefault) {
        this.buyerDefault = buyerDefault;
    }

    public Byte getSellerDefault() {
        return sellerDefault;
    }

    public void setSellerDefault(Byte sellerDefault) {
        this.sellerDefault = sellerDefault;
    }

    public Byte getBuyerInsure() {
        return buyerInsure;
    }

    public void setBuyerInsure(Byte buyerInsure) {
        this.buyerInsure = buyerInsure;
    }

    public Byte getSellerInsure() {
        return sellerInsure;
    }

    public void setSellerInsure(Byte sellerInsure) {
        this.sellerInsure = sellerInsure;
    }

    public Byte getBuyerHide() {
        return buyerHide;
    }

    public void setBuyerHide(Byte buyerHide) {
        this.buyerHide = buyerHide;
    }

    public Byte getSellerHide() {
        return sellerHide;
    }

    public void setSellerHide(Byte sellerHide) {
        this.sellerHide = sellerHide;
    }

    public BigDecimal getGoodsOrigMoney() {
        return goodsOrigMoney;
    }

    public void setGoodsOrigMoney(BigDecimal goodsOrigMoney) {
        this.goodsOrigMoney = goodsOrigMoney;
    }

    public BigDecimal getGoodsDealMoney() {
        return goodsDealMoney;
    }

    public void setGoodsDealMoney(BigDecimal goodsDealMoney) {
        this.goodsDealMoney = goodsDealMoney;
    }

    public BigDecimal getGoodsDiscountMoney() {
        return goodsDiscountMoney;
    }

    public void setGoodsDiscountMoney(BigDecimal goodsDiscountMoney) {
        this.goodsDiscountMoney = goodsDiscountMoney;
    }

    public BigDecimal getGoodsPayableMoney() {
        return goodsPayableMoney;
    }

    public void setGoodsPayableMoney(BigDecimal goodsPayableMoney) {
        this.goodsPayableMoney = goodsPayableMoney;
    }

    public BigDecimal getFreightPayableMoney() {
        return freightPayableMoney;
    }

    public void setFreightPayableMoney(BigDecimal freightPayableMoney) {
        this.freightPayableMoney = freightPayableMoney;
    }

    public BigDecimal getOtherPayableMoney() {
        return otherPayableMoney;
    }

    public void setOtherPayableMoney(BigDecimal otherPayableMoney) {
        this.otherPayableMoney = otherPayableMoney;
    }

    public BigDecimal getInsuranceMoney() {
        return insuranceMoney;
    }

    public void setInsuranceMoney(BigDecimal insuranceMoney) {
        this.insuranceMoney = insuranceMoney;
    }

    public BigDecimal getAdvancePaymentMoney() {
        return advancePaymentMoney;
    }

    public void setAdvancePaymentMoney(BigDecimal advancePaymentMoney) {
        this.advancePaymentMoney = advancePaymentMoney;
    }

    public BigDecimal getDeductionMoney() {
        return deductionMoney;
    }

    public void setDeductionMoney(BigDecimal deductionMoney) {
        this.deductionMoney = deductionMoney;
    }

    public BigDecimal getIgnoreMoney() {
        return ignoreMoney;
    }

    public void setIgnoreMoney(BigDecimal ignoreMoney) {
        this.ignoreMoney = ignoreMoney;
    }

    public BigDecimal getBuyerServiceFee() {
        return buyerServiceFee;
    }

    public void setBuyerServiceFee(BigDecimal buyerServiceFee) {
        this.buyerServiceFee = buyerServiceFee;
    }

    public BigDecimal getSellerServiceFee() {
        return sellerServiceFee;
    }

    public void setSellerServiceFee(BigDecimal sellerServiceFee) {
        this.sellerServiceFee = sellerServiceFee;
    }

    public BigDecimal getRefundsApplyMoney() {
        return refundsApplyMoney;
    }

    public void setRefundsApplyMoney(BigDecimal refundsApplyMoney) {
        this.refundsApplyMoney = refundsApplyMoney;
    }

    public BigDecimal getRefundsActualMoney() {
        return refundsActualMoney;
    }

    public void setRefundsActualMoney(BigDecimal refundsActualMoney) {
        this.refundsActualMoney = refundsActualMoney;
    }

    public BigDecimal getPayableMoney() {
        return payableMoney;
    }

    public void setPayableMoney(BigDecimal payableMoney) {
        this.payableMoney = payableMoney;
    }

    public BigDecimal getPaidMoney() {
        return paidMoney;
    }

    public void setPaidMoney(BigDecimal paidMoney) {
        this.paidMoney = paidMoney;
    }

    public BigDecimal getCashMoney() {
        return cashMoney;
    }

    public void setCashMoney(BigDecimal cashMoney) {
        this.cashMoney = cashMoney;
    }

    public BigDecimal getPaidFreightMoney() {
        return paidFreightMoney;
    }

    public void setPaidFreightMoney(BigDecimal paidFreightMoney) {
        this.paidFreightMoney = paidFreightMoney;
    }

    public BigDecimal getPaidGoodsMoney() {
        return paidGoodsMoney;
    }

    public void setPaidGoodsMoney(BigDecimal paidGoodsMoney) {
        this.paidGoodsMoney = paidGoodsMoney;
    }

    public BigDecimal getCouponMoney() {
        return couponMoney;
    }

    public void setCouponMoney(BigDecimal couponMoney) {
        this.couponMoney = couponMoney;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public Date getExpectedArrivalTime() {
        return expectedArrivalTime;
    }

    public void setExpectedArrivalTime(Date expectedArrivalTime) {
        this.expectedArrivalTime = expectedArrivalTime;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public Date getBalanceTime() {
        return balanceTime;
    }

    public void setBalanceTime(Date balanceTime) {
        this.balanceTime = balanceTime;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Date getReturnGoodsTime() {
        return returnGoodsTime;
    }

    public void setReturnGoodsTime(Date returnGoodsTime) {
        this.returnGoodsTime = returnGoodsTime;
    }

    public Date getRefundsTime() {
        return refundsTime;
    }

    public void setRefundsTime(Date refundsTime) {
        this.refundsTime = refundsTime;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getLogistics() {
        return logistics;
    }

    public void setLogistics(String logistics) {
        this.logistics = logistics;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Long getAddrId() {
        return addrId;
    }

    public void setAddrId(Long addrId) {
        this.addrId = addrId;
    }

    public String getCancelType() {
        return cancelType;
    }

    public void setCancelType(String cancelType) {
        this.cancelType = cancelType;
    }

    public String getCancelStatus() {
        return cancelStatus;
    }

    public void setCancelStatus(String cancelStatus) {
        this.cancelStatus = cancelStatus;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public Byte getIsDeposit() {
        return isDeposit;
    }

    public void setIsDeposit(Byte isDeposit) {
        this.isDeposit = isDeposit;
    }

    public Byte getIsAuction() {
        return isAuction;
    }

    public void setIsAuction(Byte isAuction) {
        this.isAuction = isAuction;
    }

    public Byte getIsHangup() {
        return isHangup;
    }

    public void setIsHangup(Byte isHangup) {
        this.isHangup = isHangup;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Date getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(Date arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus;
    }

    public String getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(String receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public String getBalanceStatus() {
        return balanceStatus;
    }

    public void setBalanceStatus(String balanceStatus) {
        this.balanceStatus = balanceStatus;
    }

    public List<Long> getGoodsIdList() {
        return goodsIdList;
    }

    public void setGoodsIdList(List<Long> goodsIdList) {
        this.goodsIdList = goodsIdList;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    @Override
    public String toString() {
        return "OrderDmEntity{" +
                "goodsIdList=" + goodsIdList +
                ", boIdList=" + boIdList +
                '}';
    }
}
