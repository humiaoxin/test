package com.nxin.etposvr.dm.elasticsearch.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/10 18:18
 */
public class ShopEsEntity {

    public String id;

    public String name;

    private Byte systemId;

    public String busiScopeCode;

    public Long oneAreaId;

    public Long twoAreaId;

    public Long areaId;

    private String areaAxis;

    private String areaFullName;

    private String busiScopeName;

    public String tel;

    public String linkman;

    public String userType;

    public String authSign;

    private Integer sort;

    private BigDecimal soldNum;

    private Date vno;

    private Date applyTime;

    private Date auditTime;

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public List<MemberTagEsEntity> memberTagEsEntityList;

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public List<MemberTagEsEntity> getMemberTagEsEntityList() {
        return memberTagEsEntityList;
    }

    public void setMemberTagEsEntityList(List<MemberTagEsEntity> memberTagEsEntityList) {
        this.memberTagEsEntityList = memberTagEsEntityList;
    }

    public BigDecimal getSoldNum() {
        return soldNum;
    }

    public void setSoldNum(BigDecimal soldNum) {
        this.soldNum = soldNum;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getBusiScopeCode() {
        return busiScopeCode;
    }

    public void setBusiScopeCode(String busiScopeCode) {
        this.busiScopeCode = busiScopeCode;
    }

    public Long getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(Long oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public Long getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(Long twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getBusiScopeName() {
        return busiScopeName;
    }

    public void setBusiScopeName(String busiScopeName) {
        this.busiScopeName = busiScopeName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getAuthSign() {
        return authSign;
    }

    public void setAuthSign(String authSign) {
        this.authSign = authSign;
    }
}
