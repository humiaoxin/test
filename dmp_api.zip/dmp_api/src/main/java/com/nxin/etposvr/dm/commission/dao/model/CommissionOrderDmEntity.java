package com.nxin.etposvr.dm.commission.dao.model;

public class CommissionOrderDmEntity {
}
