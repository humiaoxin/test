package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatPdmgArea;

/**
 * 按地区管理
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:10
 * @version: v_1.0.1
 */
public class StatPdmgAreaResForm extends StatPdmgArea {
}
