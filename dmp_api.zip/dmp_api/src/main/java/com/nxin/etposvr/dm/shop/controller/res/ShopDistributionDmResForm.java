package com.nxin.etposvr.dm.shop.controller.res;

import java.math.BigDecimal;

/**
 * 店铺分布实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class ShopDistributionDmResForm {

    /**店铺ID*/
    private Long shopId;
    /**店铺名称*/
    private String shopName;
    /**经度*/
    private BigDecimal lon;
    /**纬度*/
    private BigDecimal lat;

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public BigDecimal getLon() {
        return lon;
    }

    public void setLon(BigDecimal lon) {
        this.lon = lon;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }
}
