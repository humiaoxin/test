package com.nxin.etposvr.dm.goods.dao.model;

import java.util.Date;

/**
 * @author LiuXiBin
 * @since 2020/4/3 16:20
 */
public class GoodsDeliveryRangeDmEntity {
    /**
     * @Fields id 主键ID
     */
    private Long id;

    /**
     * @Fields goodsId 商品ID
     */
    private Long goodsId;

    /**
     * @Fields categoryId 品类ID
     */
    private Long categoryId;

    /**
     * @Fields categoryAxis 品类层级串
     */
    private String categoryAxis;

    /**
     * @Fields categoryName 品类名称
     */
    private String categoryName;

    /**
     * @Fields shopId 店铺ID
     */
    private Long shopId;

    /**
     * @Fields isDelivery 是否配送
     */
    private Byte isDelivery;

    /**
     * @Fields areaId 地区ID
     */
    private Integer areaId;

    /**
     * @Fields areaAxis 地区AXIS
     */
    private String areaAxis;

    /**
     * @Fields areaFullName 地区全称，不包含虚拟节点
     */
    private String areaFullName;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Byte getIsDelivery() {
        return isDelivery;
    }

    public void setIsDelivery(Byte isDelivery) {
        this.isDelivery = isDelivery;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}
