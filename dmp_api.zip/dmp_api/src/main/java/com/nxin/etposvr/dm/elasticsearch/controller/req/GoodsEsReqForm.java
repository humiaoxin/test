package com.nxin.etposvr.dm.elasticsearch.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup101th;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/8 13:40
 */
public class GoodsEsReqForm extends WebPageParam {

    @ApiModelProperty(value = "商品ID", example = "11", dataType = "String")
    @NotNull(message = "000001|商品ID", groups = {VldGroup1th.class, VldGroup101th.class, VldGroup2th.class})
    public String id;


    @ApiModelProperty(value = "系统ID", example = "3", dataType = "Byte")
    @NotNull(message = "000001|系统ID", groups = {VldGroup1th.class, VldGroup101th.class})
    private Byte systemId;

    @Valid
    public List<GoodsEsReqForm> goodsEsReqFormList;


    public Integer isPage = 0;

    public String path;

    @Valid
    public List<JestClientReqForm> jestClientReqFormList;

    @Valid
    public List<JestClientReqForm> jestClientKvReqFormList;

    /** 消费者处理方式（1 . 新增， 2.删除） */
    private String mqStatus;
    private Date createTimeStart;
    private Date createTimeEnd;

    public List<JestClientReqForm> getJestClientKvReqFormList() {
        return jestClientKvReqFormList;
    }

    public void setJestClientKvReqFormList(List<JestClientReqForm> jestClientKvReqFormList) {
        this.jestClientKvReqFormList = jestClientKvReqFormList;
    }

    public Date getCreateTimeStart() {
        return createTimeStart;
    }

    public void setCreateTimeStart(Date createTimeStart) {
        this.createTimeStart = createTimeStart;
    }

    public Date getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(Date createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<GoodsEsReqForm> getGoodsEsReqFormList() {
        return goodsEsReqFormList;
    }

    public void setGoodsEsReqFormList(List<GoodsEsReqForm> goodsEsReqFormList) {
        this.goodsEsReqFormList = goodsEsReqFormList;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public List<JestClientReqForm> getJestClientReqFormList() {
        return jestClientReqFormList;
    }

    public void setJestClientReqFormList(List<JestClientReqForm> jestClientReqFormList) {
        this.jestClientReqFormList = jestClientReqFormList;
    }

    public String getMqStatus() {
        return mqStatus;
    }

    public void setMqStatus(String mqStatus) {
        this.mqStatus = mqStatus;
    }
}
