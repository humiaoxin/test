package com.nxin.etposvr.dm.report.dao.model;

import java.util.Date;

/**
 * 收支分析实体
 */
public class RecordBookkeepingDmEntity {
    /** 日期 */
    private Date bookkeepingDate;
    /** 类型 */
    private String type;
    /** 类型名称 */
    private String typeCn;
    /** 类别 */
    private String way;
    /** 类别 */
    private String wayCn;
    /** 金额 */
    private String money;
    /** 主体用户ID */
    private Long boId;
    /** 操作人用户ID */
    private Long oprBoId;

    private Byte systemId;

    private String entryType;

    private String entryTypeCn;

    public Date getBookkeepingDate() {
        return bookkeepingDate;
    }

    public void setBookkeepingDate(Date bookkeepingDate) {
        this.bookkeepingDate = bookkeepingDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTypeCn() {
        return typeCn;
    }

    public void setTypeCn(String typeCn) {
        this.typeCn = typeCn;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    public String getWayCn() {
        return wayCn;
    }

    public void setWayCn(String wayCn) {
        this.wayCn = wayCn;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public String getEntryTypeCn() {
        return entryTypeCn;
    }

    public void setEntryTypeCn(String entryTypeCn) {
        this.entryTypeCn = entryTypeCn;
    }
}
