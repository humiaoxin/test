package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;

/**
 * 品类交易趋势实体
 */
public class CategoryAmount {

    private BigDecimal amount;
    private String dates;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }
}
