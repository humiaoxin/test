package com.nxin.etposvr.dm.shop.dao.model;

public class ShopClassifyGoodsDmEntity {

    private String shopClassifyId;

    private String shopClassifyName;

    public String getShopClassifyId() {
        return shopClassifyId;
    }

    public void setShopClassifyId(String shopClassifyId) {
        this.shopClassifyId = shopClassifyId;
    }

    public String getShopClassifyName() {
        return shopClassifyName;
    }

    public void setShopClassifyName(String shopClassifyName) {
        this.shopClassifyName = shopClassifyName;
    }
}
