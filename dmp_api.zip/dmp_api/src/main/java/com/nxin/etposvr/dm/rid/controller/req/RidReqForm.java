package com.nxin.etposvr.dm.rid.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/12/21 14:46
 */
public class RidReqForm extends WebPageParam{

    private String customSql;

    public String getCustomSql() {
        return customSql;
    }

    public void setCustomSql(String customSql) {
        this.customSql = customSql;
    }
}
