package com.nxin.etposvr.dm.report.controller.res;

import com.nxin.etposvr.dm.report.dao.model.RecordEntryReportDmEntity;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/11/18 15:27
 */
public class RecordEntryReportDmResForm extends RecordEntryReportDmEntity {

}
