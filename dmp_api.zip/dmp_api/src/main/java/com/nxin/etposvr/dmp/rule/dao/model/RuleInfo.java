package com.nxin.etposvr.dmp.rule.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Title rule_info表的实体类
 * @Description 规则表
 * @version 1.0
 * @Author System
 * @Date 2019-12-20 18:24:36
 */
public class RuleInfo implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields busType 业务类型
     */
    private String busType;

    /**
     * @Fields ruleType 规则类型
     */
    private String ruleType;

    /**
     * @Fields ruleCondition 规则条件
     */
    private String ruleCondition;

    /**
     * @Fields maxValue 最大结果
     */
    private Integer maxValue;

    /**
     * @Fields ruleStandard 规则标准
     */
    private String ruleStandard;

    /**
     * @Fields remark 备注
     */
    private String remark;

    /**
     * @Fields factor 
     */
    private BigDecimal factor;

    /**
     * @Fields state 状态
     */
    private String state;

    /**
     * @Fields sorting 排序
     */
    private Integer sorting;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:rule_info.id
     *
     * @return rule_info.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:rule_info.id
     *
     * @param id the value for rule_info.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 业务类型 字段:rule_info.bus_type
     *
     * @return rule_info.bus_type, 业务类型
     */
    public String getBusType() {
        return busType;
    }

    /**
     * 设置 业务类型 字段:rule_info.bus_type
     *
     * @param busType the value for rule_info.bus_type, 业务类型
     */
    public void setBusType(String busType) {
        this.busType = busType == null ? null : busType.trim();
    }

    /**
     * 获取 规则类型 字段:rule_info.rule_type
     *
     * @return rule_info.rule_type, 规则类型
     */
    public String getRuleType() {
        return ruleType;
    }

    /**
     * 设置 规则类型 字段:rule_info.rule_type
     *
     * @param ruleType the value for rule_info.rule_type, 规则类型
     */
    public void setRuleType(String ruleType) {
        this.ruleType = ruleType == null ? null : ruleType.trim();
    }

    /**
     * 获取 规则条件 字段:rule_info.rule_condition
     *
     * @return rule_info.rule_condition, 规则条件
     */
    public String getRuleCondition() {
        return ruleCondition;
    }

    /**
     * 设置 规则条件 字段:rule_info.rule_condition
     *
     * @param ruleCondition the value for rule_info.rule_condition, 规则条件
     */
    public void setRuleCondition(String ruleCondition) {
        this.ruleCondition = ruleCondition == null ? null : ruleCondition.trim();
    }

    /**
     * 获取 最大结果 字段:rule_info.max_value
     *
     * @return rule_info.max_value, 最大结果
     */
    public Integer getMaxValue() {
        return maxValue;
    }

    /**
     * 设置 最大结果 字段:rule_info.max_value
     *
     * @param maxValue the value for rule_info.max_value, 最大结果
     */
    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * 获取 规则标准 字段:rule_info.rule_standard
     *
     * @return rule_info.rule_standard, 规则标准
     */
    public String getRuleStandard() {
        return ruleStandard;
    }

    /**
     * 设置 规则标准 字段:rule_info.rule_standard
     *
     * @param ruleStandard the value for rule_info.rule_standard, 规则标准
     */
    public void setRuleStandard(String ruleStandard) {
        this.ruleStandard = ruleStandard == null ? null : ruleStandard.trim();
    }

    /**
     * 获取 备注 字段:rule_info.remark
     *
     * @return rule_info.remark, 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 设置 备注 字段:rule_info.remark
     *
     * @param remark the value for rule_info.remark, 备注
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 获取  字段:rule_info.factor
     *
     * @return rule_info.factor, 
     */
    public BigDecimal getFactor() {
        return factor;
    }

    /**
     * 设置  字段:rule_info.factor
     *
     * @param factor the value for rule_info.factor, 
     */
    public void setFactor(BigDecimal factor) {
        this.factor = factor;
    }

    /**
     * 获取 状态 字段:rule_info.state
     *
     * @return rule_info.state, 状态
     */
    public String getState() {
        return state;
    }

    /**
     * 设置 状态 字段:rule_info.state
     *
     * @param state the value for rule_info.state, 状态
     */
    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    /**
     * 获取 排序 字段:rule_info.sorting
     *
     * @return rule_info.sorting, 排序
     */
    public Integer getSorting() {
        return sorting;
    }

    /**
     * 设置 排序 字段:rule_info.sorting
     *
     * @param sorting the value for rule_info.sorting, 排序
     */
    public void setSorting(Integer sorting) {
        this.sorting = sorting;
    }

    /**
     * 获取 所属系统 字段:rule_info.system_id
     *
     * @return rule_info.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:rule_info.system_id
     *
     * @param systemId the value for rule_info.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:rule_info.data_remark
     *
     * @return rule_info.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:rule_info.data_remark
     *
     * @param dataRemark the value for rule_info.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:rule_info.create_time
     *
     * @return rule_info.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:rule_info.create_time
     *
     * @param createTime the value for rule_info.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:rule_info.version_remark
     *
     * @return rule_info.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:rule_info.version_remark
     *
     * @param versionRemark the value for rule_info.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:rule_info.vno
     *
     * @return rule_info.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:rule_info.vno
     *
     * @param vno the value for rule_info.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:rule_info.is_enabled
     *
     * @return rule_info.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:rule_info.is_enabled
     *
     * @param isEnabled the value for rule_info.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :rule_info
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", busType=").append(busType);
        sb.append(", ruleType=").append(ruleType);
        sb.append(", ruleCondition=").append(ruleCondition);
        sb.append(", maxValue=").append(maxValue);
        sb.append(", ruleStandard=").append(ruleStandard);
        sb.append(", remark=").append(remark);
        sb.append(", factor=").append(factor);
        sb.append(", state=").append(state);
        sb.append(", sorting=").append(sorting);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :rule_info
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        RuleInfo other = (RuleInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getBusType() == null ? other.getBusType() == null : this.getBusType().equals(other.getBusType()))
            && (this.getRuleType() == null ? other.getRuleType() == null : this.getRuleType().equals(other.getRuleType()))
            && (this.getRuleCondition() == null ? other.getRuleCondition() == null : this.getRuleCondition().equals(other.getRuleCondition()))
            && (this.getMaxValue() == null ? other.getMaxValue() == null : this.getMaxValue().equals(other.getMaxValue()))
            && (this.getRuleStandard() == null ? other.getRuleStandard() == null : this.getRuleStandard().equals(other.getRuleStandard()))
            && (this.getRemark() == null ? other.getRemark() == null : this.getRemark().equals(other.getRemark()))
            && (this.getFactor() == null ? other.getFactor() == null : this.getFactor().equals(other.getFactor()))
            && (this.getState() == null ? other.getState() == null : this.getState().equals(other.getState()))
            && (this.getSorting() == null ? other.getSorting() == null : this.getSorting().equals(other.getSorting()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :rule_info
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getBusType() == null) ? 0 : getBusType().hashCode());
        result = prime * result + ((getRuleType() == null) ? 0 : getRuleType().hashCode());
        result = prime * result + ((getRuleCondition() == null) ? 0 : getRuleCondition().hashCode());
        result = prime * result + ((getMaxValue() == null) ? 0 : getMaxValue().hashCode());
        result = prime * result + ((getRuleStandard() == null) ? 0 : getRuleStandard().hashCode());
        result = prime * result + ((getRemark() == null) ? 0 : getRemark().hashCode());
        result = prime * result + ((getFactor() == null) ? 0 : getFactor().hashCode());
        result = prime * result + ((getState() == null) ? 0 : getState().hashCode());
        result = prime * result + ((getSorting() == null) ? 0 : getSorting().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}