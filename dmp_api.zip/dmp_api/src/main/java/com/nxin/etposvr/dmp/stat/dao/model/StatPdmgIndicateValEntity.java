package com.nxin.etposvr.dmp.stat.dao.model;

/**
 * 指标数据实体类
 *
 * @author TianShiWei
 * @since:  2020/5/26 15:41
 * @version: v_1.0.1
 */
public class StatPdmgIndicateValEntity {

    private String statType;

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }
}
