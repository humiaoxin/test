package com.nxin.etposvr.dmp.stat.dao.model;


import java.util.Map;

/**
 * @Title stat_pdmg_category表的实体类
 * @Description 按品类统计生产管理数据
 * @version 1.0
 * @Author System
 * @Date 2020-05-23 13:58:48
 */
public class StatPdmgCategoryEntity{

    private Long indicateId;

    private String val;

    private String type;

    private Long  categoryId;

    private String dataYear;

    private Map<String,String> valMap;

    private Byte SystemId;

    private String categoryName;

    private String statType;

    private String categoryAxisLike;

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Long getIndicateId() {
        return indicateId;
    }

    public void setIndicateId(Long indicateId) {
        this.indicateId = indicateId;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public Map<String, String> getValMap() {
        return valMap;
    }

    public void setValMap(Map<String, String> valMap) {
        this.valMap = valMap;
    }

    public Byte getSystemId() {
        return SystemId;
    }

    public void setSystemId(Byte systemId) {
        SystemId = systemId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }
}