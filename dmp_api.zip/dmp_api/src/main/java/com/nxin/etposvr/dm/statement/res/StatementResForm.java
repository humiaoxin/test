package com.nxin.etposvr.dm.statement.res;

import com.nxin.etpojar.common.constant.CommonDsConstant;
import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * 对账单reqForm
 * @Author lpp
 * @Date 2019/5/20 18:09
 * @Version 1.0
 */
public class StatementResForm extends WebPageParam {

    /**
     * 买家名称
     *
     * @author lpp
     * @date 2019/5/21 13:18
     */
    private String buyerName;
    /**
     * 店铺名称
     *
     * @author lpp
     * @date 2019/5/21 13:14
     */
    private String shopName;

    /**
     * 收款方boId
     *
     * @author lpp
     * @date 2019/5/20 18:15
     */
    private Long boIdIn;
    /**
     * 付款人编号
     *
     * @author lpp
     * @date 2019/5/20 17:41
     */
    private Long boIdOut;
    /**
     * 支付/结算状态
     *
     * @author lpp
     * @date 2019/5/20 17:41
     */
    private String paymentStatus;

    /**
     * 支付状态中文
     *
     * @author lpp
     * @date 2019/5/20 17:42
     */
    private String paymentStatusCn;
    /**
     * 支付时间
     *
     * @author lpp
     * @date 2019/5/20 17:41
     */
    private Date paymentTime;
    /**
     * 支付金额
     *
     * @author lpp
     * @date 2019/5/20 17:41
     */
    private Long payAmount;
    /**
     * 支付方式名称
     *
     * @author lpp
     * @date 2019/5/29 14:38
     */
    private String paymentName;
    /**
     * 支付方式编码
     *
     * @author lpp
     * @date 2019/5/29 14:38
     */
    private String paymentCode;
    /**
     * 商品品类名称
     *
     * @author lpp
     * @date 2019/5/29 14:37
     */
    private String categoryName;
    /**
     * 商品数量
     *
     * @author lpp
     * @date 2019/5/29 14:37
     */
    private Long finalGoodsNum;
    /**
     * 商品数单位
     *
     * @author lpp
     * @date 2019/5/29 14:37
     */
    private String goodsNumUnitTxt;

    private Byte systemId;

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Long getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(Long payAmount) {
        this.payAmount = payAmount;
    }

    public String getPaymentName() {
        return paymentName;
    }

    public void setPaymentName(String paymentName) {
        this.paymentName = paymentName;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getFinalGoodsNum() {
        return finalGoodsNum;
    }

    public void setFinalGoodsNum(Long finalGoodsNum) {
        this.finalGoodsNum = finalGoodsNum;
    }

    public String getGoodsNumUnitTxt() {
        return goodsNumUnitTxt;
    }

    public void setGoodsNumUnitTxt(String goodsNumUnitTxt) {
        this.goodsNumUnitTxt = goodsNumUnitTxt;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getBoIdIn() {
        return boIdIn;
    }

    public void setBoIdIn(Long boIdIn) {
        this.boIdIn = boIdIn;
    }

    public Long getBoIdOut() {
        return boIdOut;
    }

    public void setBoIdOut(Long boIdOut) {
        this.boIdOut = boIdOut;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getPaymentStatusCn() {
        return paymentStatusCn;
    }

    public void setPaymentStatusCn(String paymentStatusCn) {
        this.paymentStatusCn = paymentStatusCn;
    }

}
