package com.nxin.etposvr.dmp.stat.dao.model;

/**
 * @Title stat_pdmg_date表的实体类
 * @Description 按日期统计生产管理数据
 * @version 1.0
 * @Author System
 * @Date 2020-05-25 15:17:52
 */
public class StatPdmgDateEntity{

    private Long indicateId;

    private String val;

    private String type;

    private String dataYear;

    private Byte SystemId;

    public Long getIndicateId() {
        return indicateId;
    }

    public void setIndicateId(Long indicateId) {
        this.indicateId = indicateId;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public Byte getSystemId() {
        return SystemId;
    }

    public void setSystemId(Byte systemId) {
        SystemId = systemId;
    }
}