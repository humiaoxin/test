package com.nxin.etposvr.dm.statement.res;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhaoshuai
 * @version v_1.0.1
 * @since 2019/7/17 18:01
 */
public class StatementPCBuyerResForm {

    /**
     * 订单编号
     */
    private Long orderId;

    /**
     * 付款时间
     */
    private Date paymentTime;

    /**
     * 支付方式
     */
    private String paymentType;

    /**
     * 收款方户名
     */
    private String realName;

    /**
     * 实付货款金额
     */
    private BigDecimal paidGoodsMoney;

    /**
     * 预估货款金额
     */
    private BigDecimal goodsOrigMoney;

    /**
     * 商品金额
     */
    private BigDecimal goodsDealMoney;

    /**
     * 服务费
     */
    private BigDecimal buyerServiceFee;

    /**
     * 保险费
     */
    private BigDecimal insuranceMoney;

    /**
     * 实付总金额
     */
    private BigDecimal paidMoney;

    /**
     * 总金额
     */
    private BigDecimal payableMoney;

    /**
     * 单价
     */
    private BigDecimal sellPrice;

    /**
     * 下单数
     */
    private BigDecimal finalGoodsNum;

    /**
     * 总量
     */
    private BigDecimal finalNum;

    /**
     * 品类
     */
    private String categoryName;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Date getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(Date paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public BigDecimal getPaidGoodsMoney() {
        return paidGoodsMoney;
    }

    public void setPaidGoodsMoney(BigDecimal paidGoodsMoney) {
        this.paidGoodsMoney = paidGoodsMoney;
    }

    public BigDecimal getGoodsOrigMoney() {
        return goodsOrigMoney;
    }

    public void setGoodsOrigMoney(BigDecimal goodsOrigMoney) {
        this.goodsOrigMoney = goodsOrigMoney;
    }

    public BigDecimal getGoodsDealMoney() {
        return goodsDealMoney;
    }

    public void setGoodsDealMoney(BigDecimal goodsDealMoney) {
        this.goodsDealMoney = goodsDealMoney;
    }

    public BigDecimal getBuyerServiceFee() {
        return buyerServiceFee;
    }

    public void setBuyerServiceFee(BigDecimal buyerServiceFee) {
        this.buyerServiceFee = buyerServiceFee;
    }

    public BigDecimal getInsuranceMoney() {
        return insuranceMoney;
    }

    public void setInsuranceMoney(BigDecimal insuranceMoney) {
        this.insuranceMoney = insuranceMoney;
    }

    public BigDecimal getPaidMoney() {
        return paidMoney;
    }

    public void setPaidMoney(BigDecimal paidMoney) {
        this.paidMoney = paidMoney;
    }

    public BigDecimal getPayableMoney() {
        return payableMoney;
    }

    public void setPayableMoney(BigDecimal payableMoney) {
        this.payableMoney = payableMoney;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getFinalGoodsNum() {
        return finalGoodsNum;
    }

    public void setFinalGoodsNum(BigDecimal finalGoodsNum) {
        this.finalGoodsNum = finalGoodsNum;
    }

    public BigDecimal getFinalNum() {
        return finalNum;
    }

    public void setFinalNum(BigDecimal finalNum) {
        this.finalNum = finalNum;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public String toString() {
        return "StatementDmPCBo{" +
                "orderId=" + orderId +
                ", paymentTime=" + paymentTime +
                ", paymentType='" + paymentType + '\'' +
                ", realName='" + realName + '\'' +
                ", paidGoodsMoney=" + paidGoodsMoney +
                ", goodsOrigMoney=" + goodsOrigMoney +
                ", goodsDealMoney=" + goodsDealMoney +
                ", buyerServiceFee=" + buyerServiceFee +
                ", insuranceMoney=" + insuranceMoney +
                ", paidMoney=" + paidMoney +
                ", payableMoney=" + payableMoney +
                ", sellPrice=" + sellPrice +
                ", finalGoodsNum=" + finalGoodsNum +
                ", finalNum=" + finalNum +
                ", categoryName='" + categoryName + '\'' +
                '}';
    }
}
