package com.nxin.etposvr.dm.elasticsearch.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/10 18:17
 */
public class GoodsEsEntity {

    private Date createTimeStart;
    private Date createTimeEnd;
    public String id;

    public String sellerBoId;

    public String type;

    public List<GoodsAttrEsEntity> goodsAttrEsEntityList;

    public List<GoodsSpecEsEntity> goodsSpecEsEntityList;

    public List<ShopClassifyGoodsEsEntity> shopClassifyGoodsEsEntityList;

    public ShopEsEntity shopEsEntity;

    public Long categoryId;

    public Long areaId;

    public Long oneCategoryId;

    public Long twoCategoryId;

    public Long oneAreaId;

    public Long twoAreaId;

    public String name;

    public String shopId;

    public String status;

    private Byte systemId;

    private Date vno;

    private String categoryAxis;

    private String categoryName;

    private String areaAxis;

    private String areaFullName;

    private  Date onTime;

    private String brand;

    private String logistics;

    private String tags;

    private String thumbnailUrl;

    private BigDecimal soldNum;

    private Date publishTime;

    private BigDecimal minSellPrice;

    private BigDecimal maxSellPrice;

    private String goodsDeliveryRangeAxisStr;

    public String getGoodsDeliveryRangeAxisStr() {
        return goodsDeliveryRangeAxisStr;
    }

    public void setGoodsDeliveryRangeAxisStr(String goodsDeliveryRangeAxisStr) {
        this.goodsDeliveryRangeAxisStr = goodsDeliveryRangeAxisStr;
    }

    public Date getCreateTimeStart() {
        return createTimeStart;
    }

    public void setCreateTimeStart(Date createTimeStart) {
        this.createTimeStart = createTimeStart;
    }

    public Date getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(Date createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public BigDecimal getMaxSellPrice() {
        return maxSellPrice;
    }

    public void setMaxSellPrice(BigDecimal maxSellPrice) {
        this.maxSellPrice = maxSellPrice;
    }

    public BigDecimal getMinSellPrice() {
        return minSellPrice;
    }

    public void setMinSellPrice(BigDecimal minSellPrice) {
        this.minSellPrice = minSellPrice;
    }

    public String getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(String sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getSoldNum() {
        return soldNum;
    }

    public void setSoldNum(BigDecimal soldNum) {
        this.soldNum = soldNum;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Date getOnTime() {
        return onTime;
    }

    public void setOnTime(Date onTime) {
        this.onTime = onTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getLogistics() {
        return logistics;
    }

    public void setLogistics(String logistics) {
        this.logistics = logistics;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public List<GoodsAttrEsEntity> getGoodsAttrEsEntityList() {
        return goodsAttrEsEntityList;
    }

    public void setGoodsAttrEsEntityList(List<GoodsAttrEsEntity> goodsAttrEsEntityList) {
        this.goodsAttrEsEntityList = goodsAttrEsEntityList;
    }

    public List<GoodsSpecEsEntity> getGoodsSpecEsEntityList() {
        return goodsSpecEsEntityList;
    }

    public void setGoodsSpecEsEntityList(List<GoodsSpecEsEntity> goodsSpecEsEntityList) {
        this.goodsSpecEsEntityList = goodsSpecEsEntityList;
    }

    public List<ShopClassifyGoodsEsEntity> getShopClassifyGoodsEsEntityList() {
        return shopClassifyGoodsEsEntityList;
    }

    public void setShopClassifyGoodsEsEntityList(List<ShopClassifyGoodsEsEntity> shopClassifyGoodsEsEntityList) {
        this.shopClassifyGoodsEsEntityList = shopClassifyGoodsEsEntityList;
    }

    public ShopEsEntity getShopEsEntity() {
        return shopEsEntity;
    }

    public void setShopEsEntity(ShopEsEntity shopEsEntity) {
        this.shopEsEntity = shopEsEntity;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public Long getOneCategoryId() {
        return oneCategoryId;
    }

    public void setOneCategoryId(Long oneCategoryId) {
        this.oneCategoryId = oneCategoryId;
    }

    public Long getTwoCategoryId() {
        return twoCategoryId;
    }

    public void setTwoCategoryId(Long twoCategoryId) {
        this.twoCategoryId = twoCategoryId;
    }

    public Long getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(Long oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public Long getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(Long twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }
}
