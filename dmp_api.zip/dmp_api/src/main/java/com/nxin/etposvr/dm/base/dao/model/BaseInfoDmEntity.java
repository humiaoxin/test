package com.nxin.etposvr.dm.base.dao.model;


import java.math.BigDecimal;
import java.util.List;

/**
 * 基础信息实体类
 *
 * @author TianShiWei
 * @since: 2019/12/13 13:59
 * @version: v_1.0.1
 */
public class BaseInfoDmEntity {
    /**
     * 土地大小（亩）
     */
    private BigDecimal totalNum;

    /**
     * 数量百分比
     */
    private String totalNumPercent;

    /**
     * 名称
     */
    private String name;
    /**
     * 日期
     */
    private String baseInfoDate;

    private List<String> baseInfoDateList;

    /**
     * 统计类型DAY-按日统计MON-按月统计YEAR-按年统计
     */
    private String stateType;

    /**
     * 天数范围
     */
    private Integer range;

    /**
     * 类型code
     */
    private String  code;
    /**
     * 规模占比（小于200）
     */
    private String scaleProportion1;

    /**
     * 规模占比（大于200且小于300）
     */
    private String scaleProportion2;

    /**
     * 规模占比（大于300且小于500）
     */
    private String scaleProportion3;

    /**
     * 规模占比（大于500）
     */
    private String scaleProportion4;

    /**
     * 系统id
     */
    private Byte systemId;

    private String schemeNaem;

    private String longitude;

    private String latitude;

    private String url;

    private String categoryName;

    private BigDecimal num;

    private BigDecimal baseInfoSize;

    private Long id;

    private String timeStart;

    private String timeEnd;

    private Long rangeId;

    private String timeStr;

    private String yield;

    private Long boId;

    private Long pcateId;

    private String uniqueId;

    private List<Long> idList;

    private String categoryAxisLike;

    private String categoryPcateName;

    public String getCategoryPcateName() {
        return categoryPcateName;
    }

    public void setCategoryPcateName(String categoryPcateName) {
        this.categoryPcateName = categoryPcateName;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public BaseInfoDmEntity() {
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public Long getPcateId() {
        return pcateId;
    }

    public void setPcateId(Long pcateId) {
        this.pcateId = pcateId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public Long getRangeId() {
        return rangeId;
    }

    public void setRangeId(Long rangeId) {
        this.rangeId = rangeId;
    }

    public String getTimeStr() {
        return timeStr;
    }

    public void setTimeStr(String timeStr) {
        this.timeStr = timeStr;
    }

    public String getYield() {
        return yield;
    }

    public void setYield(String yield) {
        this.yield = yield;
    }

    public List<String> getBaseInfoDateList() {
        return baseInfoDateList;
    }

    public void setBaseInfoDateList(List<String> baseInfoDateList) {
        this.baseInfoDateList = baseInfoDateList;
    }

    public String getSchemeNaem() {
        return schemeNaem;
    }

    public void setSchemeNaem(String schemeNaem) {
        this.schemeNaem = schemeNaem;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getNum() {
        return num;
    }

    public void setNum(BigDecimal num) {
        this.num = num;
    }

    public BigDecimal getBaseInfoSize() {
        return baseInfoSize;
    }

    public void setBaseInfoSize(BigDecimal baseInfoSize) {
        this.baseInfoSize = baseInfoSize;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTotalNumPercent() {
        return totalNumPercent;
    }

    public void setTotalNumPercent(String totalNumPercent) {
        this.totalNumPercent = totalNumPercent;
    }

    public BigDecimal getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(BigDecimal totalNum) {
        this.totalNum = totalNum;
    }

    public String getBaseInfoDate() {
        return baseInfoDate;
    }

    public void setBaseInfoDate(String baseInfoDate) {
        this.baseInfoDate = baseInfoDate;
    }

    public String getStateType() {
        return stateType;
    }

    public void setStateType(String stateType) {
        this.stateType = stateType;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }


    public String getScaleProportion1() {
        return scaleProportion1;
    }

    public void setScaleProportion1(String scaleProportion1) {
        this.scaleProportion1 = scaleProportion1;
    }

    public String getScaleProportion2() {
        return scaleProportion2;
    }

    public void setScaleProportion2(String scaleProportion2) {
        this.scaleProportion2 = scaleProportion2;
    }

    public String getScaleProportion3() {
        return scaleProportion3;
    }

    public void setScaleProportion3(String scaleProportion3) {
        this.scaleProportion3 = scaleProportion3;
    }

    public String getScaleProportion4() {
        return scaleProportion4;
    }

    public void setScaleProportion4(String scaleProportion4) {
        this.scaleProportion4 = scaleProportion4;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "BaseInfoDmEntity{" +
                "totalNum=" + totalNum +
                ", totalNumPercent='" + totalNumPercent + '\'' +
                ", name='" + name + '\'' +
                ", baseInfoDate='" + baseInfoDate + '\'' +
                ", baseInfoDateList=" + baseInfoDateList +
                ", stateType='" + stateType + '\'' +
                ", range=" + range +
                ", code='" + code + '\'' +
                ", scaleProportion1='" + scaleProportion1 + '\'' +
                ", scaleProportion2='" + scaleProportion2 + '\'' +
                ", scaleProportion3='" + scaleProportion3 + '\'' +
                ", scaleProportion4='" + scaleProportion4 + '\'' +
                ", systemId=" + systemId +
                ", schemeNaem='" + schemeNaem + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", url='" + url + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", num=" + num +
                ", baseInfoSize=" + baseInfoSize +
                ", id=" + id +
                ", timeStart='" + timeStart + '\'' +
                ", timeEnd='" + timeEnd + '\'' +
                ", rangeId=" + rangeId +
                ", timeStr='" + timeStr + '\'' +
                ", yield='" + yield + '\'' +
                ", boId=" + boId +
                ", pcateId=" + pcateId +
                ", uniqueId='" + uniqueId + '\'' +
                ", idList=" + idList +
                '}';
    }
}
