package com.nxin.etposvr.dm.member.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * @author LS
 * @date 2019/10/28
 */
public class MemberStatDmReqForm extends WebPageParam {
    /**
     * 开始时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date startTime;
    /**
     * 结束时间
     *
     * @author LS
     * @date 2019/10/28
     */
    private Date endTime;
    /**
     * 统计类型
     * DAY-按日统计
     * MON-按月统计
     * YEAR-按年统计
     * 其他-全部统计
     *
     * @author LS
     * @date 2019/10/28
     */
    private String statType;
    /**
     * 地区编号
     *
     * @author LS
     * @date 2019/10/29
     */
    private Integer areaId;
    /**
     * 用户类型
     * GR-个人
     * GT-个体
     * QY-企业
     * @author LS
     * @date 2019/10/31
     */
    private String userType;
    /**
     * 所属系统
     *
     * @author LS
     * @date 2019/10/29
     */
    private Byte systemId;
    /**
     * 地区等级
     *
     * @author lpp
     * @date 2020/4/17 15:11
     */
    private Integer areaRank = 1;

    public Integer getAreaRank() {
        return areaRank;
    }

    public void setAreaRank(Integer areaRank) {
        this.areaRank = areaRank;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "MemberStatDmReqForm{" +
                "startTime=" + startTime +
                ", endTime=" + endTime +
                ", statType='" + statType + '\'' +
                ", areaId=" + areaId +
                ", userType='" + userType + '\'' +
                ", systemId=" + systemId +
                ", areaRank=" + areaRank +
                '}';
    }
}
