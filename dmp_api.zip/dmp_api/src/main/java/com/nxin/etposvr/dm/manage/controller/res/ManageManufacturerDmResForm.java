package com.nxin.etposvr.dm.manage.controller.res;

/**
 * @author TianShiWei
 * @since:  2019/10/30 9:56
 * @version: v_1.0.1
 */
public class ManageManufacturerDmResForm {

    private String dates;

    private Integer count;

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

}
