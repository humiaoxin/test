package com.nxin.etposvr.dm.export.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderGoodsDmEntity {

    private Long id;

    private Long orderId;

    private Long goodsId;

    private Date goodsVno;

    private String goodsName;

    private Short categoryId;

    private String categoryAxis;

    private String categoryName;

    private Long manuId;

    private BigDecimal origGoodsNum;

    private BigDecimal finalGoodsNum;

    private String goodsNumUnitTxt;

    private String goodsNumUnit;

    private String goodsNumUnitType;

    private BigDecimal origNum;

    private BigDecimal finalNum;

    private String numUnitTxt;

    private String numUnit;

    private String numUnitType;

    private BigDecimal sellPrice;

    private BigDecimal goodsDiscountMoney;

    private BigDecimal goodsPayableMoney;

    private String remark;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Byte isEnabled;
    //促销类型
    private String promotionType;
    //促销id
    private Long pDtlId;

    public String getPromotionType() {
        return promotionType;
    }
    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }
    public Long getpDtlId() {
        return pDtlId;
    }
    public void setpDtlId(Long pDtlId) {
        this.pDtlId = pDtlId;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Date getGoodsVno() {
        return goodsVno;
    }

    public void setGoodsVno(Date goodsVno) {
        this.goodsVno = goodsVno;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName == null ? null : goodsName.trim();
    }

    public Short getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Short categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis == null ? null : categoryAxis.trim();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName == null ? null : categoryName.trim();
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }

    public BigDecimal getOrigGoodsNum() {
        return origGoodsNum;
    }

    public void setOrigGoodsNum(BigDecimal origGoodsNum) {
        this.origGoodsNum = origGoodsNum;
    }

    public BigDecimal getFinalGoodsNum() {
        return finalGoodsNum;
    }

    public void setFinalGoodsNum(BigDecimal finalGoodsNum) {
        this.finalGoodsNum = finalGoodsNum;
    }

    public String getGoodsNumUnitTxt() {
        return goodsNumUnitTxt;
    }

    public void setGoodsNumUnitTxt(String goodsNumUnitTxt) {
        this.goodsNumUnitTxt = goodsNumUnitTxt == null ? null : goodsNumUnitTxt.trim();
    }

    public String getGoodsNumUnit() {
        return goodsNumUnit;
    }

    public void setGoodsNumUnit(String goodsNumUnit) {
        this.goodsNumUnit = goodsNumUnit == null ? null : goodsNumUnit.trim();
    }

    public String getGoodsNumUnitType() {
        return goodsNumUnitType;
    }

    public void setGoodsNumUnitType(String goodsNumUnitType) {
        this.goodsNumUnitType = goodsNumUnitType == null ? null : goodsNumUnitType.trim();
    }

    public BigDecimal getOrigNum() {
        return origNum;
    }

    public void setOrigNum(BigDecimal origNum) {
        this.origNum = origNum;
    }

    public BigDecimal getFinalNum() {
        return finalNum;
    }

    public void setFinalNum(BigDecimal finalNum) {
        this.finalNum = finalNum;
    }

    public String getNumUnitTxt() {
        return numUnitTxt;
    }

    public void setNumUnitTxt(String numUnitTxt) {
        this.numUnitTxt = numUnitTxt == null ? null : numUnitTxt.trim();
    }

    public String getNumUnit() {
        return numUnit;
    }

    public void setNumUnit(String numUnit) {
        this.numUnit = numUnit == null ? null : numUnit.trim();
    }

    public String getNumUnitType() {
        return numUnitType;
    }

    public void setNumUnitType(String numUnitType) {
        this.numUnitType = numUnitType == null ? null : numUnitType.trim();
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getGoodsDiscountMoney() {
        return goodsDiscountMoney;
    }

    public void setGoodsDiscountMoney(BigDecimal goodsDiscountMoney) {
        this.goodsDiscountMoney = goodsDiscountMoney;
    }

    public BigDecimal getGoodsPayableMoney() {
        return goodsPayableMoney;
    }

    public void setGoodsPayableMoney(BigDecimal goodsPayableMoney) {
        this.goodsPayableMoney = goodsPayableMoney;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}
