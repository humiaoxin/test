package com.nxin.etposvr.dm.elasticsearch.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import com.nxin.etpojar.common.validation.group.VldGroup4th;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/5/17 10:49
 */
public class CmsArticleEsReqForm extends WebPageParam {

    @NotNull(message = "000001|文章主键Id", groups = {VldGroup2th.class,VldGroup4th.class})
    private String id;
    @NotNull(message = "000001|栏目id", groups = {VldGroup1th.class})
    private String colCode;
    @NotNull(message = "000001|标题", groups = {VldGroup1th.class})
    private String title;
    @NotNull(message = "000001|列表标题", groups = {VldGroup1th.class})
    private String listTitle;
    @NotNull(message = "000001|类型", groups = {VldGroup1th.class})
    private String type;

    @Valid
    public List<CmsArticleEsReqForm> cmsArticleEsReqFormList;

    public Integer isPage = 0;

    @Valid
    public List<JestClientReqForm> jestClientReqFormList;

    /** 消费者处理方式（1 . 新增， 2.删除） */
    private String mqStatus;

    private Byte systemId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<CmsArticleEsReqForm> getCmsArticleEsReqFormList() {
        return cmsArticleEsReqFormList;
    }

    public void setCmsArticleEsReqFormList(List<CmsArticleEsReqForm> cmsArticleEsReqFormList) {
        this.cmsArticleEsReqFormList = cmsArticleEsReqFormList;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public List<JestClientReqForm> getJestClientReqFormList() {
        return jestClientReqFormList;
    }

    public void setJestClientReqFormList(List<JestClientReqForm> jestClientReqFormList) {
        this.jestClientReqFormList = jestClientReqFormList;
    }

    public String getMqStatus() {
        return mqStatus;
    }

    public void setMqStatus(String mqStatus) {
        this.mqStatus = mqStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getColCode() {
        return colCode;
    }

    public void setColCode(String colCode) {
        this.colCode = colCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getListTitle() {
        return listTitle;
    }

    public void setListTitle(String listTitle) {
        this.listTitle = listTitle;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
