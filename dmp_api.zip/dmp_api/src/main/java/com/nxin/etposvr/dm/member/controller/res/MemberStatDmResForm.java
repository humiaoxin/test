package com.nxin.etposvr.dm.member.controller.res;

import com.nxin.etposvr.dm.member.domain.MemberStatDmBo;

import java.util.List;

/**
 * @author LS
 * @date 2019/10/28
 */
public class MemberStatDmResForm {
    /**
     * 时间
     * 日-yyyy-MM-dd
     * 月-yyyy-MM
     * 年-yyyy
     *
     * @author LS
     * @date 2019/10/28
     */
    private String period;
    /**
     * 总数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long totalNum = 0L;
    /**
     * 个人用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long grNum = 0L;
    /**
     * 个体用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long gtNum = 0L;
    /**
     * 企业用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long qyNum = 0L;
    /**
     * 其他用户数
     *
     * @author LS
     * @date 2019/10/28
     */
    private Long otherNum = 0L;
    /**
     * 来源
     *
     * @author lpp
     * @date 2020/4/17 13:59
     */
    private String source;
    /**
     * 用户信息集合
     *
     * @author lpp
     * @date 2020/4/17 14:35
     */
    private List<MemberStatDmResForm> memberStatDmList;

    /**
     * 地区等级
     *
     * @author lpp
     * @date 2020/4/17 15:11
     */
    private Integer areaRank;
    /**
     * 地区层级串
     *
     * @author lpp
     * @date 2020/4/17 15:17
     */
    private String areaAxis;
    /**
     * 地区名称
     *
     * @author lpp
     * @date 2020/4/17 15:18
     */
    private String areaName;

    public Integer getAreaRank() {
        return areaRank;
    }

    public void setAreaRank(Integer areaRank) {
        this.areaRank = areaRank;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public List<MemberStatDmResForm> getMemberStatDmList() {
        return memberStatDmList;
    }

    public void setMemberStatDmList(List<MemberStatDmResForm> memberStatDmList) {
        this.memberStatDmList = memberStatDmList;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public Long getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Long totalNum) {
        this.totalNum = totalNum;
    }

    public Long getGrNum() {
        return grNum;
    }

    public void setGrNum(Long grNum) {
        this.grNum = grNum;
    }

    public Long getGtNum() {
        return gtNum;
    }

    public void setGtNum(Long gtNum) {
        this.gtNum = gtNum;
    }

    public Long getQyNum() {
        return qyNum;
    }

    public void setQyNum(Long qyNum) {
        this.qyNum = qyNum;
    }

    public Long getOtherNum() {
        return otherNum;
    }

    public void setOtherNum(Long otherNum) {
        this.otherNum = otherNum;
    }

    @Override
    public String toString() {
        return "MemberStatDmResForm{" +
                "period='" + period + '\'' +
                ", totalNum=" + totalNum +
                ", grNum=" + grNum +
                ", gtNum=" + gtNum +
                ", qyNum=" + qyNum +
                ", otherNum=" + otherNum +
                ", source='" + source + '\'' +
                ", memberStatDmList=" + memberStatDmList +
                '}';
    }
}
