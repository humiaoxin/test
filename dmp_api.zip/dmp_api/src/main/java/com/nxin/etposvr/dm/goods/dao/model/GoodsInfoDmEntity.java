package com.nxin.etposvr.dm.goods.dao.model;

import com.nxin.etposvr.dm.shop.dao.model.ShopClassifyGoodsDmEntity;
import com.nxin.etposvr.dm.shop.dao.model.ShopInfoDmEntity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class GoodsInfoDmEntity {

    public String id;

    public String name;

    public String shopId;

    private Byte systemId;

    public String type;

    private String categoryAxis;

    private String categoryName;

    private String areaAxis;

    private String areaFullName;

    public List<GoodsAttrDmEntity> goodsAttrDmEntityList;

    public List<GoodsSpecDmEntity> goodsSpecDmEntityList;

    public List<ShopClassifyGoodsDmEntity> shopClassifyGoodsDmEntityList;

    public ShopInfoDmEntity shopInfoDmEntity;

    public String oneCategoryId;

    public String twoCategoryId;

    public String categoryId;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    public String promotionType;

    public String thumbnailUrl;

    public String saleMode;

    private Date vno;

    private Date expireTime;

    private String expireTimeStr;

    private Date publishTime;

    private Long sellerBoId;

    /**
     * 地块所在纬度
     *
     * @param null
     * @return
     * @author XiaoShuai
     * @since 2020/9/1 16:26
     */
    private String latitude;

    /**
     * 地块所在经度
     *
     * @param null
     * @return
     * @author XiaoShuai
     * @since 2020/9/1 16:26
     */
    private String longitude;

    private Long shopAreaId;
    private String shopAreaAxis;
    private String shopAreaFullName;
    private Long memberAreaId;
    private String memberAreaAxis;
    private String memberAreaFullName;

    public String getShopAreaAxis() {
        return shopAreaAxis;
    }

    public void setShopAreaAxis(String shopAreaAxis) {
        this.shopAreaAxis = shopAreaAxis;
    }

    public String getShopAreaFullName() {
        return shopAreaFullName;
    }

    public void setShopAreaFullName(String shopAreaFullName) {
        this.shopAreaFullName = shopAreaFullName;
    }

    public String getMemberAreaAxis() {
        return memberAreaAxis;
    }

    public void setMemberAreaAxis(String memberAreaAxis) {
        this.memberAreaAxis = memberAreaAxis;
    }

    public String getMemberAreaFullName() {
        return memberAreaFullName;
    }

    public void setMemberAreaFullName(String memberAreaFullName) {
        this.memberAreaFullName = memberAreaFullName;
    }

    public Long getShopAreaId() {
        return shopAreaId;
    }

    public void setShopAreaId(Long shopAreaId) {
        this.shopAreaId = shopAreaId;
    }

    public Long getMemberAreaId() {
        return memberAreaId;
    }

    public void setMemberAreaId(Long memberAreaId) {
        this.memberAreaId = memberAreaId;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public List<ShopClassifyGoodsDmEntity> getShopClassifyGoodsDmEntityList() {
        return shopClassifyGoodsDmEntityList;
    }

    public void setShopClassifyGoodsDmEntityList(List<ShopClassifyGoodsDmEntity> shopClassifyGoodsDmEntityList) {
        this.shopClassifyGoodsDmEntityList = shopClassifyGoodsDmEntityList;
    }

    public ShopInfoDmEntity getShopInfoDmEntity() {
        return shopInfoDmEntity;
    }

    public void setShopInfoDmEntity(ShopInfoDmEntity shopInfoDmEntity) {
        this.shopInfoDmEntity = shopInfoDmEntity;
    }

    /**
     * 客户boId集合
     */
    public List<Long> boIdList;

    /**
     * 第几页
     */
    private Integer pageNum;
    /**
     * 条数
     */
    private Integer pageSize;
    /**
     * 排序参数
     */
    private Integer sortParam;
    /**
     * 分组参数
     */
    private Integer groupParam;
    /**
     * 查询条件参数
     */
    private Integer typeParam;
    /**
     * 总条数
     */
    private Integer total;

    private String categoryAxisLike;

    /**销售价*/
    public BigDecimal sellPrice;
    /**当前库存*/
    public BigDecimal currStock;
    /**A数量*/
    private Integer count;

    private String status;

    private Long goodsId;

    /**品类集合*/
    private List<Long> categoryIds;

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getCurrStock() {
        return currStock;
    }

    public void setCurrStock(BigDecimal currStock) {
        this.currStock = currStock;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public String getExpireTimeStr() {
        return expireTimeStr;
    }

    public void setExpireTimeStr(String expireTimeStr) {
        this.expireTimeStr = expireTimeStr;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<GoodsAttrDmEntity> getGoodsAttrDmEntityList() {
        return goodsAttrDmEntityList;
    }

    public void setGoodsAttrDmEntityList(List<GoodsAttrDmEntity> goodsAttrDmEntityList) {
        this.goodsAttrDmEntityList = goodsAttrDmEntityList;
    }

    public List<GoodsSpecDmEntity> getGoodsSpecDmEntityList() {
        return goodsSpecDmEntityList;
    }

    public void setGoodsSpecDmEntityList(List<GoodsSpecDmEntity> goodsSpecDmEntityList) {
        this.goodsSpecDmEntityList = goodsSpecDmEntityList;
    }

    public String getOneCategoryId() {
        return oneCategoryId;
    }

    public void setOneCategoryId(String oneCategoryId) {
        this.oneCategoryId = oneCategoryId;
    }

    public String getTwoCategoryId() {
        return twoCategoryId;
    }

    public void setTwoCategoryId(String twoCategoryId) {
        this.twoCategoryId = twoCategoryId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public String getSaleMode() {
        return saleMode;
    }

    public void setSaleMode(String saleMode) {
        this.saleMode = saleMode;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getSortParam() {
        return sortParam;
    }

    public void setSortParam(Integer sortParam) {
        this.sortParam = sortParam;
    }

    public Integer getGroupParam() {
        return groupParam;
    }

    public void setGroupParam(Integer groupParam) {
        this.groupParam = groupParam;
    }

    public Integer getTypeParam() {
        return typeParam;
    }

    public void setTypeParam(Integer typeParam) {
        this.typeParam = typeParam;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("GoodsInfoDmEntity{");
        sb.append("id='").append(id).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", shopId='").append(shopId).append('\'');
        sb.append(", systemId=").append(systemId);
        sb.append(", type='").append(type).append('\'');
        sb.append(", categoryAxis='").append(categoryAxis).append('\'');
        sb.append(", categoryName='").append(categoryName).append('\'');
        sb.append(", areaAxis='").append(areaAxis).append('\'');
        sb.append(", areaFullName='").append(areaFullName).append('\'');
        sb.append(", goodsAttrDmEntityList=").append(goodsAttrDmEntityList);
        sb.append(", goodsSpecDmEntityList=").append(goodsSpecDmEntityList);
        sb.append(", shopClassifyGoodsDmEntityList=").append(shopClassifyGoodsDmEntityList);
        sb.append(", shopInfoDmEntity=").append(shopInfoDmEntity);
        sb.append(", oneCategoryId='").append(oneCategoryId).append('\'');
        sb.append(", twoCategoryId='").append(twoCategoryId).append('\'');
        sb.append(", categoryId='").append(categoryId).append('\'');
        sb.append(", oneAreaId='").append(oneAreaId).append('\'');
        sb.append(", twoAreaId='").append(twoAreaId).append('\'');
        sb.append(", areaId='").append(areaId).append('\'');
        sb.append(", promotionType='").append(promotionType).append('\'');
        sb.append(", thumbnailUrl='").append(thumbnailUrl).append('\'');
        sb.append(", saleMode='").append(saleMode).append('\'');
        sb.append(", vno=").append(vno);
        sb.append(", expireTime=").append(expireTime);
        sb.append(", expireTimeStr='").append(expireTimeStr).append('\'');
        sb.append(", publishTime=").append(publishTime);
        sb.append(", sellerBoId=").append(sellerBoId);
        sb.append(", latitude='").append(latitude).append('\'');
        sb.append(", longitude='").append(longitude).append('\'');
        sb.append(", boIdList=").append(boIdList);
        sb.append(", pageNum=").append(pageNum);
        sb.append(", pageSize=").append(pageSize);
        sb.append(", sortParam=").append(sortParam);
        sb.append(", groupParam=").append(groupParam);
        sb.append(", typeParam=").append(typeParam);
        sb.append(", total=").append(total);
        sb.append(", categoryAxisLike='").append(categoryAxisLike).append('\'');
        sb.append(", sellPrice=").append(sellPrice);
        sb.append(", currStock=").append(currStock);
        sb.append(", count=").append(count);
        sb.append(", status='").append(status).append('\'');
        sb.append(", goodsId=").append(goodsId);
        sb.append(", categoryIds=").append(categoryIds);
        sb.append('}');
        return sb.toString();
    }
}
