package com.nxin.etposvr.dm.member.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup101th;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import com.nxin.etposvr.dm.goods.dao.model.GoodsInfoDmEntity;
import com.nxin.etposvr.dm.member.dao.model.MemberInfoDmEntity;
import com.nxin.etposvr.dm.system.dao.model.SystemEvaluateDmEntity;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.List;

public class MemberDmReqForm extends WebPageParam {
    /**
     * 服务人员boId
     */
    @ApiModelProperty(value = "服务人员boId", example = "110119011415270001", dataType = "Long")
    @NotNull(message = "000001|服务人员boId", groups = {VldGroup1th.class})
    private Long boId;
    /**
     * 客户boId集合
     */
    @ApiModelProperty(value = "客户boId集合", example = "110119011415270001", dataType = "List")
    @NotNull(message = "000001|客户boId集合", groups = {VldGroup2th.class})
    public List<Long> boIdList;

    @ApiModelProperty(value = "系统Id", example = "2", dataType = "Byte")
    @NotNull(message = "000001|系统Id", groups = {VldGroup1th.class, VldGroup2th.class})
    private Byte systemId;

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    /**
     * 成长值
     */
    private Integer growthValue;
    /**
     * 等级
     */
    private Integer rank;
    /**
     * 会员等级名称
     */
    private String rankName;

    /**
     * 姓名
     */
    private String  realName;

    /**
     * 手机号
     */
    private String mobilePhone;

    public Integer getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(Integer growthValue) {
        this.growthValue = growthValue;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @Override
    public String toString() {
        return "MemberDmReqForm{" +
                "boId=" + boId +
                ", boIdList=" + boIdList +
                ", systemId=" + systemId +
                ", growthValue=" + growthValue +
                ", rank=" + rank +
                ", rankName='" + rankName + '\'' +
                ", realName='" + realName + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                '}';
    }
}
