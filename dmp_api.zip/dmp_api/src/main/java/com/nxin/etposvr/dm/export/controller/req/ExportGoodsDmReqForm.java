package com.nxin.etposvr.dm.export.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;

/**
 * 导出商品入参
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/11/6 14:26
 */
public class ExportGoodsDmReqForm extends WebPageParam {

    @ApiModelProperty(value = "品类层级串(模糊查询)", dataType = "String")
    private String categoryAxisLike;

    @ApiModelProperty(value = "商品编码", dataType = "String")
    private Long id;

    @ApiModelProperty(value = "商品名称(模糊查询)", dataType = "String")
    private String nameLike;

    @ApiModelProperty(value = "上架时间(开始)", dataType = "String")
    private Date onTimeDateEnd;

    @ApiModelProperty(value = "上架时间(结束)", dataType = "String")
    private Date onTimeDateStart;

    @ApiModelProperty(value = "店铺名称", dataType = "String")
    private String shopName;

    @ApiModelProperty(value = "状态集合", dataType = "String")
    private List<String> statusList;

    @ApiModelProperty(value = "系統id集合", dataType = "String")
    private Byte systemId;

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameLike() {
        return nameLike;
    }

    public void setNameLike(String nameLike) {
        this.nameLike = nameLike;
    }

    public Date getOnTimeDateEnd() {
        return onTimeDateEnd;
    }

    public void setOnTimeDateEnd(Date onTimeDateEnd) {
        this.onTimeDateEnd = onTimeDateEnd;
    }

    public Date getOnTimeDateStart() {
        return onTimeDateStart;
    }

    public void setOnTimeDateStart(Date onTimeDateStart) {
        this.onTimeDateStart = onTimeDateStart;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "ExportGoodsReqForm{" +
                "categoryAxisLike='" + categoryAxisLike + '\'' +
                ", id=" + id +
                ", nameLike='" + nameLike + '\'' +
                ", onTimeDateEnd=" + onTimeDateEnd +
                ", onTimeDateStart=" + onTimeDateStart +
                ", shopName='" + shopName + '\'' +
                ", statusList=" + statusList +
                ", systemId=" + systemId +
                '}';
    }
}
