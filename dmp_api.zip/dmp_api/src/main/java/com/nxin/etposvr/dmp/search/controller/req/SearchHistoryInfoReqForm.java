package com.nxin.etposvr.dmp.search.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 搜索历史 reqForm
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/5/29 13:31
 */
public class SearchHistoryInfoReqForm extends WebPageParam {
    @NotNull(message = "000001|搜索历史id", groups = {VldGroup1th.class})
    @ApiModelProperty(value = "搜索历史id", example = "1")
    private Long id;

    @NotNull(message = "000001|搜索历史属性值", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "搜索历史属性值", example = "商品")
    private String searchValue;

    @NotNull(message = "000001|类型（商品SP/店铺DP/资讯ZX）", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "类型（商品SP/店铺DP/资讯ZX）", example = "SP,DP")
    private String type;

    @NotNull(message = "000001|主体用户boId", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "主体用户boId", example = "1")
    private Long boId;

    @NotNull(message = "000001|操作人用户boId", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "操作人用户boId", example = "1")
    private Long oprBoId;

    @NotNull(message = "000001|用户类型", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "用户类型", example = "GR")
    private String userType;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Byte isEnabled;

    /**
     * 搜索值模糊查询
     */
    private String searchValueLike;

    /**
     * 类型模糊查询
     */
    private String typeLike;
    @Valid
    private List<SearchHistoryInfoReqForm> searchHistoryInfoReqFormList;

    public String getTypeLike() {
        return typeLike;
    }

    public void setTypeLike(String typeLike) {
        this.typeLike = typeLike;
    }

    public List<SearchHistoryInfoReqForm> getSearchHistoryInfoReqFormList() {
        return searchHistoryInfoReqFormList;
    }

    public void setSearchHistoryInfoReqFormList(List<SearchHistoryInfoReqForm> searchHistoryInfoReqFormList) {
        this.searchHistoryInfoReqFormList = searchHistoryInfoReqFormList;
    }

    public String getSearchValueLike() {
        return searchValueLike;
    }

    public void setSearchValueLike(String searchValueLike) {
        this.searchValueLike = searchValueLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue == null ? null : searchValue.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType == null ? null : userType.trim();
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}
