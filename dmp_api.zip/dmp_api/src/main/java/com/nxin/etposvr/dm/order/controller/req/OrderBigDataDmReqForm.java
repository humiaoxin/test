package com.nxin.etposvr.dm.order.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;

/**
 * 订单大数据请求实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class OrderBigDataDmReqForm extends WebPageParam {

    /**系统ID*/
    private Byte systemId;
    /**
     * 品类集合
     */
    private List<Long> categoryIds;
    /**
     * 范围（天数、月数、年数）
     */
    private Integer range;
    /**
     * 类型（按日DAY、按月MONTH、按年YEAR）
     */
    private String statType;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 品类层级
     */
    private Integer rank;

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    @Override
    public String toString() {
        return "OrderBigDataDmReqForm{" +
                "systemId=" + systemId +
                ", categoryIds=" + categoryIds +
                ", range=" + range +
                ", statType='" + statType + '\'' +
                '}';
    }
}
