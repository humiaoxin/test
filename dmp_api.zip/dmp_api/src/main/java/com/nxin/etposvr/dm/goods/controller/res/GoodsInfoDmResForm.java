package com.nxin.etposvr.dm.goods.controller.res;

import com.nxin.etposvr.dm.goods.dao.model.GoodsAttrDmEntity;
import com.nxin.etposvr.dm.goods.dao.model.GoodsSpecDmEntity;

import java.util.Date;
import java.util.List;

public class GoodsInfoDmResForm {

    public String id;

    public String name;

    public String shopId;

    private String systemId;

    public String type;

    private String categoryAxis;

    private String categoryName;

    private String areaAxis;

    private String areaFullName;

    public List<GoodsAttrDmEntity> goodsAttrDmEntityList;

    public List<GoodsSpecDmEntity> goodsSpecDmEntityList;

    public String oneCategoryId;

    public String twoCategoryId;

    public String categoryId;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    public String promotionType;

    public String thumbnailUrl;

    public String saleMode;

    private Date  vno;

    private Date expireTime;

    private Date publishTime;

    private Long sellerBoId;

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<GoodsAttrDmEntity> getGoodsAttrDmEntityList() {
        return goodsAttrDmEntityList;
    }

    public void setGoodsAttrDmEntityList(List<GoodsAttrDmEntity> goodsAttrDmEntityList) {
        this.goodsAttrDmEntityList = goodsAttrDmEntityList;
    }

    public List<GoodsSpecDmEntity> getGoodsSpecDmEntityList() {
        return goodsSpecDmEntityList;
    }

    public void setGoodsSpecDmEntityList(List<GoodsSpecDmEntity> goodsSpecDmEntityList) {
        this.goodsSpecDmEntityList = goodsSpecDmEntityList;
    }

    public String getOneCategoryId() {
        return oneCategoryId;
    }

    public void setOneCategoryId(String oneCategoryId) {
        this.oneCategoryId = oneCategoryId;
    }

    public String getTwoCategoryId() {
        return twoCategoryId;
    }

    public void setTwoCategoryId(String twoCategoryId) {
        this.twoCategoryId = twoCategoryId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public Date getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public String getSaleMode() {
        return saleMode;
    }

    public void setSaleMode(String saleMode) {
        this.saleMode = saleMode;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("GoodsInfoDmResForm{");
        sb.append("id='").append(id).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", shopId='").append(shopId).append('\'');
        sb.append(", systemId='").append(systemId).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", categoryAxis='").append(categoryAxis).append('\'');
        sb.append(", categoryName='").append(categoryName).append('\'');
        sb.append(", areaAxis='").append(areaAxis).append('\'');
        sb.append(", areaFullName='").append(areaFullName).append('\'');
        sb.append(", goodsAttrDmEntityList=").append(goodsAttrDmEntityList);
        sb.append(", goodsSpecDmEntityList=").append(goodsSpecDmEntityList);
        sb.append(", oneCategoryId='").append(oneCategoryId).append('\'');
        sb.append(", twoCategoryId='").append(twoCategoryId).append('\'');
        sb.append(", categoryId='").append(categoryId).append('\'');
        sb.append(", oneAreaId='").append(oneAreaId).append('\'');
        sb.append(", twoAreaId='").append(twoAreaId).append('\'');
        sb.append(", areaId='").append(areaId).append('\'');
        sb.append(", promotionType='").append(promotionType).append('\'');
        sb.append(", thumbnailUrl='").append(thumbnailUrl).append('\'');
        sb.append(", saleMode='").append(saleMode).append('\'');
        sb.append(", vno=").append(vno);
        sb.append(", expireTime=").append(expireTime);
        sb.append(", publishTime=").append(publishTime);
        sb.append(", sellerBoId=").append(sellerBoId);
        sb.append('}');
        return sb.toString();
    }
}
