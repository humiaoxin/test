package com.nxin.etposvr.dm.base.controller.res;

import com.nxin.etposvr.dm.base.dao.model.BaseInfoDmEntity;

/**
 * 土地
 *
 * @author TianShiWei
 * @since: 2019/12/13 14:37
 * @version: v_1.0.1
 */
public class BaseInfoDmResForm extends BaseInfoDmEntity {
}
