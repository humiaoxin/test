package com.nxin.etposvr.dm.shop.controller.res;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

public class ShopInfoDmResForm {

    public String id;

    public String name;

    private String systemId;

    public String busiScopeCode;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    private String areaAxis;

    private String areaFullName;

    private String busiScopeName;

    private String shopName;

    private String logo;

    private int goodsCount;
    /**
     * 客户boId集合
     */
    public List<Long> boIdList;

    /**
     * 标签状态
     *
     * @author lpp
     * @date 2020/3/16 14:20
     */
    private String tagsStatus;
    /**
     * 店铺企业名称
     *
     * @author lpp
     * @date 2020/3/16 14:21
     */
    private String realName;
    /**
     * 创建时间
     *
     * @author lpp
     * @date 2020/3/16 14:21
     */
    private Date createTime;
    /**
     * 排序
     *
     * @author lpp
     * @date 2020/3/16 14:21
     */
    private String sort;
    /**
     * 用户类型
     *
     * @author lpp
     * @date 2020/3/16 15:02
     */
    public String userType;
    /**
     * 店铺电话
     *
     * @author lpp
     * @date 2020/3/16 15:02
     */
    public String tel;

    /**
     * 审核状态
     */
    private String auditStatus;
    /**
     * 标签状态-中文
     *
     * @author lpp
     * @date 2020/3/16 16:36
     */
    private String tagsStatusCn;
    /**
     * 用户类型-中文
     *
     * @author lpp
     * @date 2020/3/16 16:43
     */
    private String userTypeCn;

    public String getTagsStatusCn() {
        return tagsStatusCn;
    }

    public void setTagsStatusCn(String tagsStatusCn) {
        this.tagsStatusCn = tagsStatusCn;
    }

    public String getUserTypeCn() {
        return userTypeCn;
    }

    public void setUserTypeCn(String userTypeCn) {
        this.userTypeCn = userTypeCn;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getTagsStatus() {
        return tagsStatus;
    }

    public void setTagsStatus(String tagsStatus) {
        this.tagsStatus = tagsStatus;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getBusiScopeName() {
        return busiScopeName;
    }

    public void setBusiScopeName(String busiScopeName) {
        this.busiScopeName = busiScopeName;
    }

    public String getBusiScopeCode() {
        return busiScopeCode;
    }

    public void setBusiScopeCode(String busiScopeCode) {
        this.busiScopeCode = busiScopeCode;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public int getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(int goodsCount) {
        this.goodsCount = goodsCount;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    @Override
    public String toString() {
        return "ShopInfoDmResForm{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", systemId='" + systemId + '\'' +
                ", busiScopeCode='" + busiScopeCode + '\'' +
                ", oneAreaId='" + oneAreaId + '\'' +
                ", twoAreaId='" + twoAreaId + '\'' +
                ", areaId='" + areaId + '\'' +
                ", areaAxis='" + areaAxis + '\'' +
                ", areaFullName='" + areaFullName + '\'' +
                ", busiScopeName='" + busiScopeName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", logo='" + logo + '\'' +
                ", goodsCount=" + goodsCount +
                ", boIdList=" + boIdList +
                ", tagsStatus='" + tagsStatus + '\'' +
                ", realName='" + realName + '\'' +
                ", createTime=" + createTime +
                ", sort='" + sort + '\'' +
                '}';
    }
}
