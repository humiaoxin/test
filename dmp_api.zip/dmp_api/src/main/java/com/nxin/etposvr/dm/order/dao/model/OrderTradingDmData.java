package com.nxin.etposvr.dm.order.dao.model;

import java.math.BigDecimal;

/**
 * 查询交易数据
 */
public class OrderTradingDmData {

    /**
     * 交易量
     */
    private BigDecimal businessCount;
    /**
     * 交易额
     */
    private BigDecimal amount;

    public BigDecimal getBusinessCount() {
        return businessCount;
    }

    public void setBusinessCount(BigDecimal businessCount) {
        this.businessCount = businessCount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
