package com.nxin.etposvr.dm.elasticsearch.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import javax.validation.Valid;
import java.util.List;

/**
 * 用户标签
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/6/11 19:39
 */
public class MemberTagEsReqForm extends WebPageParam {

    public Long boId;

    @Valid
    public List<MemberTagEsReqForm> memberTagEsReqFormList;

    public Integer isPage = 0;

    @Valid
    public List<JestClientReqForm> jestClientReqFormList;

    /** 商品消息处理状态 （1.添加， 2.删除） */
    private String mqStatus;

    public List<MemberTagEsReqForm> getMemberTagEsReqFormList() {
        return memberTagEsReqFormList;
    }

    public void setMemberTagEsReqFormList(List<MemberTagEsReqForm> memberTagEsReqFormList) {
        this.memberTagEsReqFormList = memberTagEsReqFormList;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public List<JestClientReqForm> getJestClientReqFormList() {
        return jestClientReqFormList;
    }

    public void setJestClientReqFormList(List<JestClientReqForm> jestClientReqFormList) {
        this.jestClientReqFormList = jestClientReqFormList;
    }

    public String getMqStatus() {
        return mqStatus;
    }

    public void setMqStatus(String mqStatus) {
        this.mqStatus = mqStatus;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }
}
