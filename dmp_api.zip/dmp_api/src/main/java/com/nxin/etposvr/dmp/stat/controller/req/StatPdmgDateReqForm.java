package com.nxin.etposvr.dmp.stat.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 品类
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:11
 * @version: v_1.0.1
 */
public class StatPdmgDateReqForm extends WebPageParam {
    /**
     * @Fields id id
     */
    private Long id;

    /**
     * @Fields dataDate 数据日期
     */
    private String dataDate;

    /**
     * @Fields dataYearMonth 数据年月
     */
    private String dataYearMonth;

    /**
     * @Fields dataYear 数据年份
     */
    private String dataYear;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    private String num;

    private Map<String, List<String>> typeMap;

    private String statType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getDataYearMonth() {
        return dataYearMonth;
    }

    public void setDataYearMonth(String dataYearMonth) {
        this.dataYearMonth = dataYearMonth;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public Map<String, List<String>> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(Map<String, List<String>> typeMap) {
        this.typeMap = typeMap;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }
}
