package com.nxin.etposvr.dmp.cma.controller.req;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class CmaRawDataTemReqForm {

    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "类型", example = "DAY")
    private String type;

    @ApiModelProperty(value = "区站号", example = "123")
    private Integer siteId;

    @ApiModelProperty(value = "纬度", example = "123")
    private Integer latitude;

    @ApiModelProperty(value = "经度", example = "123")
    private Integer longtitude;

    @ApiModelProperty(value = "观测场拔海高度", example = "123")
    private Integer altitude;

    @ApiModelProperty(value = "年", example = "2020")
    private Integer year;

    @ApiModelProperty(value = "月", example = "1")
    private Integer month;

    @ApiModelProperty(value = "日", example = "1")
    private Integer day;

    @ApiModelProperty(value = "平均气温", example = "1")
    private Integer averageTem;

    @ApiModelProperty(value = "日最高气温", example = "2")
    private Integer hiTem;

    @ApiModelProperty(value = "日最低气温", example = "1")
    private Integer lowTem;

    @ApiModelProperty(value = "平均气温质量控制码", example = "1")
    private Integer averageTemCode;

    @ApiModelProperty(value = "日最高气温质量控制码", example = "1")
    private Integer hiTemCode;

    @ApiModelProperty(value = "日最低气温质量控制码", example = "1")
    private Integer lowTemCode;

    @ApiModelProperty(value = "所属系统", example = "1")
    private Byte systemId;

    @ApiModelProperty(value = "数据说明 开发时写入")
    private String dataRemark;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "版本说明")
    private String versionRemark;

    @ApiModelProperty(value = "版本号")
    private Date vno;

    @ApiModelProperty(value = "是否可用 1可用 0不可用")
    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public Integer getLatitude() {
        return latitude;
    }

    public void setLatitude(Integer latitude) {
        this.latitude = latitude;
    }

    public Integer getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Integer longtitude) {
        this.longtitude = longtitude;
    }

    public Integer getAltitude() {
        return altitude;
    }

    public void setAltitude(Integer altitude) {
        this.altitude = altitude;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getAverageTem() {
        return averageTem;
    }

    public void setAverageTem(Integer averageTem) {
        this.averageTem = averageTem;
    }

    public Integer getHiTem() {
        return hiTem;
    }

    public void setHiTem(Integer hiTem) {
        this.hiTem = hiTem;
    }

    public Integer getLowTem() {
        return lowTem;
    }

    public void setLowTem(Integer lowTem) {
        this.lowTem = lowTem;
    }

    public Integer getAverageTemCode() {
        return averageTemCode;
    }

    public void setAverageTemCode(Integer averageTemCode) {
        this.averageTemCode = averageTemCode;
    }

    public Integer getHiTemCode() {
        return hiTemCode;
    }

    public void setHiTemCode(Integer hiTemCode) {
        this.hiTemCode = hiTemCode;
    }

    public Integer getLowTemCode() {
        return lowTemCode;
    }

    public void setLowTemCode(Integer lowTemCode) {
        this.lowTemCode = lowTemCode;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        return "CmaRawDataTemReqForm{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", siteId=" + siteId +
                ", latitude=" + latitude +
                ", longtitude=" + longtitude +
                ", altitude=" + altitude +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", averageTem=" + averageTem +
                ", hiTem=" + hiTem +
                ", lowTem=" + lowTem +
                ", averageTemCode=" + averageTemCode +
                ", hiTemCode=" + hiTemCode +
                ", lowTemCode=" + lowTemCode +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                '}';
    }
}
