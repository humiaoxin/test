package com.nxin.etposvr.dm.base.dao.model;


/**
 * @author TianShiWei
 * @since:  2019/10/23 13:30
 * @version: v_1.0.1
 */
public class BaseUniqueIdInfoDmEntity {
    private Long holderBoId;
    private Float enabRatio;
    private Integer uniqueIdSum;
    private Float disEnabRatio;
    private Float recoveryRatio;
    private Float disRecoveryRatio;
    private String holderName;
    private String imgUrl;

    public Long getHolderBoId() {
        return holderBoId;
    }

    public void setHolderBoId(Long holderBoId) {
        this.holderBoId = holderBoId;
    }

    public Float getEnabRatio() {
        return enabRatio;
    }

    public void setEnabRatio(Float enabRatio) {
        this.enabRatio = enabRatio;
    }

    public Integer getUniqueIdSum() {
        return uniqueIdSum;
    }

    public void setUniqueIdSum(Integer uniqueIdSum) {
        this.uniqueIdSum = uniqueIdSum;
    }

    public Float getDisEnabRatio() {
        return disEnabRatio;
    }

    public void setDisEnabRatio(Float disEnabRatio) {
        this.disEnabRatio = disEnabRatio;
    }

    public Float getRecoveryRatio() {
        return recoveryRatio;
    }

    public void setRecoveryRatio(Float recoveryRatio) {
        this.recoveryRatio = recoveryRatio;
    }

    public Float getDisRecoveryRatio() {
        return disRecoveryRatio;
    }

    public void setDisRecoveryRatio(Float disRecoveryRatio) {
        this.disRecoveryRatio = disRecoveryRatio;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
