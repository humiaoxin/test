package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatPdmgCategory;

/**
 * 品类
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:11
 * @version: v_1.0.1
 */
public class StatPdmgCategoryResForm extends StatPdmgCategory {

    private String num;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
