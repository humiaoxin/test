package com.nxin.etposvr.dm.finance.controller.req;


import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 查询还款bo
 * @author sjw
 * @since 2020/4/10
 */
public class RePayAmountDmReqForm extends WebPageParam {

    /**
     * 请求流水号
     */
    private String serialNum;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String endTime;
    /**
     * 平台来源
     */
    private String platformSource;
    /**
     * 私钥签名
     */
    private String signMsg;

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getPlatformSource() {
        return platformSource;
    }

    public void setPlatformSource(String platformSource) {
        this.platformSource = platformSource;
    }

    public String getSignMsg() {
        return signMsg;
    }

    public void setSignMsg(String signMsg) {
        this.signMsg = signMsg;
    }

    @Override
    public String toString() {
        return "RepaymentAmountDailyDmBo{" +
                "serialNum='" + serialNum + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", platformSource='" + platformSource + '\'' +
                ", signMsg='" + signMsg + '\'' +
                '}';
    }
}