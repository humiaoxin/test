package com.nxin.etposvr.dm.report.controller.res;

import com.nxin.etposvr.dm.report.dao.model.RemindRecordDmEntity;

public class RemindRecordDmResForm extends RemindRecordDmEntity {
}
