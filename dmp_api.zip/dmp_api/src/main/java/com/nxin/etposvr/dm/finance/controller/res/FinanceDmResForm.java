package com.nxin.etposvr.dm.finance.controller.res;


import java.math.BigDecimal;
import java.util.Date;

/**
 * 金融bo
 *
 * @author sjw
 * @since 2020/4/10
 */
public class FinanceDmResForm {

    private Byte systemId;

    private Date startTime;

    private Date endTime;

    /**
     * 累计总额
     */
    private BigDecimal totalAmount;
    /**
     * 累计贷款金额
     */
    private BigDecimal loanAmount;
    /**
     * 累计支付金额
     */
    private BigDecimal payAmount;
    /**
     * 累计贷款用户
     */
    private Long loanUser;

    /**
     * 支付类型
     */
    private String paymentCode;
    /**
     * 银行卡类型占比
     */
    private String cardPercent;
    /**
     * 微信类型占比
     */
    private String wxPercent;
    /**
     * pos类型占比
     */
    private String posPercent;
    /**
     * 贷款类型占比
     */
    private String loanPercent;

    /**
     * 支付宝类型占比
     */
    private String zfbPercent;

    /**
     * 网银类型占比
     */
    private String wyPercent;
    /**
     * 余额类型占比
     */
    private String yePercent;

    /**
     * 贷款时间
     */
    private Date loanTime;

    /**
     * 银行卡用户支付金额
     */
    private BigDecimal cardAmount;
    /**
     * pos用户支付金额
     */
    private BigDecimal posAmount;
    /**
     * 微信用户支付金额
     */
    private BigDecimal wxAmount;

    /**
     * 支付宝用户支付金额
     */
    private BigDecimal zfbAmount;
    /**
     * 余额用户支付金额
     */
    private BigDecimal yeAmount;
    /**
     * 网银用户支付金额
     */
    private BigDecimal wyAmount;

    private BigDecimal returnAmount;

    private Date dateTime;

    /**
     * 纬度
     */
    private String lat;
    /**
     * 精度
     */
    private String lon;
    /**
     * 地区编号
     */
    private Long areaId;
    /**
     * 用户编号
     */
    private Long boId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public Long getLoanUser() {
        return loanUser;
    }

    public void setLoanUser(Long loanUser) {
        this.loanUser = loanUser;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }

    public String getCardPercent() {
        return cardPercent;
    }

    public void setCardPercent(String cardPercent) {
        this.cardPercent = cardPercent;
    }

    public String getWxPercent() {
        return wxPercent;
    }

    public void setWxPercent(String wxPercent) {
        this.wxPercent = wxPercent;
    }

    public String getPosPercent() {
        return posPercent;
    }

    public void setPosPercent(String posPercent) {
        this.posPercent = posPercent;
    }

    public String getLoanPercent() {
        return loanPercent;
    }

    public void setLoanPercent(String loanPercent) {
        this.loanPercent = loanPercent;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public BigDecimal getCardAmount() {
        return cardAmount;
    }

    public void setCardAmount(BigDecimal cardAmount) {
        this.cardAmount = cardAmount;
    }

    public BigDecimal getPosAmount() {
        return posAmount;
    }

    public void setPosAmount(BigDecimal posAmount) {
        this.posAmount = posAmount;
    }

    public BigDecimal getWxAmount() {
        return wxAmount;
    }

    public void setWxAmount(BigDecimal wxAmount) {
        this.wxAmount = wxAmount;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public String getZfbPercent() {
        return zfbPercent;
    }

    public void setZfbPercent(String zfbPercent) {
        this.zfbPercent = zfbPercent;
    }

    public String getWyPercent() {
        return wyPercent;
    }

    public void setWyPercent(String wyPercent) {
        this.wyPercent = wyPercent;
    }

    public String getYePercent() {
        return yePercent;
    }

    public void setYePercent(String yePercent) {
        this.yePercent = yePercent;
    }

    public BigDecimal getZfbAmount() {
        return zfbAmount;
    }

    public void setZfbAmount(BigDecimal zfbAmount) {
        this.zfbAmount = zfbAmount;
    }

    public BigDecimal getYeAmount() {
        return yeAmount;
    }

    public void setYeAmount(BigDecimal yeAmount) {
        this.yeAmount = yeAmount;
    }

    public BigDecimal getWyAmount() {
        return wyAmount;
    }

    public void setWyAmount(BigDecimal wyAmount) {
        this.wyAmount = wyAmount;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }
}