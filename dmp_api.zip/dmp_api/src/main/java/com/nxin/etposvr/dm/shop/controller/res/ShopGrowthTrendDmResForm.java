package com.nxin.etposvr.dm.shop.controller.res;

import com.nxin.etposvr.dm.shop.dao.model.ShopDmInfo;

import java.util.List;

/**
 * 店铺增长趋势返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class ShopGrowthTrendDmResForm {

    private String dates;
    private List<ShopDmInfo> shopDmInfos;

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public List<ShopDmInfo> getShopDmInfos() {
        return shopDmInfos;
    }

    public void setShopDmInfos(List<ShopDmInfo> shopDmInfos) {
        this.shopDmInfos = shopDmInfos;
    }
}
