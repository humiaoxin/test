package com.nxin.etposvr.dm.manage.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;

/**
 * @author TianShiWei
 * @since:  2019/10/30 9:56
 * @version: v_1.0.1
 */
public class ManageManufacturerDmReqForm extends WebPageParam {

    private String accordingType;

    private Integer range;

    private Byte systemId;

    private Date startTime;

    private Date endTime;

    private String id;

    private Long manuId;

    private String categoryAxis;

    private String areaAxisLike;

    private List<Long> idList;

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccordingType() {
        return accordingType;
    }

    public void setAccordingType(String accordingType) {
        this.accordingType = accordingType;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }
}
