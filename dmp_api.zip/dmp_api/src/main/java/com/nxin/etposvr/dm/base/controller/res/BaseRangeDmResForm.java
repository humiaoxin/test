package com.nxin.etposvr.dm.base.controller.res;

import com.nxin.etposvr.dm.base.dao.model.BaseRangeDmEntity;

/**
 *  菇棚resForm
 */
public class BaseRangeDmResForm extends BaseRangeDmEntity {


}
