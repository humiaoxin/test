package com.nxin.etposvr.dm.report.dao.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2019/11/18 15:27
 */
public class RecordEntryReportDmEntity {
    /**
     * 地块id
     */
    private Long baseInfoId;
    /**
     * 查询开始时间
     */
    private String timeStart;

    /**
     * 查询结束时间
     */
    private String timeEnd;
    /**
     * 名称
     */
    private String name;

    /**
     * 数量
     */
    private BigDecimal num;

    private  String numUnit;

    /**
     * 面积
     */
    private BigDecimal areaNum;

    /**
     * 数量百分比
     */
    private String numPercent;

    /**
     * 时间
     */
    private String time;

    /**
     * 面积
     */
    private String area;

    /**
     * 产量
     */
    private String yield;

    private Long boId;

    private Long manufacturerId;

    private Byte systemId;

    private String recordType;

    private String baseInfoType;

    private String groupType;

    private String recordAttrType;

    private String recordAttrInfoDefType;

    private List<Long> categoryIdList;

    private Long materialId;

    private String materialName;

    private String materialJson;

    private Long  categoryId;

    private String categoryAxis;

    private String categoryName;

    private String automatic;

    private List<String> categoryAxisLikeList;

    private String categoryAxisLike;

    private Map<String, List<String>> typeMap;

    private String statType;

    private String type;

    private String dataYear;

    private String dataYearNum;

    public String getDataYearNum() {
        return dataYearNum;
    }

    public void setDataYearNum(String dataYearNum) {
        this.dataYearNum = dataYearNum;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getCategoryAxisLikeList() {
        return categoryAxisLikeList;
    }

    public void setCategoryAxisLikeList(List<String> categoryAxisLikeList) {
        this.categoryAxisLikeList = categoryAxisLikeList;
    }

    public String getCategoryAxisLike() {
        return categoryAxisLike;
    }

    public void setCategoryAxisLike(String categoryAxisLike) {
        this.categoryAxisLike = categoryAxisLike;
    }

    public Map<String, List<String>> getTypeMap() {
        return typeMap;
    }

    public void setTypeMap(Map<String, List<String>> typeMap) {
        this.typeMap = typeMap;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getNumUnit() {
        return numUnit;
    }

    public void setNumUnit(String numUnit) {
        this.numUnit = numUnit;
    }

    public List<Long> getCategoryIdList() {
        return categoryIdList;
    }

    public void setCategoryIdList(List<Long> categoryIdList) {
        this.categoryIdList = categoryIdList;
    }

    public String getRecordAttrInfoDefType() {
        return recordAttrInfoDefType;
    }

    public void setRecordAttrInfoDefType(String recordAttrInfoDefType) {
        this.recordAttrInfoDefType = recordAttrInfoDefType;
    }

    public String getRecordAttrType() {
        return recordAttrType;
    }

    public void setRecordAttrType(String recordAttrType) {
        this.recordAttrType = recordAttrType;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getBaseInfoType() {
        return baseInfoType;
    }

    public void setBaseInfoType(String baseInfoType) {
        this.baseInfoType = baseInfoType;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public BigDecimal getAreaNum() {
        return areaNum;
    }

    public void setAreaNum(BigDecimal areaNum) {
        this.areaNum = areaNum;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getYield() {
        return yield;
    }

    public void setYield(String yield) {
        this.yield = yield;
    }

    private String yearStr;

    public String getYearStr() {
        return yearStr;
    }

    public void setYearStr(String yearStr) {
        this.yearStr = yearStr;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getNumPercent() {
        return numPercent;
    }

    public void setNumPercent(String numPercent) {
        this.numPercent = numPercent;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Long baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getNum() {
        return num;
    }

    public void setNum(BigDecimal num) {
        this.num = num;
    }

    public Long getManufacturerId() {
        return manufacturerId;
    }

    public void setManufacturerId(Long manufacturerId) {
        this.manufacturerId = manufacturerId;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getMaterialJson() {
        return materialJson;
    }

    public void setMaterialJson(String materialJson) {
        this.materialJson = materialJson;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getAutomatic() {
        return automatic;
    }

    public void setAutomatic(String automatic) {
        this.automatic = automatic;
    }

    @Override
    public String toString() {
        return "RecordEntryReportDmEntity{" +
                "baseInfoId=" + baseInfoId +
                ", timeStart='" + timeStart + '\'' +
                ", timeEnd='" + timeEnd + '\'' +
                ", name='" + name + '\'' +
                ", num=" + num +
                ", numUnit='" + numUnit + '\'' +
                ", areaNum=" + areaNum +
                ", numPercent='" + numPercent + '\'' +
                ", time='" + time + '\'' +
                ", area='" + area + '\'' +
                ", yield='" + yield + '\'' +
                ", boId=" + boId +
                ", manufacturerId=" + manufacturerId +
                ", systemId=" + systemId +
                ", recordType='" + recordType + '\'' +
                ", baseInfoType='" + baseInfoType + '\'' +
                ", recordAttrType='" + recordAttrType + '\'' +
                ", recordAttrInfoDefType='" + recordAttrInfoDefType + '\'' +
                ", categoryIdList=" + categoryIdList +
                ", materialId=" + materialId +
                ", materialJson='" + materialJson + '\'' +
                ", yearStr='" + yearStr + '\'' +
                '}';
    }
}
