package com.nxin.etposvr.dmp.search.dao.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Title search_history_info表的实体类
 * @Description 搜索历史表
 * @version 1.0
 * @Author System
 * @Date 2019-06-13 15:06:04
 */
public class SearchHistoryInfo implements Serializable {
    /**
     * @Fields id 主键ID
     */
    private Long id;

    /**
     * @Fields searchValue 搜索值
     */
    private String searchValue;

    /**
     * @Fields type 类型(综合ZH/商品SP/店铺DP/资讯ZX)
     */
    private String type;

    /**
     * @Fields boId 主体用户ID
     */
    private Long boId;

    /**
     * @Fields oprBoId 操作人用户ID
     */
    private Long oprBoId;

    /**
     * @Fields userType 用户类型个人-GR 个体工商GT 企业-QY
     */
    private String userType;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 主键ID 字段:search_history_info.id
     *
     * @return search_history_info.id, 主键ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 主键ID 字段:search_history_info.id
     *
     * @param id the value for search_history_info.id, 主键ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 搜索值 字段:search_history_info.search_value
     *
     * @return search_history_info.search_value, 搜索值
     */
    public String getSearchValue() {
        return searchValue;
    }

    /**
     * 设置 搜索值 字段:search_history_info.search_value
     *
     * @param searchValue the value for search_history_info.search_value, 搜索值
     */
    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue == null ? null : searchValue.trim();
    }

    /**
     * 获取 类型(综合ZH/商品SP/店铺DP/资讯ZX) 字段:search_history_info.type
     *
     * @return search_history_info.type, 类型(综合ZH/商品SP/店铺DP/资讯ZX)
     */
    public String getType() {
        return type;
    }

    /**
     * 设置 类型(综合ZH/商品SP/店铺DP/资讯ZX) 字段:search_history_info.type
     *
     * @param type the value for search_history_info.type, 类型(综合ZH/商品SP/店铺DP/资讯ZX)
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 获取 主体用户ID 字段:search_history_info.bo_id
     *
     * @return search_history_info.bo_id, 主体用户ID
     */
    public Long getBoId() {
        return boId;
    }

    /**
     * 设置 主体用户ID 字段:search_history_info.bo_id
     *
     * @param boId the value for search_history_info.bo_id, 主体用户ID
     */
    public void setBoId(Long boId) {
        this.boId = boId;
    }

    /**
     * 获取 操作人用户ID 字段:search_history_info.opr_bo_id
     *
     * @return search_history_info.opr_bo_id, 操作人用户ID
     */
    public Long getOprBoId() {
        return oprBoId;
    }

    /**
     * 设置 操作人用户ID 字段:search_history_info.opr_bo_id
     *
     * @param oprBoId the value for search_history_info.opr_bo_id, 操作人用户ID
     */
    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    /**
     * 获取 用户类型个人-GR 个体工商GT 企业-QY 字段:search_history_info.user_type
     *
     * @return search_history_info.user_type, 用户类型个人-GR 个体工商GT 企业-QY
     */
    public String getUserType() {
        return userType;
    }

    /**
     * 设置 用户类型个人-GR 个体工商GT 企业-QY 字段:search_history_info.user_type
     *
     * @param userType the value for search_history_info.user_type, 用户类型个人-GR 个体工商GT 企业-QY
     */
    public void setUserType(String userType) {
        this.userType = userType == null ? null : userType.trim();
    }

    /**
     * 获取 所属系统 字段:search_history_info.system_id
     *
     * @return search_history_info.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:search_history_info.system_id
     *
     * @param systemId the value for search_history_info.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:search_history_info.data_remark
     *
     * @return search_history_info.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:search_history_info.data_remark
     *
     * @param dataRemark the value for search_history_info.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:search_history_info.create_time
     *
     * @return search_history_info.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:search_history_info.create_time
     *
     * @param createTime the value for search_history_info.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:search_history_info.version_remark
     *
     * @return search_history_info.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:search_history_info.version_remark
     *
     * @param versionRemark the value for search_history_info.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:search_history_info.vno
     *
     * @return search_history_info.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:search_history_info.vno
     *
     * @param vno the value for search_history_info.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:search_history_info.is_enabled
     *
     * @return search_history_info.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:search_history_info.is_enabled
     *
     * @param isEnabled the value for search_history_info.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :search_history_info
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", searchValue=").append(searchValue);
        sb.append(", type=").append(type);
        sb.append(", boId=").append(boId);
        sb.append(", oprBoId=").append(oprBoId);
        sb.append(", userType=").append(userType);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :search_history_info
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SearchHistoryInfo other = (SearchHistoryInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSearchValue() == null ? other.getSearchValue() == null : this.getSearchValue().equals(other.getSearchValue()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getBoId() == null ? other.getBoId() == null : this.getBoId().equals(other.getBoId()))
            && (this.getOprBoId() == null ? other.getOprBoId() == null : this.getOprBoId().equals(other.getOprBoId()))
            && (this.getUserType() == null ? other.getUserType() == null : this.getUserType().equals(other.getUserType()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :search_history_info
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSearchValue() == null) ? 0 : getSearchValue().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getBoId() == null) ? 0 : getBoId().hashCode());
        result = prime * result + ((getOprBoId() == null) ? 0 : getOprBoId().hashCode());
        result = prime * result + ((getUserType() == null) ? 0 : getUserType().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}