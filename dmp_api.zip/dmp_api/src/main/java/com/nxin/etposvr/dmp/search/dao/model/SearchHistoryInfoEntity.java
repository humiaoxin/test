package com.nxin.etposvr.dmp.search.dao.model;

import java.util.List;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/6/15 16:57
 */
public class SearchHistoryInfoEntity extends SearchHistoryInfo {
    /**
     * 搜索值模糊查询
     */
    private String searchValueLike;

    /**
     * 类型模糊查询
     */
    private String typeLike;

    private List<Byte> isEnabledList;

    /**
     * 第几页
     */
    private Integer pageNum;
    /**
     * 页数大小
     */
    private Integer pageSize;
    /**
     * 排序参数
     */
    private Integer sortParam;
    /**
     * 分组参数
     */
    private Integer groupParam;
    /**
     * 查询条件参数
     */
    private Integer typeParam;
    /**
     * 总条数
     */
    private Integer total;

    public List<Byte> getIsEnabledList() {
        return isEnabledList;
    }

    public void setIsEnabledList(List<Byte> isEnabledList) {
        this.isEnabledList = isEnabledList;
    }

    public String getSearchValueLike() {
        return searchValueLike;
    }

    public void setSearchValueLike(String searchValueLike) {
        this.searchValueLike = searchValueLike;
    }

    public String getTypeLike() {
        return typeLike;
    }

    public void setTypeLike(String typeLike) {
        this.typeLike = typeLike;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getSortParam() {
        return sortParam;
    }

    public void setSortParam(Integer sortParam) {
        this.sortParam = sortParam;
    }

    public Integer getGroupParam() {
        return groupParam;
    }

    public void setGroupParam(Integer groupParam) {
        this.groupParam = groupParam;
    }

    public Integer getTypeParam() {
        return typeParam;
    }

    public void setTypeParam(Integer typeParam) {
        this.typeParam = typeParam;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}
