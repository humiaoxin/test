package com.nxin.etposvr.dm.goods.dao.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @version 1.0
 * @Title goods_spec_attr表的实体类
 * @Description 商品规格属性表
 * @Author System
 * @Date 2019-09-19 16:49:25
 */
public class GoodsSpecAttrDmEntity {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields goodsId 商品ID
     */
    private Long goodsId;

    /**
     * @Fields goodsSpecId 商品规格ID
     */
    private Long goodsSpecId;

    /**
     * @Fields attrDefId 属性定义ID
     */
    private String attrDefId;

    /**
     * @Fields attrDefName 属性名
     */
    private String attrDefName;

    /**
     * @Fields attrValue 属性值
     */
    private String attrValue;

    /**
     * @Fields description 描述
     */
    private String description;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;
    /**
     * @Fields goodsSpecIdList 商品规格id集合
     */
    private List<Long> goodsSpecIdList;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:goods_spec_attr.id
     *
     * @return goods_spec_attr.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:goods_spec_attr.id
     *
     * @param id the value for goods_spec_attr.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 商品ID 字段:goods_spec_attr.goods_id
     *
     * @return goods_spec_attr.goods_id, 商品ID
     */
    public Long getGoodsId() {
        return goodsId;
    }

    /**
     * 设置 商品ID 字段:goods_spec_attr.goods_id
     *
     * @param goodsId the value for goods_spec_attr.goods_id, 商品ID
     */
    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    /**
     * 获取 商品规格ID 字段:goods_spec_attr.goods_spec_id
     *
     * @return goods_spec_attr.goods_spec_id, 商品规格ID
     */
    public Long getGoodsSpecId() {
        return goodsSpecId;
    }

    /**
     * 设置 商品规格ID 字段:goods_spec_attr.goods_spec_id
     *
     * @param goodsSpecId the value for goods_spec_attr.goods_spec_id, 商品规格ID
     */
    public void setGoodsSpecId(Long goodsSpecId) {
        this.goodsSpecId = goodsSpecId;
    }

    /**
     * 获取 属性定义ID 字段:goods_spec_attr.attr_def_id
     *
     * @return goods_spec_attr.attr_def_id, 属性定义ID
     */
    public String getAttrDefId() {
        return attrDefId;
    }

    /**
     * 设置 属性定义ID 字段:goods_spec_attr.attr_def_id
     *
     * @param attrDefId the value for goods_spec_attr.attr_def_id, 属性定义ID
     */
    public void setAttrDefId(String attrDefId) {
        this.attrDefId = attrDefId == null ? null : attrDefId.trim();
    }

    /**
     * 获取 属性名 字段:goods_spec_attr.attr_def_name
     *
     * @return goods_spec_attr.attr_def_name, 属性名
     */
    public String getAttrDefName() {
        return attrDefName;
    }

    /**
     * 设置 属性名 字段:goods_spec_attr.attr_def_name
     *
     * @param attrDefName the value for goods_spec_attr.attr_def_name, 属性名
     */
    public void setAttrDefName(String attrDefName) {
        this.attrDefName = attrDefName == null ? null : attrDefName.trim();
    }

    /**
     * 获取 属性值 字段:goods_spec_attr.attr_value
     *
     * @return goods_spec_attr.attr_value, 属性值
     */
    public String getAttrValue() {
        return attrValue;
    }

    /**
     * 设置 属性值 字段:goods_spec_attr.attr_value
     *
     * @param attrValue the value for goods_spec_attr.attr_value, 属性值
     */
    public void setAttrValue(String attrValue) {
        this.attrValue = attrValue == null ? null : attrValue.trim();
    }

    /**
     * 获取 描述 字段:goods_spec_attr.description
     *
     * @return goods_spec_attr.description, 描述
     */
    public String getDescription() {
        return description;
    }

    /**
     * 设置 描述 字段:goods_spec_attr.description
     *
     * @param description the value for goods_spec_attr.description, 描述
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * 获取 所属系统 字段:goods_spec_attr.system_id
     *
     * @return goods_spec_attr.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:goods_spec_attr.system_id
     *
     * @param systemId the value for goods_spec_attr.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:goods_spec_attr.data_remark
     *
     * @return goods_spec_attr.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:goods_spec_attr.data_remark
     *
     * @param dataRemark the value for goods_spec_attr.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:goods_spec_attr.create_time
     *
     * @return goods_spec_attr.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:goods_spec_attr.create_time
     *
     * @param createTime the value for goods_spec_attr.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:goods_spec_attr.version_remark
     *
     * @return goods_spec_attr.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:goods_spec_attr.version_remark
     *
     * @param versionRemark the value for goods_spec_attr.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号 字段:goods_spec_attr.vno
     *
     * @return goods_spec_attr.vno, 版本号
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号 字段:goods_spec_attr.vno
     *
     * @param vno the value for goods_spec_attr.vno, 版本号
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:goods_spec_attr.is_enabled
     *
     * @return goods_spec_attr.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:goods_spec_attr.is_enabled
     *
     * @param isEnabled the value for goods_spec_attr.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public List<Long> getGoodsSpecIdList() {
        return goodsSpecIdList;
    }

    public void setGoodsSpecIdList(List<Long> goodsSpecIdList) {
        this.goodsSpecIdList = goodsSpecIdList;
    }

    @Override
    public String toString() {
        return "GoodsSpecAttrDmEntity{" +
                "id=" + id +
                ", goodsId=" + goodsId +
                ", goodsSpecId=" + goodsSpecId +
                ", attrDefId='" + attrDefId + '\'' +
                ", attrDefName='" + attrDefName + '\'' +
                ", attrValue='" + attrValue + '\'' +
                ", description='" + description + '\'' +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                ", goodsSpecIdList=" + goodsSpecIdList +
                '}';
    }
}