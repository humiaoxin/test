package com.nxin.etposvr.dm.statement.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * 对账单reqForm
 * @Author lpp
 * @Date 2019/5/20 18:09
 * @Version 1.0
 */
public class StatementReqForm extends WebPageParam {

    private Long boIdOut;

    private Long boIdIn;

    private Byte systemId;

    /**
     * 收款方户名
     */
    private String realNameLike;

    /**
     * 开始日期
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /** 付款方名称 */
    private String userOutNameLike;
    /** 交易单号 */
    private Long tradeId;
    /** 结算单号 */
    private Long settlementInfoId;
    /** 结算状态 */
    private String paymentStatus;
    /** 结算开始时间 */
    private Date settlementStartTime;
    /** 结算结束时间 */
    private Date settlementEndTime;
    /** 支付流水号 */
    private Long bizId;
    /** 支付方式 */
    private String paymentCode;
    /** 支付起始时间 */
    private Date paymentStartDate;
    /** 支付结束时间 */
    private Date paymentEndDate;


    public Long getBoIdIn() {
        return boIdIn;
    }

    public void setBoIdIn(Long boIdIn) {
        this.boIdIn = boIdIn;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getBoIdOut() {
        return boIdOut;
    }

    public void setBoIdOut(Long boIdOut) {
        this.boIdOut = boIdOut;
    }

    public String getRealNameLike() {
        return realNameLike;
    }

    public void setRealNameLike(String realNameLike) {
        this.realNameLike = realNameLike;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getUserOutNameLike() {
        return userOutNameLike;
    }

    public void setUserOutNameLike(String userOutNameLike) {
        this.userOutNameLike = userOutNameLike;
    }

    public Long getTradeId() {
        return tradeId;
    }

    public void setTradeId(Long tradeId) {
        this.tradeId = tradeId;
    }

    public Long getSettlementInfoId() {
        return settlementInfoId;
    }

    public void setSettlementInfoId(Long settlementInfoId) {
        this.settlementInfoId = settlementInfoId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Date getSettlementStartTime() {
        return settlementStartTime;
    }

    public void setSettlementStartTime(Date settlementStartTime) {
        this.settlementStartTime = settlementStartTime;
    }

    public Date getSettlementEndTime() {
        return settlementEndTime;
    }

    public void setSettlementEndTime(Date settlementEndTime) {
        this.settlementEndTime = settlementEndTime;
    }

    public Long getBizId() {
        return bizId;
    }

    public void setBizId(Long bizId) {
        this.bizId = bizId;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }

    public Date getPaymentStartDate() {
        return paymentStartDate;
    }

    public void setPaymentStartDate(Date paymentStartDate) {
        this.paymentStartDate = paymentStartDate;
    }

    public Date getPaymentEndDate() {
        return paymentEndDate;
    }

    public void setPaymentEndDate(Date paymentEndDate) {
        this.paymentEndDate = paymentEndDate;
    }
}
