package com.nxin.etposvr.dm.order.dao.model;

import java.util.List;

/**
 * 订单流动返回实体
 *
 * @author ZhangXu
 * @since 2020.4.15
 */
public class OrderFlowDmEntity {

    private Long categoryId;
    private List<OrderInfoDmEntity> orderInfoDmEntityList;

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public List<OrderInfoDmEntity> getOrderInfoDmEntityList() {
        return orderInfoDmEntityList;
    }

    public void setOrderInfoDmEntityList(List<OrderInfoDmEntity> orderInfoDmEntityList) {
        this.orderInfoDmEntityList = orderInfoDmEntityList;
    }
}
