package com.nxin.etposvr.dmp.stat.controller.res;

import com.nxin.etposvr.dmp.stat.dao.model.StatIndicateDef;

/**
 * 指标定义
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:03
 * @version: v_1.0.1
 */
public class StatIndicateDefResForm extends StatIndicateDef {
}
