package com.nxin.etposvr.dm.statement.res;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhaoshuai
 * @version v_1.0.1
 * @since 2019/7/17 18:01
 */
public class StatementPCSellerResForm {

    /**
     * 订单编号
     */
    private Long orderId;

    /**
     * 到账时间
     */
    private Date balanceTime;

    /**
     * 支付方式
     */
    private String paymentType;

    /**
     * 付款方/收款方户名
     */
    private String realName;

    /**
     * 实付货款金额
     */
    private BigDecimal paidGoodsMoney;

    /**
     * 预估货款金额
     */
    private BigDecimal goodsOrigMoney;

    /**
     * 商品金额
     */
    private BigDecimal goodsDealMoney;

    /**
     * 卖家服务费
     */
    private BigDecimal sellerServiceFee;

    /**
     * 保险费
     */
    private BigDecimal insuranceMoney;

    /**
     * 单价
     */
    private BigDecimal sellPrice;

    /**
     * 下单数
     */
    private BigDecimal finalGoodsNum;

    /**
     * 总量
     */
    private BigDecimal finalNum;

    /**
     * 品类
     */
    private String categoryName;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public BigDecimal getPaidGoodsMoney() {
        return paidGoodsMoney;
    }

    public void setPaidGoodsMoney(BigDecimal paidGoodsMoney) {
        this.paidGoodsMoney = paidGoodsMoney;
    }

    public BigDecimal getGoodsOrigMoney() {
        return goodsOrigMoney;
    }

    public void setGoodsOrigMoney(BigDecimal goodsOrigMoney) {
        this.goodsOrigMoney = goodsOrigMoney;
    }

    public BigDecimal getGoodsDealMoney() {
        return goodsDealMoney;
    }

    public void setGoodsDealMoney(BigDecimal goodsDealMoney) {
        this.goodsDealMoney = goodsDealMoney;
    }

    public BigDecimal getInsuranceMoney() {
        return insuranceMoney;
    }

    public void setInsuranceMoney(BigDecimal insuranceMoney) {
        this.insuranceMoney = insuranceMoney;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getFinalGoodsNum() {
        return finalGoodsNum;
    }

    public void setFinalGoodsNum(BigDecimal finalGoodsNum) {
        this.finalGoodsNum = finalGoodsNum;
    }

    public BigDecimal getFinalNum() {
        return finalNum;
    }

    public void setFinalNum(BigDecimal finalNum) {
        this.finalNum = finalNum;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Date getBalanceTime() {
        return balanceTime;
    }

    public void setBalanceTime(Date balanceTime) {
        this.balanceTime = balanceTime;
    }

    public BigDecimal getSellerServiceFee() {
        return sellerServiceFee;
    }

    public void setSellerServiceFee(BigDecimal sellerServiceFee) {
        this.sellerServiceFee = sellerServiceFee;
    }

    @Override
    public String toString() {
        return "StatementPCSellerResForm{" +
                "orderId=" + orderId +
                ", balanceTime=" + balanceTime +
                ", paymentType='" + paymentType + '\'' +
                ", realName='" + realName + '\'' +
                ", paidGoodsMoney=" + paidGoodsMoney +
                ", goodsOrigMoney=" + goodsOrigMoney +
                ", goodsDealMoney=" + goodsDealMoney +
                ", sellerServiceFee=" + sellerServiceFee +
                ", insuranceMoney=" + insuranceMoney +
                ", sellPrice=" + sellPrice +
                ", finalGoodsNum=" + finalGoodsNum +
                ", finalNum=" + finalNum +
                ", categoryName='" + categoryName + '\'' +
                '}';
    }
}
