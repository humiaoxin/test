package com.nxin.etposvr.dm.manage.dao.model;

import com.nxin.etposvr.dm.base.dao.model.BaseInfoDmEntity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 场实体
 * @author TianShiWei
 * @since:  2019/10/30 9:54
 * @version: v_1.0.1
 */
public class ManageManufacturerDmEntity{

    private String accordingType;

    private Integer range;

    private String dates;

    private Integer count;

    private Byte systemId;

    private String id;

    private String name;

    private Integer areaId;

    private Long manuId;

    private String areaFullName;

    private String addr;

    private String linkman;

    private String tel;

    private String longitude;

    private String latitude;

    private Integer pageNum;

    private Integer pageSize;

    private Date startTime;

    private Date endTime;

    private List<String > baseInfoNameList;

    private BigDecimal baseInfoSize;

    private List<BaseInfoDmEntity> baseInfoDmEntityList;


    private String areaAxisLike;

    private List<Date> dateList;

    private String startTimeStr;

    private String endTimeStr;

    private Long infoId;

    private String categoryName;

    private String categoryPcateName;


    public String getCategoryPcateName() {
        return categoryPcateName;
    }

    public void setCategoryPcateName(String categoryPcateName) {
        this.categoryPcateName = categoryPcateName;
    }

    public Long getInfoId() {
        return infoId;
    }

    public void setInfoId(Long infoId) {
        this.infoId = infoId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getStartTimeStr() {
        return startTimeStr;
    }

    public void setStartTimeStr(String startTimeStr) {
        this.startTimeStr = startTimeStr;
    }

    public String getEndTimeStr() {
        return endTimeStr;
    }

    public void setEndTimeStr(String endTimeStr) {
        this.endTimeStr = endTimeStr;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public List<Date> getDateList() {
        return dateList;
    }

    public void setDateList(List<Date> dateList) {
        this.dateList = dateList;
    }

    public List<String> getBaseInfoNameList() {
        return baseInfoNameList;
    }

    public void setBaseInfoNameList(List<String> baseInfoNameList) {
        this.baseInfoNameList = baseInfoNameList;
    }

    public BigDecimal getBaseInfoSize() {
        return baseInfoSize;
    }

    public void setBaseInfoSize(BigDecimal baseInfoSize) {
        this.baseInfoSize = baseInfoSize;
    }

    public List<BaseInfoDmEntity> getBaseInfoDmEntityList() {
        return baseInfoDmEntityList;
    }

    public void setBaseInfoDmEntityList(List<BaseInfoDmEntity> baseInfoDmEntityList) {
        this.baseInfoDmEntityList = baseInfoDmEntityList;
    }

    public String getAccordingType() {
        return accordingType;
    }

    public void setAccordingType(String accordingType) {
        this.accordingType = accordingType;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }
}