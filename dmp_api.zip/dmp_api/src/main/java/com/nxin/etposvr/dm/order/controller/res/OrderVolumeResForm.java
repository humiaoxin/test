package com.nxin.etposvr.dm.order.controller.res;

import com.nxin.etposvr.dm.order.dao.model.OrderVolume;

import java.util.List;

/**
 * 成交量返回实体
 * @author ZhangXu
 * @since 2019.10.24
 */
public class OrderVolumeResForm {

    private String dates;
    private List<OrderVolume> orderVolumes;

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public List<OrderVolume> getOrderVolumes() {
        return orderVolumes;
    }

    public void setOrderVolumes(List<OrderVolume> orderVolumes) {
        this.orderVolumes = orderVolumes;
    }
}
