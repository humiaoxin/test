package com.nxin.etposvr.dm.elasticsearch.controller.res;

import com.nxin.etposvr.dm.elasticsearch.dao.model.GoodsEsEntity;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2018/11/8 13:43
 */
public class GoodsEsResForm extends GoodsEsEntity {


}
