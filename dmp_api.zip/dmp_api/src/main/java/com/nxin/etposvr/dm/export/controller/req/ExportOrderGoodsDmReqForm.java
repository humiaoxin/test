package com.nxin.etposvr.dm.export.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 导出订单商品入参
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2019/11/6 14:28
 */
public class ExportOrderGoodsDmReqForm extends WebPageParam {

    /**
     * 销售店铺卖家
     */
    private Long sellerBoId;

    /**
     * 系统id
     */
    private Byte systemId;

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
