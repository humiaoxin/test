package com.nxin.etposvr.dmp.satelite.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Title satelite_hdf_dtl表的实体类
 * @Description 卫星数据明细表
 * @version 1.0
 * @Author System
 * @Date 2020-06-03 09:57:34
 */
public class SateliteHdfDtl implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields hdfId 数据文件ID
     */
    private Long hdfId;

    /**
     * @Fields longtitude 经度
     */
    private String longtitude;

    /**
     * @Fields latitude 纬度
     */
    private String latitude;

    /**
     * @Fields lonlatHash 经纬度HASH
     */
    private String lonlatHash;

    /**
     * @Fields val 数值
     */
    private BigDecimal val;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    /**
     * @Fields isChina 是否中国
     */
    private Boolean isChina;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:satelite_hdf_dtl.id
     *
     * @return satelite_hdf_dtl.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:satelite_hdf_dtl.id
     *
     * @param id the value for satelite_hdf_dtl.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 数据文件ID 字段:satelite_hdf_dtl.hdf_id
     *
     * @return satelite_hdf_dtl.hdf_id, 数据文件ID
     */
    public Long getHdfId() {
        return hdfId;
    }

    /**
     * 设置 数据文件ID 字段:satelite_hdf_dtl.hdf_id
     *
     * @param hdfId the value for satelite_hdf_dtl.hdf_id, 数据文件ID
     */
    public void setHdfId(Long hdfId) {
        this.hdfId = hdfId;
    }

    /**
     * 获取 经度 字段:satelite_hdf_dtl.longtitude
     *
     * @return satelite_hdf_dtl.longtitude, 经度
     */
    public String getLongtitude() {
        return longtitude;
    }

    /**
     * 设置 经度 字段:satelite_hdf_dtl.longtitude
     *
     * @param longtitude the value for satelite_hdf_dtl.longtitude, 经度
     */
    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude == null ? null : longtitude.trim();
    }

    /**
     * 获取 纬度 字段:satelite_hdf_dtl.latitude
     *
     * @return satelite_hdf_dtl.latitude, 纬度
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * 设置 纬度 字段:satelite_hdf_dtl.latitude
     *
     * @param latitude the value for satelite_hdf_dtl.latitude, 纬度
     */
    public void setLatitude(String latitude) {
        this.latitude = latitude == null ? null : latitude.trim();
    }

    /**
     * 获取 经纬度HASH 字段:satelite_hdf_dtl.lonlat_hash
     *
     * @return satelite_hdf_dtl.lonlat_hash, 经纬度HASH
     */
    public String getLonlatHash() {
        return lonlatHash;
    }

    /**
     * 设置 经纬度HASH 字段:satelite_hdf_dtl.lonlat_hash
     *
     * @param lonlatHash the value for satelite_hdf_dtl.lonlat_hash, 经纬度HASH
     */
    public void setLonlatHash(String lonlatHash) {
        this.lonlatHash = lonlatHash == null ? null : lonlatHash.trim();
    }

    /**
     * 获取 数值 字段:satelite_hdf_dtl.val
     *
     * @return satelite_hdf_dtl.val, 数值
     */
    public BigDecimal getVal() {
        return val;
    }

    /**
     * 设置 数值 字段:satelite_hdf_dtl.val
     *
     * @param val the value for satelite_hdf_dtl.val, 数值
     */
    public void setVal(BigDecimal val) {
        this.val = val;
    }

    /**
     * 获取 所属系统 字段:satelite_hdf_dtl.system_id
     *
     * @return satelite_hdf_dtl.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:satelite_hdf_dtl.system_id
     *
     * @param systemId the value for satelite_hdf_dtl.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:satelite_hdf_dtl.data_remark
     *
     * @return satelite_hdf_dtl.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:satelite_hdf_dtl.data_remark
     *
     * @param dataRemark the value for satelite_hdf_dtl.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:satelite_hdf_dtl.create_time
     *
     * @return satelite_hdf_dtl.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:satelite_hdf_dtl.create_time
     *
     * @param createTime the value for satelite_hdf_dtl.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:satelite_hdf_dtl.version_remark
     *
     * @return satelite_hdf_dtl.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:satelite_hdf_dtl.version_remark
     *
     * @param versionRemark the value for satelite_hdf_dtl.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:satelite_hdf_dtl.vno
     *
     * @return satelite_hdf_dtl.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:satelite_hdf_dtl.vno
     *
     * @param vno the value for satelite_hdf_dtl.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:satelite_hdf_dtl.is_enabled
     *
     * @return satelite_hdf_dtl.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:satelite_hdf_dtl.is_enabled
     *
     * @param isEnabled the value for satelite_hdf_dtl.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * 获取 是否中国 字段:satelite_hdf_dtl.is_china
     *
     * @return satelite_hdf_dtl.is_china, 是否中国
     */
    public Boolean getIsChina() {
        return isChina;
    }

    /**
     * 设置 是否中国 字段:satelite_hdf_dtl.is_china
     *
     * @param isChina the value for satelite_hdf_dtl.is_china, 是否中国
     */
    public void setIsChina(Boolean isChina) {
        this.isChina = isChina;
    }

    /**
     * :satelite_hdf_dtl
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", hdfId=").append(hdfId);
        sb.append(", longtitude=").append(longtitude);
        sb.append(", latitude=").append(latitude);
        sb.append(", lonlatHash=").append(lonlatHash);
        sb.append(", val=").append(val);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", isChina=").append(isChina);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :satelite_hdf_dtl
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SateliteHdfDtl other = (SateliteHdfDtl) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getHdfId() == null ? other.getHdfId() == null : this.getHdfId().equals(other.getHdfId()))
            && (this.getLongtitude() == null ? other.getLongtitude() == null : this.getLongtitude().equals(other.getLongtitude()))
            && (this.getLatitude() == null ? other.getLatitude() == null : this.getLatitude().equals(other.getLatitude()))
            && (this.getLonlatHash() == null ? other.getLonlatHash() == null : this.getLonlatHash().equals(other.getLonlatHash()))
            && (this.getVal() == null ? other.getVal() == null : this.getVal().equals(other.getVal()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()))
            && (this.getIsChina() == null ? other.getIsChina() == null : this.getIsChina().equals(other.getIsChina()));
    }

    /**
     * :satelite_hdf_dtl
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getHdfId() == null) ? 0 : getHdfId().hashCode());
        result = prime * result + ((getLongtitude() == null) ? 0 : getLongtitude().hashCode());
        result = prime * result + ((getLatitude() == null) ? 0 : getLatitude().hashCode());
        result = prime * result + ((getLonlatHash() == null) ? 0 : getLonlatHash().hashCode());
        result = prime * result + ((getVal() == null) ? 0 : getVal().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        result = prime * result + ((getIsChina() == null) ? 0 : getIsChina().hashCode());
        return result;
    }
}