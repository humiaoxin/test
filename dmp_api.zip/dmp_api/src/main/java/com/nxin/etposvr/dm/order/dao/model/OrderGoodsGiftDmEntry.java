package com.nxin.etposvr.dm.order.dao.model;

public class OrderGoodsGiftDmEntry {
    /** 订单id */
    private Long orderId;
    /** 赠品商品id */
    private Long goodsId;
    /** 订单赠品商品id */
    private Long orderGoodsId;
    /** 赠品商品名称 */
    private String goodsName;
    /** 赠品商品数量 */
    private Integer goodsNum;
    /** 赠品商品规格id */
    private Long goodsSpecId;
    /** 商品规格名称 */
    private String stockUnitTxt;
    //赠品商品图片
    private String giftGoodsImg;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Long getOrderGoodsId() {
        return orderGoodsId;
    }

    public void setOrderGoodsId(Long orderGoodsId) {
        this.orderGoodsId = orderGoodsId;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Integer getGoodsNum() {
        return goodsNum;
    }

    public void setGoodsNum(Integer goodsNum) {
        this.goodsNum = goodsNum;
    }

    public Long getGoodsSpecId() {
        return goodsSpecId;
    }

    public void setGoodsSpecId(Long goodsSpecId) {
        this.goodsSpecId = goodsSpecId;
    }

    public String getStockUnitTxt() {
        return stockUnitTxt;
    }

    public void setStockUnitTxt(String stockUnitTxt) {
        this.stockUnitTxt = stockUnitTxt;
    }

    public String getGiftGoodsImg() {
        return giftGoodsImg;
    }

    public void setGiftGoodsImg(String giftGoodsImg) {
        this.giftGoodsImg = giftGoodsImg;
    }
}
