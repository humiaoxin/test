package com.nxin.etposvr.dm.order.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup1th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

public class OrderInfoDmReqForm extends WebPageParam {

    /**
     * 服务人员编号
     */
    @ApiModelProperty(value = "服务人员编号", example = "110119011415270001", dataType = "Long")
    @NotNull(message = "000001|服务人员编号", groups = {VldGroup1th.class})
    private Long boId;

    private List<Long> boIdList;

    /**
     * 查询开始时间
     */
    private Date startTime;
    /**
     * 查询结束时间
     */
    private Date endTime;
    /**
     * 支付状态
     */
    private String paymentStatus;
    /**
     * 发货状态
     */
    private String sendStatus;
    /**
     * 收货状态
     */
    private String receiveStatus;
    /**
     * 结算状态
     */
    private String balanceStatus;
    /**
     * 退货状态
     */
    private String returnGoodsStatus;
    /**
     * 退款状态
     */
    private String refundsStatus;

    private String paymentStatusNot;

    private String sendStatusNot;

    private String receiveStatusNot;

    private String balanceStatusNot;

    private String returnGoodsStatusNot;

    private String refundsStatusNot;

    //店铺名称
    private String shopName;
    //卖家名称
    private String linkMan;
    //收货人
    private String personName;
    //收货人电话
    private String tel;

    private Long id;

    private String type;

    private String payment;

    private String  areaAxisLike;

    /**
     * @Fields buyerBoId 买家用户ID
     */
    private Long buyerBoId;

    /**
     * @Fields sellerBoId 卖家用户ID
     */
    private Long sellerBoId;
    //可用标识
    private Byte isEnabled;

    //订单类型集合
    private List<String> typesList;

    /**
     * @Fields buyerFeedback 买家是否已评价
     */
    private Byte buyerFeedback;

    /**
     * @Fields sellerFeedback 卖家是否已评价
     */
    private Byte sellerFeedback;

    /**
     * 下单开始时间
     */
    private String startOrderTimeStr;
    /**
     * 下单截至时间
     */
    private String endOrderTimeStr;

    /**
     * 结算/成交开始时间
     */
    private String startBalanceTimeStr;
    /**
     * 结算/成交截至时间
     */
    private String endBalanceTimeStr;

    /**
     * @Fields realName 姓名/企业名称
     */
    private String realName;

    /**
     * @Fields mobilePhone 买家手机号码
     */
    private String mobilePhone;

    /**
     * @Fields shopPhone 卖家手机号码
     */
    private String shopPhone;

    //买家隐藏
    private Byte buyerHide;
    //卖家隐藏
    private Byte sellerHide;
    /**
     * @Fields 商品名称
     */
    private String goodsNameLike;

    /**
     * @Fields 卖家名称
     */
    private String sellerName;

    /**
     * @Fields saleType 销售类型
     */
    private String saleType;

    /**
     * @Fields landCirculationStatus 土地流转状态
     */
    private String landCirculationStatus;

    /**
     * @Fields serviceDemandStatus 服务需求状态
     */
    private String serviceDemandStatus;
    /**
     * @Fields serviceDemandStatus 服务需求状态集合
     */
    private List<String> serviceStatusList;

    //订单销售类型集合
    private List<String> saleTypeList;
    /**
     * @Fields traceNo 溯源编码
     */
    private String traceNo;

    /**
     * 卖家电话/供应方电话
     */
    private String sellerTel;

    public String getSellerTel() {
        return sellerTel;
    }

    public void setSellerTel(String sellerTel) {
        this.sellerTel = sellerTel;
    }

    public String getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo;
    }

    public List<String> getSaleTypeList() {
        return saleTypeList;
    }

    public void setSaleTypeList(List<String> saleTypeList) {
        this.saleTypeList = saleTypeList;
    }

    public List<String> getServiceStatusList() {
        return serviceStatusList;
    }

    public void setServiceStatusList(List<String> serviceStatusList) {
        this.serviceStatusList = serviceStatusList;
    }

    public String getLandCirculationStatus() {
        return landCirculationStatus;
    }

    public void setLandCirculationStatus(String landCirculationStatus) {
        this.landCirculationStatus = landCirculationStatus;
    }

    public String getServiceDemandStatus() {
        return serviceDemandStatus;
    }

    public void setServiceDemandStatus(String serviceDemandStatus) {
        this.serviceDemandStatus = serviceDemandStatus;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getGoodsNameLike() {
        return goodsNameLike;
    }

    public void setGoodsNameLike(String goodsNameLike) {
        this.goodsNameLike = goodsNameLike;
    }
    public String getSellerName() {
        return sellerName;
    }
    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public Byte getBuyerHide() {
        return buyerHide;
    }

    public void setBuyerHide(Byte buyerHide) {
        this.buyerHide = buyerHide;
    }

    public Byte getSellerHide() {
        return sellerHide;
    }

    public void setSellerHide(Byte sellerHide) {
        this.sellerHide = sellerHide;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getShopPhone() {
        return shopPhone;
    }

    public void setShopPhone(String shopPhone) {
        this.shopPhone = shopPhone;
    }

    public String getStartBalanceTimeStr() {
        return startBalanceTimeStr;
    }

    public void setStartBalanceTimeStr(String startBalanceTimeStr) {
        this.startBalanceTimeStr = startBalanceTimeStr;
    }

    public String getEndBalanceTimeStr() {
        return endBalanceTimeStr;
    }

    public void setEndBalanceTimeStr(String endBalanceTimeStr) {
        this.endBalanceTimeStr = endBalanceTimeStr;
    }

    public String getStartOrderTimeStr() {
        return startOrderTimeStr;
    }

    public void setStartOrderTimeStr(String startOrderTimeStr) {
        this.startOrderTimeStr = startOrderTimeStr;
    }

    public String getEndOrderTimeStr() {
        return endOrderTimeStr;
    }

    public void setEndOrderTimeStr(String endOrderTimeStr) {
        this.endOrderTimeStr = endOrderTimeStr;
    }

    public Byte getBuyerFeedback() {
        return buyerFeedback;
    }

    public void setBuyerFeedback(Byte buyerFeedback) {
        this.buyerFeedback = buyerFeedback;
    }

    public Byte getSellerFeedback() {
        return sellerFeedback;
    }

    public void setSellerFeedback(Byte sellerFeedback) {
        this.sellerFeedback = sellerFeedback;
    }

    public List<String> getTypesList() {
        return typesList;
    }

    public void setTypesList(List<String> typesList) {
        this.typesList = typesList;
    }


    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Long getBuyerBoId() {
        return buyerBoId;
    }

    public void setBuyerBoId(Long buyerBoId) {
        this.buyerBoId = buyerBoId;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus;
    }

    public String getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(String receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public String getBalanceStatus() {
        return balanceStatus;
    }

    public void setBalanceStatus(String balanceStatus) {
        this.balanceStatus = balanceStatus;
    }

    public String getReturnGoodsStatus() {
        return returnGoodsStatus;
    }

    public void setReturnGoodsStatus(String returnGoodsStatus) {
        this.returnGoodsStatus = returnGoodsStatus;
    }

    public String getRefundsStatus() {
        return refundsStatus;
    }

    public void setRefundsStatus(String refundsStatus) {
        this.refundsStatus = refundsStatus;
    }

    public String getPaymentStatusNot() {
        return paymentStatusNot;
    }

    public void setPaymentStatusNot(String paymentStatusNot) {
        this.paymentStatusNot = paymentStatusNot;
    }

    public String getSendStatusNot() {
        return sendStatusNot;
    }

    public void setSendStatusNot(String sendStatusNot) {
        this.sendStatusNot = sendStatusNot;
    }

    public String getReceiveStatusNot() {
        return receiveStatusNot;
    }

    public void setReceiveStatusNot(String receiveStatusNot) {
        this.receiveStatusNot = receiveStatusNot;
    }

    public String getBalanceStatusNot() {
        return balanceStatusNot;
    }

    public void setBalanceStatusNot(String balanceStatusNot) {
        this.balanceStatusNot = balanceStatusNot;
    }

    public String getReturnGoodsStatusNot() {
        return returnGoodsStatusNot;
    }

    public void setReturnGoodsStatusNot(String returnGoodsStatusNot) {
        this.returnGoodsStatusNot = returnGoodsStatusNot;
    }

    public String getRefundsStatusNot() {
        return refundsStatusNot;
    }

    public void setRefundsStatusNot(String refundsStatusNot) {
        this.refundsStatusNot = refundsStatusNot;
    }

    @Override
    public String toString() {
        return "OrderInfoDmReqForm{" +
                "boId=" + boId +
                ", boIdList=" + boIdList +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", sendStatus='" + sendStatus + '\'' +
                ", receiveStatus='" + receiveStatus + '\'' +
                ", balanceStatus='" + balanceStatus + '\'' +
                ", returnGoodsStatus='" + returnGoodsStatus + '\'' +
                ", refundsStatus='" + refundsStatus + '\'' +
                ", paymentStatusNot='" + paymentStatusNot + '\'' +
                ", sendStatusNot='" + sendStatusNot + '\'' +
                ", receiveStatusNot='" + receiveStatusNot + '\'' +
                ", balanceStatusNot='" + balanceStatusNot + '\'' +
                ", returnGoodsStatusNot='" + returnGoodsStatusNot + '\'' +
                ", refundsStatusNot='" + refundsStatusNot + '\'' +
                ", shopName='" + shopName + '\'' +
                ", linkMan='" + linkMan + '\'' +
                ", personName='" + personName + '\'' +
                ", tel='" + tel + '\'' +
                ", id=" + id +
                ", type='" + type + '\'' +
                ", payment='" + payment + '\'' +
                ", areaAxisLike='" + areaAxisLike + '\'' +
                ", buyerBoId=" + buyerBoId +
                ", sellerBoId=" + sellerBoId +
                ", isEnabled=" + isEnabled +
                ", typesList=" + typesList +
                ", buyerFeedback=" + buyerFeedback +
                ", sellerFeedback=" + sellerFeedback +
                ", startOrderTimeStr='" + startOrderTimeStr + '\'' +
                ", endOrderTimeStr='" + endOrderTimeStr + '\'' +
                ", startBalanceTimeStr='" + startBalanceTimeStr + '\'' +
                ", endBalanceTimeStr='" + endBalanceTimeStr + '\'' +
                ", realName='" + realName + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", shopPhone='" + shopPhone + '\'' +
                '}';
    }
}
