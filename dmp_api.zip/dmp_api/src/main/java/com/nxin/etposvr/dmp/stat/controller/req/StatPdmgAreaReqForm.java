package com.nxin.etposvr.dmp.stat.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * 按地区管理
 *
 * @author TianShiWei
 * @since:  2020/5/23 14:10
 * @version: v_1.0.1
 */
public class StatPdmgAreaReqForm extends WebPageParam {

    /**
     * @Fields id id
     */
    private Long id;

    /**
     * @Fields areaId 地区ID
     */
    private Long areaId;

    /**
     * @Fields areaAxis 地区串
     */
    private String areaAxis;

    /**
     * @Fields areaName 地区名称
     */
    private String areaName;

    /**
     * @Fields dataDate 数据日期
     */
    private String dataDate;

    /**
     * @Fields dataYearMonth 数据年月
     */
    private String dataYearMonth;

    /**
     * @Fields dataYear 数据年份
     */
    private String dataYear;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getDataDate() {
        return dataDate;
    }

    public void setDataDate(String dataDate) {
        this.dataDate = dataDate;
    }

    public String getDataYearMonth() {
        return dataYearMonth;
    }

    public void setDataYearMonth(String dataYearMonth) {
        this.dataYearMonth = dataYearMonth;
    }

    public String getDataYear() {
        return dataYear;
    }

    public void setDataYear(String dataYear) {
        this.dataYear = dataYear;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }
}
