package com.nxin.etposvr.dm.shop.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class ShopInfoDmEntity {

    public String id;

    public String name;

    private Byte systemId;

    public String busiScopeCode;

    public String oneAreaId;

    public String twoAreaId;

    public String areaId;

    private String areaAxis;

    private String areaFullName;

    private String busiScopeName;

    private String shopName;

    private String logo;

    private int goodsCount;

    public String tel;

    public String linkman;

    public String userType;

    public String authSign;
    /**
     * @Fields addr 地址
     */
    private String addr;

    /**
     * 高德返回经纬度
     */
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getAuthSign() {
        return authSign;
    }

    public void setAuthSign(String authSign) {
        this.authSign = authSign;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman;
    }

    /**
     * 客户boId集合
     */
    public List<Long> boIdList;

    /**
     * 第几页
     */
    private Integer pageNum;
    /**
     * 条数
     */
    private Integer pageSize;

    /**占比*/
    private BigDecimal percent;

    /**范围(天数)*/
    private Integer range;

    /**店铺数量*/
    private Integer num;
    /**日期*/
    private String dates;
    /**店铺数量*/
    private Integer count;
    /**经度*/
    private BigDecimal lon;
    /**纬度*/
    private BigDecimal lat;
    /**店铺ID*/
    private Long shopId;
    /**开始时间*/
    private String startTimeStr;
    /**结束时间*/
    private String endTimeStr;
    /**
     * 统计类型DAY-按日统计MON-按月统计YEAR-按年统计
     */
    private String statType;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 日期类型
     */
    private String pattern;
    /**
     * 截止查询时间
     */
    private String limitDate;
    /**
     * 状态集合
     */
    private List<String> statusList;

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public String getLimitDate() {
        return limitDate;
    }

    public void setLimitDate(String limitDate) {
        this.limitDate = limitDate;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getStartTimeStr() {
        return startTimeStr;
    }

    public void setStartTimeStr(String startTimeStr) {
        this.startTimeStr = startTimeStr;
    }

    public String getEndTimeStr() {
        return endTimeStr;
    }

    public void setEndTimeStr(String endTimeStr) {
        this.endTimeStr = endTimeStr;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public BigDecimal getLon() {
        return lon;
    }

    public void setLon(BigDecimal lon) {
        this.lon = lon;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public BigDecimal getPercent() {
        return percent;
    }

    public void setPercent(BigDecimal percent) {
        this.percent = percent;
    }

    public String getAreaAxis() {
        return areaAxis;
    }

    public void setAreaAxis(String areaAxis) {
        this.areaAxis = areaAxis;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getBusiScopeName() {
        return busiScopeName;
    }

    public void setBusiScopeName(String busiScopeName) {
        this.busiScopeName = busiScopeName;
    }

    public String getBusiScopeCode() {
        return busiScopeCode;
    }

    public void setBusiScopeCode(String busiScopeCode) {
        this.busiScopeCode = busiScopeCode;
    }

    public String getOneAreaId() {
        return oneAreaId;
    }

    public void setOneAreaId(String oneAreaId) {
        this.oneAreaId = oneAreaId;
    }

    public String getTwoAreaId() {
        return twoAreaId;
    }

    public void setTwoAreaId(String twoAreaId) {
        this.twoAreaId = twoAreaId;
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public int getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(int goodsCount) {
        this.goodsCount = goodsCount;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "ShopInfoDmEntity{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", systemId='" + systemId + '\'' +
                ", busiScopeCode='" + busiScopeCode + '\'' +
                ", oneAreaId='" + oneAreaId + '\'' +
                ", twoAreaId='" + twoAreaId + '\'' +
                ", areaId='" + areaId + '\'' +
                ", areaAxis='" + areaAxis + '\'' +
                ", areaFullName='" + areaFullName + '\'' +
                ", busiScopeName='" + busiScopeName + '\'' +
                ", shopName='" + shopName + '\'' +
                ", logo='" + logo + '\'' +
                ", goodsCount=" + goodsCount +
                ", tel='" + tel + '\'' +
                ", linkman='" + linkman + '\'' +
                ", userType='" + userType + '\'' +
                ", authSign='" + authSign + '\'' +
                ", boIdList=" + boIdList +
                ", pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", percent=" + percent +
                ", range=" + range +
                ", num=" + num +
                ", dates='" + dates + '\'' +
                ", count=" + count +
                ", addrLon=" + lon +
                ", addrLat=" + lat +
                ", shopId=" + shopId +
                ", startTimeStr='" + startTimeStr + '\'' +
                ", endTimeStr='" + endTimeStr + '\'' +
                ", statType='" + statType + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", pattern='" + pattern + '\'' +
                ", limitDate='" + limitDate + '\'' +
                '}';
    }
}
