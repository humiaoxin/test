package com.nxin.etposvr.dm.commission.dao.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * 返佣-打款
 */
public class CommissionManageDmEntity {

    //登录名
    private String loginName;
    //姓名
    private String userName;
    //手机号
    private String tel;
    //所在地
    private String addr;
    //推广状态
    private String status;
    //推广状态-中文
    private String statusCn;
    //月佣金
    private BigDecimal monthMoney;
    //结算状态
    private String blanceStatus;
    //结算状态-中文
    private String blanceStatusCn;
    //返拥用户Id
    private Long boId;
    //日期
    private String dateTime;
    //卡号
    private String cardNo;

    private String realName;

    private String dailyPerson;


    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getDailyPerson() {
        return dailyPerson;
    }

    public void setDailyPerson(String dailyPerson) {
        this.dailyPerson = dailyPerson;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getDateTime() {
        return dateTime;
    }
    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCn() {
        return statusCn;
    }

    public void setStatusCn(String statusCn) {
        this.statusCn = statusCn;
    }

    public BigDecimal getMonthMoney() {
        return monthMoney;
    }

    public void setMonthMoney(BigDecimal monthMoney) {
        this.monthMoney = monthMoney;
    }

    public String getBlanceStatus() {
        return blanceStatus;
    }

    public void setBlanceStatus(String blanceStatus) {
        this.blanceStatus = blanceStatus;
    }

    public String getBlanceStatusCn() {
        return blanceStatusCn;
    }

    public void setBlanceStatusCn(String blanceStatusCn) {
        this.blanceStatusCn = blanceStatusCn;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }
}
