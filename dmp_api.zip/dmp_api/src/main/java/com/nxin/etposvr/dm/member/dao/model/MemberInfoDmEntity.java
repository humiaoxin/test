package com.nxin.etposvr.dm.member.dao.model;


import java.util.Date;
import java.util.List;

/**
 * @author ZhuPengFei
 * @explain
 * @since 2018/8/13 14:44
 */
public class MemberInfoDmEntity {

    private Long boId;

    private Long oprBoId;

    private String userType;

    private String userName;

    private String realName;

    private String mobilePhone;

    private String headIcon;

    private Integer areaId;

    private String addr;

    private Byte systemId;

    /**
     * 性别
     */
    private String gender;
    /**
     * 地区全称
     */
    private String areaFullName;

    /**
     * 企业名称
     */
    private String orgName;

    private List<ManageManufacturerDmEntity> manuFacturerList;

    private int goodsCount;


    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getHeadIcon() {
        return headIcon;
    }

    public void setHeadIcon(String headIcon) {
        this.headIcon = headIcon;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAreaFullName() {
        return areaFullName;
    }

    public void setAreaFullName(String areaFullName) {
        this.areaFullName = areaFullName;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public List<ManageManufacturerDmEntity> getManuFacturerList() {
        return manuFacturerList;
    }

    public void setManuFacturerList(List<ManageManufacturerDmEntity> manuFacturerList) {
        this.manuFacturerList = manuFacturerList;
    }

    public int getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(int goodsCount) {
        this.goodsCount = goodsCount;
    }

    @Override
    public String toString() {
        return "MemberInfoDmEntity{" +
                "boId=" + boId +
                ", oprBoId=" + oprBoId +
                ", userType='" + userType + '\'' +
                ", userName='" + userName + '\'' +
                ", realName='" + realName + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", headIcon='" + headIcon + '\'' +
                ", areaId=" + areaId +
                ", addr='" + addr + '\'' +
                ", systemId=" + systemId +
                ", gender='" + gender + '\'' +
                ", areaFullName='" + areaFullName + '\'' +
                ", orgName='" + orgName + '\'' +
                ", manuFacturerList=" + manuFacturerList +
                ", goodsCount=" + goodsCount +
                '}';
    }
}
