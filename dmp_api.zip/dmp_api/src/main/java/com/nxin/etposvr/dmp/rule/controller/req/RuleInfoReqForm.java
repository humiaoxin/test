package com.nxin.etposvr.dmp.rule.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

public class RuleInfoReqForm extends WebPageParam {
    @NotNull(message = "规格id不能为null", groups = {VldGroup2th.class})
    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "业务类型", example = "HYCZZ")
    private String busType;

    @ApiModelProperty(value = "规则类型", example = "HYCZZ")
    private String ruleType;

    @ApiModelProperty(value = "规则条件", example = "")
    private String ruleCondition;

    @ApiModelProperty(value = "最大结果", example = "100")
    private Integer maxValue;

    @ApiModelProperty(value = "规则标准", example = "")
    private String ruleStandard;

    @ApiModelProperty(value = "备注", example = "")
    private String remark;

    @ApiModelProperty(value = "系数", example = "")
    private BigDecimal factor;

    @ApiModelProperty(value = "状态", example = "QY")
    private String state;

    @ApiModelProperty(value = "排序", example = "1")
    private Integer sorting;

    @ApiModelProperty(value = "所属系统", example = "1")
    private Byte systemId;


    @ApiModelProperty(value = "是否可用", example = "1可用 0不可用")
    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusType() {
        return busType;
    }

    public void setBusType(String busType) {
        this.busType = busType;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public String getRuleCondition() {
        return ruleCondition;
    }

    public void setRuleCondition(String ruleCondition) {
        this.ruleCondition = ruleCondition;
    }

    public Integer getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    public String getRuleStandard() {
        return ruleStandard;
    }

    public void setRuleStandard(String ruleStandard) {
        this.ruleStandard = ruleStandard;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public BigDecimal getFactor() {
        return factor;
    }

    public void setFactor(BigDecimal factor) {
        this.factor = factor;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getSorting() {
        return sorting;
    }

    public void setSorting(Integer sorting) {
        this.sorting = sorting;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}
