package com.nxin.etposvr.dm.base.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * @author TianShiWei
 * @since:  2019/10/23 13:34
 * @version: v_1.0.1
 */
public class BaseUniqueIdInfoDmReqForm extends WebPageParam {

    private Long id;
    private Long uisId;
    private Long biId;
    private Byte isUse;
    private String uniqueId;
    private String status;
    private Date statusTime;
    private String entryMode;
    private String remark;
    private Long holderBoId;
    private Long categoryId;
    private String categoryAxis;
    private String categoryName;
    private Long rangeId;
    private Long manuId;
    private Long boId;
    private Long oprBoId;
    private String userType;
    private Byte systemId;
    private String dataRemark;
    private Date createTime;
    private String versionRemark;
    private Date vno;
    private Byte isEnabled;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUisId() {
        return uisId;
    }

    public void setUisId(Long uisId) {
        this.uisId = uisId;
    }

    public Long getBiId() {
        return biId;
    }

    public void setBiId(Long biId) {
        this.biId = biId;
    }

    public Byte getIsUse() {
        return isUse;
    }

    public void setIsUse(Byte isUse) {
        this.isUse = isUse;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getStatusTime() {
        return statusTime;
    }

    public void setStatusTime(Date statusTime) {
        this.statusTime = statusTime;
    }

    public String getEntryMode() {
        return entryMode;
    }

    public void setEntryMode(String entryMode) {
        this.entryMode = entryMode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Long getHolderBoId() {
        return holderBoId;
    }

    public void setHolderBoId(Long holderBoId) {
        this.holderBoId = holderBoId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getRangeId() {
        return rangeId;
    }

    public void setRangeId(Long rangeId) {
        this.rangeId = rangeId;
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Long getOprBoId() {
        return oprBoId;
    }

    public void setOprBoId(Long oprBoId) {
        this.oprBoId = oprBoId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }
}
