package com.nxin.etposvr.dm.goods.dao.model;


import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;

public class GoodsAttrDmEntity extends WebPageParam {

    /**
     * @Fields 属性历史 ID
     */
    private Long id;
    /**
     * @Fields 属性类型
     */
    private String type;
    /**
     * @Fields 控件类型
     */
    private String widgetType;
    /**
     * @Fields 属性名
     */
    private String name;
    /**
     * @Fields 商品ID
     */
    private Long goodsId;
    /**
     * @Fields 属性定义ID
     */
    private String attrDefId;
    /**
     * @Fields 属性值CODE，枚举时有
     */
    private String valCode;
    /**
     * @Fields 属性值单位中文
     */
    private String valUnitTxt;
    /**
     * @Fields 属性值单位CODE
     */
    private String valUnit;
    /**
     * @Fields 属性值单位类型
     */
    private String valUnitType;
    /**
     * @Fields 显示顺序
     */
    private Integer sort;
    /**
     * @Fields 所属系统
     */
    private Byte systemId;
    /**
     * @Fields 数据说明 开发时写入
     */
    private String dataRemark;
    /**
     * @Fields 创建时间
     */
    private Date createTime;
    /**
     * @Fields 版本说明
     */
    private String versionRemark;
    /**
     * @Fields 版本号
     */
    private Date vno;
    /**
     * @Fields 是否可用 1可用 0不可用
     */
    private Byte isEnabled;
    /**
     * @Fields 属性值
     */
    private String val;
    /**
     * @Fields 属性id
     */
    private Long attrId;
    /**
     * @Fields 商品idList
     */
    private List<Long> goodsIdList;


    public Long getAttrId() {
        return attrId;
    }

    public void setAttrId(Long attrId) {
        this.attrId = attrId;
    }

    public List<Long> getGoodsIdList() {
        return goodsIdList;
    }
    public void setGoodsIdList(List<Long> goodsIdList) {
        this.goodsIdList = goodsIdList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWidgetType() {
        return widgetType;
    }

    public void setWidgetType(String widgetType) {
        this.widgetType = widgetType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValUnitType() {
        return valUnitType;
    }

    public void setValUnitType(String valUnitType) {
        this.valUnitType = valUnitType;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public String getValCode() {
        return valCode;
    }

    public void setValCode(String valCode) {
        this.valCode = valCode;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public String getAttrDefId() {
        return attrDefId;
    }

    public void setAttrDefId(String attrDefId) {
        this.attrDefId = attrDefId;
    }

    public String getValUnitTxt() {
        return valUnitTxt;
    }

    public void setValUnitTxt(String valUnitTxt) {
        this.valUnitTxt = valUnitTxt;
    }

    public String getValUnit() {
        return valUnit;
    }

    public void setValUnit(String valUnit) {
        this.valUnit = valUnit;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }
}