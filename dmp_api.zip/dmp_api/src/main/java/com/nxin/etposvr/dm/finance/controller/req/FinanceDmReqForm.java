package com.nxin.etposvr.dm.finance.controller.req;


import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * 金融bo
 * @author sjw
 * @since 2020/4/10
 */
public class FinanceDmReqForm extends WebPageParam {

    private Byte systemId;

    private Date startTime;

    private Date endTime;


    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}