package com.nxin.etposvr.dm.base.controller.res;

import com.nxin.etposvr.dm.base.dao.model.BaseUniqueIdInfoDmEntity;

import java.util.Date;

/**
 * @author TianShiWei
 * @since:  2019/10/23 13:34
 * @version: v_1.0.1
 */
public class BaseUniqueIdInfoDmResForm extends BaseUniqueIdInfoDmEntity {


}
