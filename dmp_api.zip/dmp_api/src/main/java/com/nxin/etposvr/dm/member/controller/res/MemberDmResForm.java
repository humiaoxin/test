package com.nxin.etposvr.dm.member.controller.res;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.nxin.etposvr.dm.goods.dao.model.GoodsInfoDmEntity;
import com.nxin.etposvr.dm.shop.dao.model.ShopInfoDmEntity;
import com.nxin.etposvr.dm.system.dao.model.SystemEvaluateDmEntity;

import java.util.List;

public class MemberDmResForm {
    /**
     * 服务人员boId
     */
    private Long boId;
    /**
     * 客户boId集合
     */
    public List<Long> boIdList;
    /**
     * 所有客户的猪场个数
     */
    public int manuCount;
    /**
     * 所有在售商品数
     */
    public int goodsCount;
    /**
     * 总成交数
     */
    public int orderCount;

    /**
     * 商品类型集合
     */
    public String type;

    private Byte systemId;

    /**
     * 商品集合
     */
    public List<GoodsInfoDmEntity> spGoodsList;

    /**
     * 求购集合
     */
    public List<GoodsInfoDmEntity> qgGoodsList;

    /**
     * 评价集合
     */
    public List<SystemEvaluateDmEntity> pjList;

    public List<ShopInfoDmEntity> shopList;

    /**
     * 成长值
     */
    private String growthValue;
    /**
     * 会员等级名称
     */
    private String rankName;

    /**
     * 姓名
     */
    private String  realName;

    /**
     * 手机号
     */
    private String mobilePhone;

    private String userName;

    public String getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(String growthValue) {
        this.growthValue = growthValue;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public int getManuCount() {
        return manuCount;
    }

    public void setManuCount(int manuCount) {
        this.manuCount = manuCount;
    }

    public int getGoodsCount() {
        return goodsCount;
    }

    public void setGoodsCount(int goodsCount) {
        this.goodsCount = goodsCount;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public List<GoodsInfoDmEntity> getSpGoodsList() {
        return spGoodsList;
    }

    public void setSpGoodsList(List<GoodsInfoDmEntity> spGoodsList) {
        this.spGoodsList = spGoodsList;
    }

    public List<GoodsInfoDmEntity> getQgGoodsList() {
        return qgGoodsList;
    }

    public void setQgGoodsList(List<GoodsInfoDmEntity> qgGoodsList) {
        this.qgGoodsList = qgGoodsList;
    }

    public List<SystemEvaluateDmEntity> getPjList() {
        return pjList;
    }

    public void setPjList(List<SystemEvaluateDmEntity> pjList) {
        this.pjList = pjList;
    }


    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public List<ShopInfoDmEntity> getShopList() {
        return shopList;
    }

    public void setShopList(List<ShopInfoDmEntity> shopList) {
        this.shopList = shopList;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, new SerializerFeature[]{
                SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty,
                SerializerFeature.WriteNullStringAsEmpty,
                SerializerFeature.WriteNullNumberAsZero,
                SerializerFeature.WriteNullBooleanAsFalse,
                SerializerFeature.WriteDateUseDateFormat});
    }

}
