package com.nxin.etposvr.dm.elasticsearch.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class GoodsSpecEsEntity {

    public BigDecimal sellPrice;

    public BigDecimal currStock;

    private BigDecimal wholesalePrice;

    private BigDecimal costPrice;

    private BigDecimal marketPrice;

    private Date vno;

    public String promotionType;

    private String stockUnit;

    public String getStockUnit() {
        return stockUnit;
    }

    public void setStockUnit(String stockUnit) {
        this.stockUnit = stockUnit;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    public void setWholesalePrice(BigDecimal wholesalePrice) {
        this.wholesalePrice = wholesalePrice;
    }

    public BigDecimal getCostPrice() {
        return costPrice;
    }

    public void setCostPrice(BigDecimal costPrice) {
        this.costPrice = costPrice;
    }

    public BigDecimal getMarketPrice() {
        return marketPrice;
    }

    public void setMarketPrice(BigDecimal marketPrice) {
        this.marketPrice = marketPrice;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getCurrStock() {
        return currStock;
    }

    public void setCurrStock(BigDecimal currStock) {
        this.currStock = currStock;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }


}


