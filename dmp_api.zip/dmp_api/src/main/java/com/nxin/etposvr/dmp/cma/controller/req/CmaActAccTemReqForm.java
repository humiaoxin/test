package com.nxin.etposvr.dmp.cma.controller.req;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;

public class CmaActAccTemReqForm {
    @ApiModelProperty(value = "ID", example = "1")
    private Long id;

    @ApiModelProperty(value = "汇总类型", example = "DAY")
    private String type;

    @ApiModelProperty(value = "区站号", example = "123")
    private Integer siteId;

    @ApiModelProperty(value = "纬度", example = "123")
    private Integer latitude;

    @ApiModelProperty(value = "经度", example = "123")
    private Integer longtitude;

    @ApiModelProperty(value = "geohash", example = "12ass3")
    private String geohash;

    @ApiModelProperty(value = "年", example = "2020")
    private Integer year;

    @ApiModelProperty(value = "月", example = "1")
    private Integer month;

    @ApiModelProperty(value = "活动积温", example = "100")
    private Integer actAccTem;

    @ApiModelProperty(value = "所属系统", example = "1")
    private Byte systemId;

    @ApiModelProperty(value = "数据说明 开发时写入")
    private String dataRemark;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "版本说明")
    private String versionRemark;

    @ApiModelProperty(value = "版本号")
    private Date vno;

    @ApiModelProperty(value = "是否可用 1可用 0不可用")
    private Byte isEnabled;


    @ApiModelProperty(value = "查询范围 最小活动积温")
    private Integer minActAccTem;

    @ApiModelProperty(value = "查询范围 最大活动积温")
    private Integer maxActAccTem;

    @ApiModelProperty(value = "查询条件 经纬度hash")
    private String geohashLike;

    @ApiModelProperty(value = "数据id")
    private Long dataId;

    public Long getDataId() {
        return dataId;
    }
    public void setDataId(Long dataId) {
        this.dataId = dataId;
    }

    private List<CmaActAccTemReqForm> cmaActAccTemReqFormList;

    public List<CmaActAccTemReqForm> getCmaActAccTemReqFormList() {
        return cmaActAccTemReqFormList;
    }

    public void setCmaActAccTemReqFormList(List<CmaActAccTemReqForm> cmaActAccTemReqFormList) {
        this.cmaActAccTemReqFormList = cmaActAccTemReqFormList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public Integer getLatitude() {
        return latitude;
    }

    public void setLatitude(Integer latitude) {
        this.latitude = latitude;
    }

    public Integer getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Integer longtitude) {
        this.longtitude = longtitude;
    }

    public String getGeohash() {
        return geohash;
    }

    public void setGeohash(String geohash) {
        this.geohash = geohash;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getActAccTem() {
        return actAccTem;
    }

    public void setActAccTem(Integer actAccTem) {
        this.actAccTem = actAccTem;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Integer getMinActAccTem() {
        return minActAccTem;
    }

    public void setMinActAccTem(Integer minActAccTem) {
        this.minActAccTem = minActAccTem;
    }

    public Integer getMaxActAccTem() {
        return maxActAccTem;
    }

    public void setMaxActAccTem(Integer maxActAccTem) {
        this.maxActAccTem = maxActAccTem;
    }

    public String getGeohashLike() {
        return geohashLike;
    }

    public void setGeohashLike(String geohashLike) {
        this.geohashLike = geohashLike;
    }

    @Override
    public String toString() {
        return "CmaActAccTemReqForm{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", siteId=" + siteId +
                ", latitude=" + latitude +
                ", longtitude=" + longtitude +
                ", geohash='" + geohash + '\'' +
                ", year=" + year +
                ", month=" + month +
                ", actAccTem=" + actAccTem +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                ", minActAccTem=" + minActAccTem +
                ", maxActAccTem=" + maxActAccTem +
                ", geohashLike='" + geohashLike + '\'' +
                '}';
    }
}
