package com.nxin.etposvr.dmp.satelite.controller.res;

import com.nxin.etposvr.dmp.satelite.dao.model.SateliteHdfInfo;

import java.util.List;

/**
 * 数据文件信息出参
 *
 * @author ShanShuYu
 * @version v_1.0.1
 * @since 2020/1/8 10:27
 */
public class SateliteHdfInfoResForm extends SateliteHdfInfo {

    private List<SateliteHdfDtlResForm> sateliteHdfDtlResFormList;

    public List<SateliteHdfDtlResForm> getSateliteHdfDtlResFormList() {
        return sateliteHdfDtlResFormList;
    }

    public void setSateliteHdfDtlResFormList(List<SateliteHdfDtlResForm> sateliteHdfDtlResFormList) {
        this.sateliteHdfDtlResFormList = sateliteHdfDtlResFormList;
    }

    @Override
    public String toString() {
        return "SateliteHdfInfoResForm{" +
                "sateliteHdfDtlResFormList=" + sateliteHdfDtlResFormList +
                '}';
    }
}
