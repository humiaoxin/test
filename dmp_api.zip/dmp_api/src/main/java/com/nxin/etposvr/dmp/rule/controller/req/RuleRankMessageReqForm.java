package com.nxin.etposvr.dmp.rule.controller.req;

/**
 * 发送规则等级message
 */
public class RuleRankMessageReqForm {
    private Long id;

    private Long boId;
    /** 店铺信誉值 */
    private Integer reputationValue;
    /** 会员成长值 */
    private Integer growthValue;
    /** 等级 */
    private Integer rank;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public Integer getReputationValue() {
        return reputationValue;
    }

    public void setReputationValue(Integer reputationValue) {
        this.reputationValue = reputationValue;
    }

    public Integer getGrowthValue() {
        return growthValue;
    }

    public void setGrowthValue(Integer growthValue) {
        this.growthValue = growthValue;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }
}
