package com.nxin.etposvr.dm.commission.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.math.BigDecimal;
import java.util.List;

public class CommissionManageDmReqForm extends WebPageParam {

    //登录名
    private String loginName;
    //姓名
    private String userName;
    //手机号
    private String tel;
    //所在地
    private String addr;
    //推广状态
    private String status;
    //推广状态-中文
    private String statusCn;
    //月佣金
    private BigDecimal monthMoney;
    //结算状态
    private String blanceStatus;
    //结算状态-中文
    private String blanceStatusCn;
    //返拥用户Id
    private Long boId;
    //日期
    private String dateTime;

    private List<Long> boIdList;

    /**页数*/
    private Integer pageNum;
    /**页数大小*/
    private Integer pageSize;

    //佣金月时间
    private String monthTime;

    //佣金状态集合
    private List<String> blanceStatusList;


    public List<String> getBlanceStatusList() {
        return blanceStatusList;
    }

    public void setBlanceStatusList(List<String> blanceStatusList) {
        this.blanceStatusList = blanceStatusList;
    }

    public String getMonthTime() {
        return monthTime;
    }

    public void setMonthTime(String monthTime) {
        this.monthTime = monthTime;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusCn() {
        return statusCn;
    }

    public void setStatusCn(String statusCn) {
        this.statusCn = statusCn;
    }

    public BigDecimal getMonthMoney() {
        return monthMoney;
    }

    public void setMonthMoney(BigDecimal monthMoney) {
        this.monthMoney = monthMoney;
    }

    public String getBlanceStatus() {
        return blanceStatus;
    }

    public void setBlanceStatus(String blanceStatus) {
        this.blanceStatus = blanceStatus;
    }

    public String getBlanceStatusCn() {
        return blanceStatusCn;
    }

    public void setBlanceStatusCn(String blanceStatusCn) {
        this.blanceStatusCn = blanceStatusCn;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }
}
