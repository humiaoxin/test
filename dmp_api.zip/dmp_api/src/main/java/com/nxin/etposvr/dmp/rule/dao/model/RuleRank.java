package com.nxin.etposvr.dmp.rule.dao.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Title rule_rank表的实体类
 * @Description 等级规则表
 * @version 1.0
 * @Author System
 * @Date 2019-12-20 18:24:36
 */
public class RuleRank implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields busType 业务类型
     */
    private String busType;

    /**
     * @Fields infoId 规则表ID
     */
    private Long infoId;

    /**
     * @Fields name 名称
     */
    private String name;

    /**
     * @Fields rank 等级
     */
    private Integer rank;

    /**
     * @Fields minValue 最小值
     */
    private Integer minValue;

    /**
     * @Fields maxValue 最大值
     */
    private Integer maxValue;

    /**
     * @Fields sorting 排序
     */
    private Integer sorting;

    /**
     * @Fields icon 图标
     */
    private String icon;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:rule_rank.id
     *
     * @return rule_rank.id, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:rule_rank.id
     *
     * @param id the value for rule_rank.id, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 业务类型 字段:rule_rank.bus_type
     *
     * @return rule_rank.bus_type, 业务类型
     */
    public String getBusType() {
        return busType;
    }

    /**
     * 设置 业务类型 字段:rule_rank.bus_type
     *
     * @param busType the value for rule_rank.bus_type, 业务类型
     */
    public void setBusType(String busType) {
        this.busType = busType == null ? null : busType.trim();
    }

    /**
     * 获取 规则表ID 字段:rule_rank.info_id
     *
     * @return rule_rank.info_id, 规则表ID
     */
    public Long getInfoId() {
        return infoId;
    }

    /**
     * 设置 规则表ID 字段:rule_rank.info_id
     *
     * @param infoId the value for rule_rank.info_id, 规则表ID
     */
    public void setInfoId(Long infoId) {
        this.infoId = infoId;
    }

    /**
     * 获取 名称 字段:rule_rank.name
     *
     * @return rule_rank.name, 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置 名称 字段:rule_rank.name
     *
     * @param name the value for rule_rank.name, 名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 获取 等级 字段:rule_rank.rank
     *
     * @return rule_rank.rank, 等级
     */
    public Integer getRank() {
        return rank;
    }

    /**
     * 设置 等级 字段:rule_rank.rank
     *
     * @param rank the value for rule_rank.rank, 等级
     */
    public void setRank(Integer rank) {
        this.rank = rank;
    }

    /**
     * 获取 最小值 字段:rule_rank.min_value
     *
     * @return rule_rank.min_value, 最小值
     */
    public Integer getMinValue() {
        return minValue;
    }

    /**
     * 设置 最小值 字段:rule_rank.min_value
     *
     * @param minValue the value for rule_rank.min_value, 最小值
     */
    public void setMinValue(Integer minValue) {
        this.minValue = minValue;
    }

    /**
     * 获取 最大值 字段:rule_rank.max_value
     *
     * @return rule_rank.max_value, 最大值
     */
    public Integer getMaxValue() {
        return maxValue;
    }

    /**
     * 设置 最大值 字段:rule_rank.max_value
     *
     * @param maxValue the value for rule_rank.max_value, 最大值
     */
    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * 获取 排序 字段:rule_rank.sorting
     *
     * @return rule_rank.sorting, 排序
     */
    public Integer getSorting() {
        return sorting;
    }

    /**
     * 设置 排序 字段:rule_rank.sorting
     *
     * @param sorting the value for rule_rank.sorting, 排序
     */
    public void setSorting(Integer sorting) {
        this.sorting = sorting;
    }

    /**
     * 获取 图标 字段:rule_rank.icon
     *
     * @return rule_rank.icon, 图标
     */
    public String getIcon() {
        return icon;
    }

    /**
     * 设置 图标 字段:rule_rank.icon
     *
     * @param icon the value for rule_rank.icon, 图标
     */
    public void setIcon(String icon) {
        this.icon = icon == null ? null : icon.trim();
    }

    /**
     * 获取 所属系统 字段:rule_rank.system_id
     *
     * @return rule_rank.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:rule_rank.system_id
     *
     * @param systemId the value for rule_rank.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:rule_rank.data_remark
     *
     * @return rule_rank.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:rule_rank.data_remark
     *
     * @param dataRemark the value for rule_rank.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:rule_rank.create_time
     *
     * @return rule_rank.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:rule_rank.create_time
     *
     * @param createTime the value for rule_rank.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:rule_rank.version_remark
     *
     * @return rule_rank.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:rule_rank.version_remark
     *
     * @param versionRemark the value for rule_rank.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:rule_rank.vno
     *
     * @return rule_rank.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:rule_rank.vno
     *
     * @param vno the value for rule_rank.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:rule_rank.is_enabled
     *
     * @return rule_rank.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:rule_rank.is_enabled
     *
     * @param isEnabled the value for rule_rank.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :rule_rank
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", busType=").append(busType);
        sb.append(", infoId=").append(infoId);
        sb.append(", name=").append(name);
        sb.append(", rank=").append(rank);
        sb.append(", minValue=").append(minValue);
        sb.append(", maxValue=").append(maxValue);
        sb.append(", sorting=").append(sorting);
        sb.append(", icon=").append(icon);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :rule_rank
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        RuleRank other = (RuleRank) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getBusType() == null ? other.getBusType() == null : this.getBusType().equals(other.getBusType()))
            && (this.getInfoId() == null ? other.getInfoId() == null : this.getInfoId().equals(other.getInfoId()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getRank() == null ? other.getRank() == null : this.getRank().equals(other.getRank()))
            && (this.getMinValue() == null ? other.getMinValue() == null : this.getMinValue().equals(other.getMinValue()))
            && (this.getMaxValue() == null ? other.getMaxValue() == null : this.getMaxValue().equals(other.getMaxValue()))
            && (this.getSorting() == null ? other.getSorting() == null : this.getSorting().equals(other.getSorting()))
            && (this.getIcon() == null ? other.getIcon() == null : this.getIcon().equals(other.getIcon()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :rule_rank
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getBusType() == null) ? 0 : getBusType().hashCode());
        result = prime * result + ((getInfoId() == null) ? 0 : getInfoId().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getRank() == null) ? 0 : getRank().hashCode());
        result = prime * result + ((getMinValue() == null) ? 0 : getMinValue().hashCode());
        result = prime * result + ((getMaxValue() == null) ? 0 : getMaxValue().hashCode());
        result = prime * result + ((getSorting() == null) ? 0 : getSorting().hashCode());
        result = prime * result + ((getIcon() == null) ? 0 : getIcon().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}