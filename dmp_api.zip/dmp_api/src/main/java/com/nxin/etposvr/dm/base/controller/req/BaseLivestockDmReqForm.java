package com.nxin.etposvr.dm.base.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/14 17:03
 */
public class BaseLivestockDmReqForm extends WebPageParam {
    private Byte systemId;

    private String categoryAxis;

    private String areaAxisLike;

    private double ztRate;

    private double zsRate;

    private Long totalBreedNum;

    private Long totalManuNum;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public double getZtRate() {
        return ztRate;
    }

    public void setZtRate(double ztRate) {
        this.ztRate = ztRate;
    }

    public double getZsRate() {
        return zsRate;
    }

    public void setZsRate(double zsRate) {
        this.zsRate = zsRate;
    }

    public Long getTotalBreedNum() {
        return totalBreedNum;
    }

    public void setTotalBreedNum(Long totalBreedNum) {
        this.totalBreedNum = totalBreedNum;
    }

    public Long getTotalManuNum() {
        return totalManuNum;
    }

    public void setTotalManuNum(Long totalManuNum) {
        this.totalManuNum = totalManuNum;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("BaseLivestockDmReqForm{");
        sb.append("systemId=").append(systemId);
        sb.append(", categoryAxis='").append(categoryAxis).append('\'');
        sb.append(", areaAxisLike='").append(areaAxisLike).append('\'');
        sb.append(", ztRate=").append(ztRate);
        sb.append(", zsRate=").append(zsRate);
        sb.append(", totalBreedNum=").append(totalBreedNum);
        sb.append(", totalManuNum=").append(totalManuNum);
        sb.append("super:").append(super.toString());
        sb.append('}');
        return sb.toString();
    }
}
