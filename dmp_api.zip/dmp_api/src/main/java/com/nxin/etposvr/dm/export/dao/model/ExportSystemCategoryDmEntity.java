package com.nxin.etposvr.dm.export.dao.model;

/**
 * @author ShanShuYu
 * @version v_1.0.1
 * @since  2020/9/5 10:11
 */
public class ExportSystemCategoryDmEntity {

    private Byte systemId;

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "ExportSystemCategoryDmEntity{" +
                "systemId=" + systemId +
                '}';
    }
}
