package com.nxin.etposvr.dm.shop.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;
import java.util.List;

/**
 * 店铺大数据请求实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class ShopBigDataDmReqForm extends WebPageParam {

    private Byte systemId;
    /**
     * 范围（天数）
     */
    private Integer range;
    /**
     * 统计类型DAY-按日统计MON-按月统计YEAR-按年统计
     */
    private String statType;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 状态集合
     */
    private List<String> statusList;

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    @Override
    public String toString() {
        return "ShopBigDataDmReqForm{" +
                "systemId=" + systemId +
                ", range=" + range +
                ", statType='" + statType + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
