package com.nxin.etposvr.dmp.rule.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import io.swagger.annotations.ApiModelProperty;

/**
 * 店铺信誉值
 */
public class ShopRuleScoreRecordReqForm extends WebPageParam {
    @ApiModelProperty(value = "店铺id", example = "1")
    private Long id;
    @ApiModelProperty(value = "店铺等级", example = "1")
    private Integer rank;
    @ApiModelProperty(value = "店铺信誉值", example = "1")
    private Integer reputationValue;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Integer getReputationValue() {
        return reputationValue;
    }

    public void setReputationValue(Integer reputationValue) {
        this.reputationValue = reputationValue;
    }

    @Override
    public String toString() {
        return "ShopRuleScoreRecordReqForm{" +
                "id=" + id +
                ", rank=" + rank +
                ", reputationValue=" + reputationValue +
                '}';
    }
}
