package com.nxin.etposvr.dm.system.controller.res;

import com.nxin.etposvr.basic.system.controller.res.SystemCodeResForm;

/**
 * @author YanShuang
 * @version v_1.0.1
 * @since 2022/4/19 9:36
 */
public class SystemCodeDmResForm extends SystemCodeResForm {
}
