package com.nxin.etposvr.dm.feeding.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;

import java.util.Date;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/11 9:51
 */
public class FeedingTreatDmReqForm  extends WebPageParam {

    private String categoryAxis;

    private String categoryName;

    private String diseaseName;

    private String diseaseNameCn;

    private Byte systemId;

    private Date treatDateStart;

    private Date treatDateEnd;

    private Byte isEnabled;

    private Integer treatNum;

    private String areaAxisLike;

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public Integer getTreatNum() {
        return treatNum;
    }

    public void setTreatNum(Integer treatNum) {
        this.treatNum = treatNum;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getDiseaseName() {
        return diseaseName;
    }

    public void setDiseaseName(String diseaseName) {
        this.diseaseName = diseaseName;
    }

    public String getDiseaseNameCn() {
        return diseaseNameCn;
    }

    public void setDiseaseNameCn(String diseaseNameCn) {
        this.diseaseNameCn = diseaseNameCn;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getTreatDateStart() {
        return treatDateStart;
    }

    public void setTreatDateStart(Date treatDateStart) {
        this.treatDateStart = treatDateStart;
    }

    public Date getTreatDateEnd() {
        return treatDateEnd;
    }

    public void setTreatDateEnd(Date treatDateEnd) {
        this.treatDateEnd = treatDateEnd;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("FeedingTreatDmReqForm{");
        sb.append("categoryAxis='").append(categoryAxis).append('\'');
        sb.append(", categoryName='").append(categoryName).append('\'');
        sb.append(", diseaseName='").append(diseaseName).append('\'');
        sb.append(", diseaseNameCn='").append(diseaseNameCn).append('\'');
        sb.append(", systemId=").append(systemId);
        sb.append(", treatDateStart=").append(treatDateStart);
        sb.append(", treatDateEnd=").append(treatDateEnd);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", treatNum=").append(treatNum);
        sb.append("super:").append(super.toString());
        sb.append('}');
        return sb.toString();
    }
}
