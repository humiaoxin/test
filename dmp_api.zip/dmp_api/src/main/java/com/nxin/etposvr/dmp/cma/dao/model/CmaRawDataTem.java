package com.nxin.etposvr.dmp.cma.dao.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Title cma_raw_data_tem表的实体类
 * @Description 气温原始数据
 * @version 1.0
 * @Author System
 * @Date 2020-05-16 14:15:46
 */
public class CmaRawDataTem implements Serializable {
    /**
     * @Fields id ID
     */
    private Long id;

    /**
     * @Fields type 类型
     */
    private String type;

    /**
     * @Fields siteId 区站号
     */
    private Integer siteId;

    /**
     * @Fields latitude 纬度
     */
    private Integer latitude;

    /**
     * @Fields longtitude 经度
     */
    private Integer longtitude;

    /**
     * @Fields geohash geohash
     */
    private String geohash;

    /**
     * @Fields altitude 观测场拔海高度
     */
    private Integer altitude;

    /**
     * @Fields year 年
     */
    private Integer year;

    /**
     * @Fields month 月
     */
    private Integer month;

    /**
     * @Fields day 日
     */
    private Integer day;

    /**
     * @Fields averageTem 平均气温
     */
    private Integer averageTem;

    /**
     * @Fields hiTem 日最高气温
     */
    private Integer hiTem;

    /**
     * @Fields lowTem 日最低气温
     */
    private Integer lowTem;

    /**
     * @Fields averageTemCode 平均气温质量控制码
     */
    private Integer averageTemCode;

    /**
     * @Fields hiTemCode 日最高气温质量控制码
     */
    private Integer hiTemCode;

    /**
     * @Fields lowTemCode 日最低气温质量控制码
     */
    private Integer lowTemCode;

    /**
     * @Fields systemId 所属系统
     */
    private Byte systemId;

    /**
     * @Fields dataRemark 数据说明 开发时写入
     */
    private String dataRemark;

    /**
     * @Fields createTime 创建时间
     */
    private Date createTime;

    /**
     * @Fields versionRemark 版本说明
     */
    private String versionRemark;

    /**
     * @Fields vno 版本号 
     */
    private Date vno;

    /**
     * @Fields isEnabled 是否可用 1可用 0不可用
     */
    private Byte isEnabled;

    private static final long serialVersionUID = 1L;

    /**
     * 获取 ID 字段:cma_raw_data_tem.ID
     *
     * @return cma_raw_data_tem.ID, ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 ID 字段:cma_raw_data_tem.ID
     *
     * @param id the value for cma_raw_data_tem.ID, ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 类型 字段:cma_raw_data_tem.type
     *
     * @return cma_raw_data_tem.type, 类型
     */
    public String getType() {
        return type;
    }

    /**
     * 设置 类型 字段:cma_raw_data_tem.type
     *
     * @param type the value for cma_raw_data_tem.type, 类型
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 获取 区站号 字段:cma_raw_data_tem.site_id
     *
     * @return cma_raw_data_tem.site_id, 区站号
     */
    public Integer getSiteId() {
        return siteId;
    }

    /**
     * 设置 区站号 字段:cma_raw_data_tem.site_id
     *
     * @param siteId the value for cma_raw_data_tem.site_id, 区站号
     */
    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    /**
     * 获取 纬度 字段:cma_raw_data_tem.latitude
     *
     * @return cma_raw_data_tem.latitude, 纬度
     */
    public Integer getLatitude() {
        return latitude;
    }

    /**
     * 设置 纬度 字段:cma_raw_data_tem.latitude
     *
     * @param latitude the value for cma_raw_data_tem.latitude, 纬度
     */
    public void setLatitude(Integer latitude) {
        this.latitude = latitude;
    }

    /**
     * 获取 经度 字段:cma_raw_data_tem.longtitude
     *
     * @return cma_raw_data_tem.longtitude, 经度
     */
    public Integer getLongtitude() {
        return longtitude;
    }

    /**
     * 设置 经度 字段:cma_raw_data_tem.longtitude
     *
     * @param longtitude the value for cma_raw_data_tem.longtitude, 经度
     */
    public void setLongtitude(Integer longtitude) {
        this.longtitude = longtitude;
    }

    /**
     * 获取 geohash 字段:cma_raw_data_tem.geohash
     *
     * @return cma_raw_data_tem.geohash, geohash
     */
    public String getGeohash() {
        return geohash;
    }

    /**
     * 设置 geohash 字段:cma_raw_data_tem.geohash
     *
     * @param geohash the value for cma_raw_data_tem.geohash, geohash
     */
    public void setGeohash(String geohash) {
        this.geohash = geohash == null ? null : geohash.trim();
    }

    /**
     * 获取 观测场拔海高度 字段:cma_raw_data_tem.altitude
     *
     * @return cma_raw_data_tem.altitude, 观测场拔海高度
     */
    public Integer getAltitude() {
        return altitude;
    }

    /**
     * 设置 观测场拔海高度 字段:cma_raw_data_tem.altitude
     *
     * @param altitude the value for cma_raw_data_tem.altitude, 观测场拔海高度
     */
    public void setAltitude(Integer altitude) {
        this.altitude = altitude;
    }

    /**
     * 获取 年 字段:cma_raw_data_tem.year
     *
     * @return cma_raw_data_tem.year, 年
     */
    public Integer getYear() {
        return year;
    }

    /**
     * 设置 年 字段:cma_raw_data_tem.year
     *
     * @param year the value for cma_raw_data_tem.year, 年
     */
    public void setYear(Integer year) {
        this.year = year;
    }

    /**
     * 获取 月 字段:cma_raw_data_tem.month
     *
     * @return cma_raw_data_tem.month, 月
     */
    public Integer getMonth() {
        return month;
    }

    /**
     * 设置 月 字段:cma_raw_data_tem.month
     *
     * @param month the value for cma_raw_data_tem.month, 月
     */
    public void setMonth(Integer month) {
        this.month = month;
    }

    /**
     * 获取 日 字段:cma_raw_data_tem.day
     *
     * @return cma_raw_data_tem.day, 日
     */
    public Integer getDay() {
        return day;
    }

    /**
     * 设置 日 字段:cma_raw_data_tem.day
     *
     * @param day the value for cma_raw_data_tem.day, 日
     */
    public void setDay(Integer day) {
        this.day = day;
    }

    /**
     * 获取 平均气温 字段:cma_raw_data_tem.average_tem
     *
     * @return cma_raw_data_tem.average_tem, 平均气温
     */
    public Integer getAverageTem() {
        return averageTem;
    }

    /**
     * 设置 平均气温 字段:cma_raw_data_tem.average_tem
     *
     * @param averageTem the value for cma_raw_data_tem.average_tem, 平均气温
     */
    public void setAverageTem(Integer averageTem) {
        this.averageTem = averageTem;
    }

    /**
     * 获取 日最高气温 字段:cma_raw_data_tem.hi_tem
     *
     * @return cma_raw_data_tem.hi_tem, 日最高气温
     */
    public Integer getHiTem() {
        return hiTem;
    }

    /**
     * 设置 日最高气温 字段:cma_raw_data_tem.hi_tem
     *
     * @param hiTem the value for cma_raw_data_tem.hi_tem, 日最高气温
     */
    public void setHiTem(Integer hiTem) {
        this.hiTem = hiTem;
    }

    /**
     * 获取 日最低气温 字段:cma_raw_data_tem.low_tem
     *
     * @return cma_raw_data_tem.low_tem, 日最低气温
     */
    public Integer getLowTem() {
        return lowTem;
    }

    /**
     * 设置 日最低气温 字段:cma_raw_data_tem.low_tem
     *
     * @param lowTem the value for cma_raw_data_tem.low_tem, 日最低气温
     */
    public void setLowTem(Integer lowTem) {
        this.lowTem = lowTem;
    }

    /**
     * 获取 平均气温质量控制码 字段:cma_raw_data_tem.average_tem_code
     *
     * @return cma_raw_data_tem.average_tem_code, 平均气温质量控制码
     */
    public Integer getAverageTemCode() {
        return averageTemCode;
    }

    /**
     * 设置 平均气温质量控制码 字段:cma_raw_data_tem.average_tem_code
     *
     * @param averageTemCode the value for cma_raw_data_tem.average_tem_code, 平均气温质量控制码
     */
    public void setAverageTemCode(Integer averageTemCode) {
        this.averageTemCode = averageTemCode;
    }

    /**
     * 获取 日最高气温质量控制码 字段:cma_raw_data_tem.hi_tem_code
     *
     * @return cma_raw_data_tem.hi_tem_code, 日最高气温质量控制码
     */
    public Integer getHiTemCode() {
        return hiTemCode;
    }

    /**
     * 设置 日最高气温质量控制码 字段:cma_raw_data_tem.hi_tem_code
     *
     * @param hiTemCode the value for cma_raw_data_tem.hi_tem_code, 日最高气温质量控制码
     */
    public void setHiTemCode(Integer hiTemCode) {
        this.hiTemCode = hiTemCode;
    }

    /**
     * 获取 日最低气温质量控制码 字段:cma_raw_data_tem.low_tem_code
     *
     * @return cma_raw_data_tem.low_tem_code, 日最低气温质量控制码
     */
    public Integer getLowTemCode() {
        return lowTemCode;
    }

    /**
     * 设置 日最低气温质量控制码 字段:cma_raw_data_tem.low_tem_code
     *
     * @param lowTemCode the value for cma_raw_data_tem.low_tem_code, 日最低气温质量控制码
     */
    public void setLowTemCode(Integer lowTemCode) {
        this.lowTemCode = lowTemCode;
    }

    /**
     * 获取 所属系统 字段:cma_raw_data_tem.system_id
     *
     * @return cma_raw_data_tem.system_id, 所属系统
     */
    public Byte getSystemId() {
        return systemId;
    }

    /**
     * 设置 所属系统 字段:cma_raw_data_tem.system_id
     *
     * @param systemId the value for cma_raw_data_tem.system_id, 所属系统
     */
    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    /**
     * 获取 数据说明 开发时写入 字段:cma_raw_data_tem.data_remark
     *
     * @return cma_raw_data_tem.data_remark, 数据说明 开发时写入
     */
    public String getDataRemark() {
        return dataRemark;
    }

    /**
     * 设置 数据说明 开发时写入 字段:cma_raw_data_tem.data_remark
     *
     * @param dataRemark the value for cma_raw_data_tem.data_remark, 数据说明 开发时写入
     */
    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark == null ? null : dataRemark.trim();
    }

    /**
     * 获取 创建时间 字段:cma_raw_data_tem.create_time
     *
     * @return cma_raw_data_tem.create_time, 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置 创建时间 字段:cma_raw_data_tem.create_time
     *
     * @param createTime the value for cma_raw_data_tem.create_time, 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取 版本说明 字段:cma_raw_data_tem.version_remark
     *
     * @return cma_raw_data_tem.version_remark, 版本说明
     */
    public String getVersionRemark() {
        return versionRemark;
    }

    /**
     * 设置 版本说明 字段:cma_raw_data_tem.version_remark
     *
     * @param versionRemark the value for cma_raw_data_tem.version_remark, 版本说明
     */
    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark == null ? null : versionRemark.trim();
    }

    /**
     * 获取 版本号  字段:cma_raw_data_tem.vno
     *
     * @return cma_raw_data_tem.vno, 版本号 
     */
    public Date getVno() {
        return vno;
    }

    /**
     * 设置 版本号  字段:cma_raw_data_tem.vno
     *
     * @param vno the value for cma_raw_data_tem.vno, 版本号 
     */
    public void setVno(Date vno) {
        this.vno = vno;
    }

    /**
     * 获取 是否可用 1可用 0不可用 字段:cma_raw_data_tem.is_enabled
     *
     * @return cma_raw_data_tem.is_enabled, 是否可用 1可用 0不可用
     */
    public Byte getIsEnabled() {
        return isEnabled;
    }

    /**
     * 设置 是否可用 1可用 0不可用 字段:cma_raw_data_tem.is_enabled
     *
     * @param isEnabled the value for cma_raw_data_tem.is_enabled, 是否可用 1可用 0不可用
     */
    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * :cma_raw_data_tem
     * @return String
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", type=").append(type);
        sb.append(", siteId=").append(siteId);
        sb.append(", latitude=").append(latitude);
        sb.append(", longtitude=").append(longtitude);
        sb.append(", geohash=").append(geohash);
        sb.append(", altitude=").append(altitude);
        sb.append(", year=").append(year);
        sb.append(", month=").append(month);
        sb.append(", day=").append(day);
        sb.append(", averageTem=").append(averageTem);
        sb.append(", hiTem=").append(hiTem);
        sb.append(", lowTem=").append(lowTem);
        sb.append(", averageTemCode=").append(averageTemCode);
        sb.append(", hiTemCode=").append(hiTemCode);
        sb.append(", lowTemCode=").append(lowTemCode);
        sb.append(", systemId=").append(systemId);
        sb.append(", dataRemark=").append(dataRemark);
        sb.append(", createTime=").append(createTime);
        sb.append(", versionRemark=").append(versionRemark);
        sb.append(", vno=").append(vno);
        sb.append(", isEnabled=").append(isEnabled);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    /**
     * :cma_raw_data_tem
     * @param that
     * @return boolean
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CmaRawDataTem other = (CmaRawDataTem) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getSiteId() == null ? other.getSiteId() == null : this.getSiteId().equals(other.getSiteId()))
            && (this.getLatitude() == null ? other.getLatitude() == null : this.getLatitude().equals(other.getLatitude()))
            && (this.getLongtitude() == null ? other.getLongtitude() == null : this.getLongtitude().equals(other.getLongtitude()))
            && (this.getGeohash() == null ? other.getGeohash() == null : this.getGeohash().equals(other.getGeohash()))
            && (this.getAltitude() == null ? other.getAltitude() == null : this.getAltitude().equals(other.getAltitude()))
            && (this.getYear() == null ? other.getYear() == null : this.getYear().equals(other.getYear()))
            && (this.getMonth() == null ? other.getMonth() == null : this.getMonth().equals(other.getMonth()))
            && (this.getDay() == null ? other.getDay() == null : this.getDay().equals(other.getDay()))
            && (this.getAverageTem() == null ? other.getAverageTem() == null : this.getAverageTem().equals(other.getAverageTem()))
            && (this.getHiTem() == null ? other.getHiTem() == null : this.getHiTem().equals(other.getHiTem()))
            && (this.getLowTem() == null ? other.getLowTem() == null : this.getLowTem().equals(other.getLowTem()))
            && (this.getAverageTemCode() == null ? other.getAverageTemCode() == null : this.getAverageTemCode().equals(other.getAverageTemCode()))
            && (this.getHiTemCode() == null ? other.getHiTemCode() == null : this.getHiTemCode().equals(other.getHiTemCode()))
            && (this.getLowTemCode() == null ? other.getLowTemCode() == null : this.getLowTemCode().equals(other.getLowTemCode()))
            && (this.getSystemId() == null ? other.getSystemId() == null : this.getSystemId().equals(other.getSystemId()))
            && (this.getDataRemark() == null ? other.getDataRemark() == null : this.getDataRemark().equals(other.getDataRemark()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getVersionRemark() == null ? other.getVersionRemark() == null : this.getVersionRemark().equals(other.getVersionRemark()))
            && (this.getVno() == null ? other.getVno() == null : this.getVno().equals(other.getVno()))
            && (this.getIsEnabled() == null ? other.getIsEnabled() == null : this.getIsEnabled().equals(other.getIsEnabled()));
    }

    /**
     * :cma_raw_data_tem
     * @return int
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getSiteId() == null) ? 0 : getSiteId().hashCode());
        result = prime * result + ((getLatitude() == null) ? 0 : getLatitude().hashCode());
        result = prime * result + ((getLongtitude() == null) ? 0 : getLongtitude().hashCode());
        result = prime * result + ((getGeohash() == null) ? 0 : getGeohash().hashCode());
        result = prime * result + ((getAltitude() == null) ? 0 : getAltitude().hashCode());
        result = prime * result + ((getYear() == null) ? 0 : getYear().hashCode());
        result = prime * result + ((getMonth() == null) ? 0 : getMonth().hashCode());
        result = prime * result + ((getDay() == null) ? 0 : getDay().hashCode());
        result = prime * result + ((getAverageTem() == null) ? 0 : getAverageTem().hashCode());
        result = prime * result + ((getHiTem() == null) ? 0 : getHiTem().hashCode());
        result = prime * result + ((getLowTem() == null) ? 0 : getLowTem().hashCode());
        result = prime * result + ((getAverageTemCode() == null) ? 0 : getAverageTemCode().hashCode());
        result = prime * result + ((getHiTemCode() == null) ? 0 : getHiTemCode().hashCode());
        result = prime * result + ((getLowTemCode() == null) ? 0 : getLowTemCode().hashCode());
        result = prime * result + ((getSystemId() == null) ? 0 : getSystemId().hashCode());
        result = prime * result + ((getDataRemark() == null) ? 0 : getDataRemark().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getVersionRemark() == null) ? 0 : getVersionRemark().hashCode());
        result = prime * result + ((getVno() == null) ? 0 : getVno().hashCode());
        result = prime * result + ((getIsEnabled() == null) ? 0 : getIsEnabled().hashCode());
        return result;
    }
}