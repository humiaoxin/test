package com.nxin.etposvr.dm.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 金融大数据实体
 *
 * @author sjw
 * @since: 2020/4/10
 * @version: v_1.0.1
 */
public class FinanceDmEntity {

    private Byte systemId;

    private Date startTime;

    private Date endTime;
    /**
     * 累计贷款金额
     */
    private BigDecimal loanAmount;
    /**
     * 累计贷款用户
     */
    private Long loanUser;
    /**
     * 支付类型
     */
    private String paymentCode;
    /**
     * 支付渠道
     */
    private String channelType;
    /**
     * 贷款时间
     */
    private Date loanTime;
    /**
     * 贷款用户累计金额
     */
    private Long totalLoanAmount;
    /**
     * 银行卡用户支付金额
     */
    private BigDecimal cardAmount;
    /**
     * pos用户支付金额
     */
    private BigDecimal posAmount;
    /**
     * 微信用户支付金额
     */
    private BigDecimal wxAmount;
    /**
     * 支付宝用户支付金额
     */
    private BigDecimal zfbAmount;
    /**
     * 余额用户支付金额
     */
    private BigDecimal yeAmount;
    /**
     * 网银用户支付金额
     */
    private BigDecimal wyAmount;
    /**
     * 还款金额
     */
    private BigDecimal returnAmount;

    private BigDecimal amount;
    private Date dateTime;
    private List<Date> dateList;

    /**
     * 纬度
     */
    private String lat;
    /**
     * 精度
     */
    private String lon;
    /**
     * 地区编号
     */
    private Long areaId;
    /**
     * 用户编号
     */
    private Long boId;



    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Long getLoanUser() {
        return loanUser;
    }

    public void setLoanUser(Long loanUser) {
        this.loanUser = loanUser;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }

    public Date getLoanTime() {
        return loanTime;
    }

    public void setLoanTime(Date loanTime) {
        this.loanTime = loanTime;
    }

    public Long getTotalLoanAmount() {
        return totalLoanAmount;
    }

    public void setTotalLoanAmount(Long totalLoanAmount) {
        this.totalLoanAmount = totalLoanAmount;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public BigDecimal getCardAmount() {
        return cardAmount;
    }

    public void setCardAmount(BigDecimal cardAmount) {
        this.cardAmount = cardAmount;
    }

    public BigDecimal getPosAmount() {
        return posAmount;
    }

    public void setPosAmount(BigDecimal posAmount) {
        this.posAmount = posAmount;
    }

    public BigDecimal getWxAmount() {
        return wxAmount;
    }

    public void setWxAmount(BigDecimal wxAmount) {
        this.wxAmount = wxAmount;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getZfbAmount() {
        return zfbAmount;
    }

    public void setZfbAmount(BigDecimal zfbAmount) {
        this.zfbAmount = zfbAmount;
    }

    public BigDecimal getYeAmount() {
        return yeAmount;
    }

    public void setYeAmount(BigDecimal yeAmount) {
        this.yeAmount = yeAmount;
    }

    public BigDecimal getWyAmount() {
        return wyAmount;
    }

    public void setWyAmount(BigDecimal wyAmount) {
        this.wyAmount = wyAmount;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public Long getBoId() {
        return boId;
    }

    public void setBoId(Long boId) {
        this.boId = boId;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public List<Date> getDateList() {
        return dateList;
    }

    public void setDateList(List<Date> dateList) {
        this.dateList = dateList;
    }
}