package com.nxin.etposvr.dm.statement.res;


import java.math.BigDecimal;

/**
 * @author zhaoshuai
 * @version v_1.0.1
 * @since 2019/7/17 18:01
 */
public class TotalNumPcDmResForm {

    private Integer total;

    private Integer sellerPerNum;

    private Integer buyerPerNum;

    private BigDecimal totalMoney;

    private BigDecimal totalGoodsNum;

    private BigDecimal totalNum;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getSellerPerNum() {
        return sellerPerNum;
    }

    public void setSellerPerNum(Integer sellerPerNum) {
        this.sellerPerNum = sellerPerNum;
    }

    public Integer getBuyerPerNum() {
        return buyerPerNum;
    }

    public void setBuyerPerNum(Integer buyerPerNum) {
        this.buyerPerNum = buyerPerNum;
    }

    public BigDecimal getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(BigDecimal totalMoney) {
        this.totalMoney = totalMoney;
    }

    public BigDecimal getTotalGoodsNum() {
        return totalGoodsNum;
    }

    public void setTotalGoodsNum(BigDecimal totalGoodsNum) {
        this.totalGoodsNum = totalGoodsNum;
    }

    public BigDecimal getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(BigDecimal totalNum) {
        this.totalNum = totalNum;
    }

    @Override
    public String toString() {
        return "TotalNumPcDmResForm{" +
                "total=" + total +
                ", sellerPerNum=" + sellerPerNum +
                ", buyerPerNum=" + buyerPerNum +
                ", totalMoney=" + totalMoney +
                ", totalGoodsNum=" + totalGoodsNum +
                ", totalNum=" + totalNum +
                '}';
    }
}
