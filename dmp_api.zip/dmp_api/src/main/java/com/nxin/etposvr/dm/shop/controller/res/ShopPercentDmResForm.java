package com.nxin.etposvr.dm.shop.controller.res;

/**
 * 店铺占比返回实体
 * @author ZhangXu
 * @since 2019.10.23
 */
public class ShopPercentDmResForm {

    /**用户类型*/
    private String userType;
    /**店铺数量*/
    private Integer num;

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }
}
