package com.nxin.etposvr.dm.base.controller.res;

/**
 * @author: xiaoshuai
 * @explain:
 * @since: 2020/4/15 14:00
 */
public class BaseLivestockDmResForm {
    private Byte systemId;

    private String categoryAxis;

    private String areaAxisLike;

    private double ztRate;

    private double zsRate;

    private String status;


    private Long totalBreedNum;

    private Long totalBrithNum;

    private Long totalManuNum;

    private Long zsTotal;

    private Long psTotal;

    private Long totalNum;

    private Long chNum;

    public Long getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Long totalNum) {
        this.totalNum = totalNum;
    }

    public Long getChNum() {
        return chNum;
    }

    public void setChNum(Long chNum) {
        this.chNum = chNum;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getAreaAxisLike() {
        return areaAxisLike;
    }

    public void setAreaAxisLike(String areaAxisLike) {
        this.areaAxisLike = areaAxisLike;
    }

    public double getZtRate() {
        return ztRate;
    }

    public void setZtRate(double ztRate) {
        this.ztRate = ztRate;
    }

    public double getZsRate() {
        return zsRate;
    }

    public void setZsRate(double zsRate) {
        this.zsRate = zsRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getTotalBreedNum() {
        return totalBreedNum;
    }

    public void setTotalBreedNum(Long totalBreedNum) {
        this.totalBreedNum = totalBreedNum;
    }

    public Long getTotalBrithNum() {
        return totalBrithNum;
    }

    public void setTotalBrithNum(Long totalBrithNum) {
        this.totalBrithNum = totalBrithNum;
    }

    public Long getTotalManuNum() {
        return totalManuNum;
    }

    public void setTotalManuNum(Long totalManuNum) {
        this.totalManuNum = totalManuNum;
    }

    public Long getZsTotal() {
        return zsTotal;
    }

    public void setZsTotal(Long zsTotal) {
        this.zsTotal = zsTotal;
    }

    public Long getPsTotal() {
        return psTotal;
    }

    public void setPsTotal(Long psTotal) {
        this.psTotal = psTotal;
    }
}
