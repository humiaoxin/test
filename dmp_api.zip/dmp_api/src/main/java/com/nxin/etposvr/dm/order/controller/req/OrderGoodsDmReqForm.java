package com.nxin.etposvr.dm.order.controller.req;

import com.nxin.etpojar.common.result.WebPageParam;
import com.nxin.etpojar.common.validation.group.VldGroup2th;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class OrderGoodsDmReqForm extends WebPageParam {

    @ApiModelProperty(value = "客户boId集合", example = "110119011415270001", dataType = "List")
    @NotNull(message = "000001|客户boId集合", groups = {VldGroup2th.class})
    public List<Long> boIdList;

    private List<Long> goodsIdList;
    //商品id
    private Long goodsId;
    //成交的商品数量
    private Integer dealNums;

    private Long id;

    private Long orderId;

    private Date goodsVno;

    private String goodsName;

    private Long categoryId;

    private String categoryAxis;

    private String categoryName;

    private Long manuId;

    private BigDecimal origGoodsNum;

    private BigDecimal finalGoodsNum;

    private String goodsNumUnitTxt;

    private String goodsNumUnit;

    private String goodsNumUnitType;

    private BigDecimal origNum;

    private BigDecimal finalNum;

    private String numUnitTxt;

    private String numUnit;

    private String numUnitType;

    private BigDecimal sellPrice;

    private BigDecimal goodsDiscountMoney;

    private BigDecimal goodsPayableMoney;

    private String promotionType;

    private Long pDtlId;

    private String remark;

    private String valuationMode;

    private Byte systemId;

    private String dataRemark;

    private Date createTime;

    private String versionRemark;

    private Date vno;

    private Byte isEnabled;

    //商品缩略图
    private String thumbnailUrl;

    /**
     * 品类集合
     */
    private List<Long> categoryIds;

    /**
     * 品类层级
     */
    private Integer rank;
    /**
     * 是否分页 1是0否
     */
    private Integer isPage;

    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Long> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public List<Long> getGoodsIdList() {
        return goodsIdList;
    }

    public void setGoodsIdList(List<Long> goodsIdList) {
        this.goodsIdList = goodsIdList;
    }

    public List<Long> getBoIdList() {
        return boIdList;
    }

    public void setBoIdList(List<Long> boIdList) {
        this.boIdList = boIdList;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getDealNums() {
        return dealNums;
    }

    public void setDealNums(Integer dealNums) {
        this.dealNums = dealNums;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Date getGoodsVno() {
        return goodsVno;
    }

    public void setGoodsVno(Date goodsVno) {
        this.goodsVno = goodsVno;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryAxis() {
        return categoryAxis;
    }

    public void setCategoryAxis(String categoryAxis) {
        this.categoryAxis = categoryAxis;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Long getManuId() {
        return manuId;
    }

    public void setManuId(Long manuId) {
        this.manuId = manuId;
    }

    public BigDecimal getOrigGoodsNum() {
        return origGoodsNum;
    }

    public void setOrigGoodsNum(BigDecimal origGoodsNum) {
        this.origGoodsNum = origGoodsNum;
    }

    public BigDecimal getFinalGoodsNum() {
        return finalGoodsNum;
    }

    public void setFinalGoodsNum(BigDecimal finalGoodsNum) {
        this.finalGoodsNum = finalGoodsNum;
    }

    public String getGoodsNumUnitTxt() {
        return goodsNumUnitTxt;
    }

    public void setGoodsNumUnitTxt(String goodsNumUnitTxt) {
        this.goodsNumUnitTxt = goodsNumUnitTxt;
    }

    public String getGoodsNumUnit() {
        return goodsNumUnit;
    }

    public void setGoodsNumUnit(String goodsNumUnit) {
        this.goodsNumUnit = goodsNumUnit;
    }

    public String getGoodsNumUnitType() {
        return goodsNumUnitType;
    }

    public void setGoodsNumUnitType(String goodsNumUnitType) {
        this.goodsNumUnitType = goodsNumUnitType;
    }

    public BigDecimal getOrigNum() {
        return origNum;
    }

    public void setOrigNum(BigDecimal origNum) {
        this.origNum = origNum;
    }

    public BigDecimal getFinalNum() {
        return finalNum;
    }

    public void setFinalNum(BigDecimal finalNum) {
        this.finalNum = finalNum;
    }

    public String getNumUnitTxt() {
        return numUnitTxt;
    }

    public void setNumUnitTxt(String numUnitTxt) {
        this.numUnitTxt = numUnitTxt;
    }

    public String getNumUnit() {
        return numUnit;
    }

    public void setNumUnit(String numUnit) {
        this.numUnit = numUnit;
    }

    public String getNumUnitType() {
        return numUnitType;
    }

    public void setNumUnitType(String numUnitType) {
        this.numUnitType = numUnitType;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public BigDecimal getGoodsDiscountMoney() {
        return goodsDiscountMoney;
    }

    public void setGoodsDiscountMoney(BigDecimal goodsDiscountMoney) {
        this.goodsDiscountMoney = goodsDiscountMoney;
    }

    public BigDecimal getGoodsPayableMoney() {
        return goodsPayableMoney;
    }

    public void setGoodsPayableMoney(BigDecimal goodsPayableMoney) {
        this.goodsPayableMoney = goodsPayableMoney;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public Long getpDtlId() {
        return pDtlId;
    }

    public void setpDtlId(Long pDtlId) {
        this.pDtlId = pDtlId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getValuationMode() {
        return valuationMode;
    }

    public void setValuationMode(String valuationMode) {
        this.valuationMode = valuationMode;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public String getDataRemark() {
        return dataRemark;
    }

    public void setDataRemark(String dataRemark) {
        this.dataRemark = dataRemark;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getVersionRemark() {
        return versionRemark;
    }

    public void setVersionRemark(String versionRemark) {
        this.versionRemark = versionRemark;
    }

    public Date getVno() {
        return vno;
    }

    public void setVno(Date vno) {
        this.vno = vno;
    }

    public Byte getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Byte isEnabled) {
        this.isEnabled = isEnabled;
    }

    @Override
    public String toString() {
        return "OrderGoodsDmReqForm{" +
                "boIdList=" + boIdList +
                ", goodsIdList=" + goodsIdList +
                ", goodsId=" + goodsId +
                ", dealNums=" + dealNums +
                ", id=" + id +
                ", orderId=" + orderId +
                ", goodsVno=" + goodsVno +
                ", goodsName='" + goodsName + '\'' +
                ", categoryId=" + categoryId +
                ", categoryAxis='" + categoryAxis + '\'' +
                ", categoryName='" + categoryName + '\'' +
                ", manuId=" + manuId +
                ", origGoodsNum=" + origGoodsNum +
                ", finalGoodsNum=" + finalGoodsNum +
                ", goodsNumUnitTxt='" + goodsNumUnitTxt + '\'' +
                ", goodsNumUnit='" + goodsNumUnit + '\'' +
                ", goodsNumUnitType='" + goodsNumUnitType + '\'' +
                ", origNum=" + origNum +
                ", finalNum=" + finalNum +
                ", numUnitTxt='" + numUnitTxt + '\'' +
                ", numUnit='" + numUnit + '\'' +
                ", numUnitType='" + numUnitType + '\'' +
                ", sellPrice=" + sellPrice +
                ", goodsDiscountMoney=" + goodsDiscountMoney +
                ", goodsPayableMoney=" + goodsPayableMoney +
                ", promotionType='" + promotionType + '\'' +
                ", pDtlId=" + pDtlId +
                ", remark='" + remark + '\'' +
                ", valuationMode='" + valuationMode + '\'' +
                ", systemId=" + systemId +
                ", dataRemark='" + dataRemark + '\'' +
                ", createTime=" + createTime +
                ", versionRemark='" + versionRemark + '\'' +
                ", vno=" + vno +
                ", isEnabled=" + isEnabled +
                ", thumbnailUrl='" + thumbnailUrl + '\'' +
                ", categoryIds=" + categoryIds +
                '}';
    }
}
