package com.nxin.etposvr.dm.goods.controller.res;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author lpp
 * @Date 2020/3/10 10:03
 * @Version 1.0
 */
public class GoodsSpecCustPriceDmResForm {


    /**
     * 卖家用户boid
     *
     * @author lpp
     * @date 2020/3/9 17:55
     */
    private Long sellerBoId;
    /**
     * 客户关系id
     * @author lpp
     * @date 2020/3/9 18:06
     */
    private Long customerId;
    /**
     * 客户用户id
     * @author lpp
     * @date 2020/3/9 18:06
     */
    private Long customerBoId;
    /**
     * 系统id
     *
     * @author lpp
     * @date 2020/3/9 17:55
     */
    private Byte systemId;
    /**
     * 商品id
     *
     * @author lpp
     * @date 2020/3/9 17:55
     */
    private Long goodsId;
    /**
     * 优惠类型 YYH-以优惠 WYH-未优惠
     *
     * @author lpp
     * @date 2020/3/9 17:56
     */
    private String discountType;
    /**
     * 商品规格id
     *
     * @author lpp
     * @date 2020/3/9 17:56
     */
    private Long goodsSpecId;
    /**
     * 销售价格
     *
     * @author lpp
     * @date 2020/3/9 17:56
     */
    private BigDecimal sellPrice;
    /**
     * 规格名称
     *
     * @author lpp
     * @date 2020/3/9 17:57
     */
    private String goodsSpecTxt;
    /**
     * 优惠金额
     *
     * @author lpp
     * @date 2020/3/9 17:57
     */
    private BigDecimal discount;
    /**
     * 客户名称
     *
     * @author lpp
     * @date 2020/3/9 17:57
     */
    private String noteName;
    /**
     * 客户电话
     *
     * @author lpp
     * @date 2020/3/9 17:57
     */
    private String mobilePhone;

    /**
     * 客户是否注册
     *
     * @author lpp
     * @date 2020/3/10 13:38
     */
    private Byte isRegister;
    /**
     * 客户创建时间
     *
     * @author lpp
     * @date 2020/3/10 13:38
     */
    private Date custCreateTime;
    /**
     * 客户头像
     *
     * @author lpp
     * @date 2020/3/10 14:07
     */
    private String custHeadIcon;

    /**
     * 商品数量
     *
     * @author lpp
     * @date 2020/3/10 17:20
     */
    private Long goodsNum;
    /**
     * 价格方案id
     *
     * @author lpp
     * @date 2020/3/13 18:34
     */
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getGoodsNum() {
        return goodsNum;
    }

    public void setGoodsNum(Long goodsNum) {
        this.goodsNum = goodsNum;
    }

    public String getCustHeadIcon() {
        return custHeadIcon;
    }

    public void setCustHeadIcon(String custHeadIcon) {
        this.custHeadIcon = custHeadIcon;
    }


    public Byte getIsRegister() {
        return isRegister;
    }

    public void setIsRegister(Byte isRegister) {
        this.isRegister = isRegister;
    }

    public Date getCustCreateTime() {
        return custCreateTime;
    }

    public void setCustCreateTime(Date custCreateTime) {
        this.custCreateTime = custCreateTime;
    }

    public Long getSellerBoId() {
        return sellerBoId;
    }

    public void setSellerBoId(Long sellerBoId) {
        this.sellerBoId = sellerBoId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getCustomerBoId() {
        return customerBoId;
    }

    public void setCustomerBoId(Long customerBoId) {
        this.customerBoId = customerBoId;
    }

    public Byte getSystemId() {
        return systemId;
    }

    public void setSystemId(Byte systemId) {
        this.systemId = systemId;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public Long getGoodsSpecId() {
        return goodsSpecId;
    }

    public void setGoodsSpecId(Long goodsSpecId) {
        this.goodsSpecId = goodsSpecId;
    }

    public BigDecimal getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(BigDecimal sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getGoodsSpecTxt() {
        return goodsSpecTxt;
    }

    public void setGoodsSpecTxt(String goodsSpecTxt) {
        this.goodsSpecTxt = goodsSpecTxt;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public String getNoteName() {
        return noteName;
    }

    public void setNoteName(String noteName) {
        this.noteName = noteName;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @Override
    public String toString() {
        return "GoodsSpecCustPriceDmResForm{" +
                "sellerBoId=" + sellerBoId +
                ", customerId=" + customerId +
                ", customerBoId=" + customerBoId +
                ", systemId=" + systemId +
                ", goodsId=" + goodsId +
                ", discountType='" + discountType + '\'' +
                ", goodsSpecId=" + goodsSpecId +
                ", sellPrice=" + sellPrice +
                ", goodsSpecTxt='" + goodsSpecTxt + '\'' +
                ", discount=" + discount +
                ", noteName='" + noteName + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                '}';
    }
}
